#!/usr/bin/env bash
set -eo pipefail
source /workspace/env.sh
export PATH="/work/venvs/validation/bin:$PATH"
export OMP_NUM_THREADS=1 PYTHONDONTWRITEBYTECODE=1
cd /workspace/hyper-parallel
python /work/tools/check_dense_wgrad_long_cpu.py
