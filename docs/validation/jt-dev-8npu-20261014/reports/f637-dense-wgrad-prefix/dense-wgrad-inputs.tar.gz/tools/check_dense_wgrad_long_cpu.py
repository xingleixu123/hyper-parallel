# Copyright 2026 Huawei Technologies Co., Ltd
#
# Licensed under the Apache License, Version 2.0 (the "License");
# you may not use this file except in compliance with the License.
# You may obtain a copy of the License at
#
# http://www.apache.org/licenses/LICENSE-2.0
#
# Unless required by applicable law or agreed to in writing, software
# distributed under the License is distributed on an "AS IS" BASIS,
# WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
# See the License for the specific language governing permissions and
# limitations under the License.
# ============================================================================

"""CPU derivative, actual FSDP consumption and checkpoint contracts for the candidate."""

from __future__ import annotations

import hashlib
import json
from pathlib import Path
from types import MethodType, SimpleNamespace
import unittest

# CPU tests exercise native Torch autograd and the current FSDP implementation.
import torch  # pylint: disable=forbidden-backend-import
from torch.nn import functional  # pylint: disable=forbidden-backend-import
from torch.utils.checkpoint import DefaultDeviceType  # pylint: disable=forbidden-backend-import

from dense_wgrad_experiment import NATIVE_LINEAR, row_slice
from dense_wgrad_long_observer import LongDenseWgrad
from hyper_parallel.components.losses.chunked_cross_entropy import projected_cross_entropy
from hyper_parallel.core.fully_shard.hsdp_param import HSDPParamV2
from hyper_parallel.trainer.config.parser import parse_training_args


ROOT = Path('/work')


def cpu_accumulate(destination: torch.Tensor, gradient: torch.Tensor, inputs: torch.Tensor) -> None:
    """Independent CPU FP64 oracle substituted for the NPU grouped-matmul operation."""
    destination.add_((gradient.double().t() @ inputs.double()).float())


class RowLinear(torch.nn.Linear):
    """Exercise a derived Linear and the adapter's explicit contiguous-row view."""

    def forward(self, inputs: torch.Tensor, rows: slice | None = None, fail: bool = False) -> torch.Tensor:
        """Use the same module-owned projection boundary as the CP head adapter."""
        if fail:
            raise ValueError('intentional projection failure')
        weight = self.weight if rows is None else self.weight[rows]
        return functional.linear(inputs, weight)


def managed_linear(rows: int = 19, width: int = 13) -> RowLinear:
    """Provide local managed-parameter attributes without distributed initialization."""
    module = RowLinear(width, rows, bias=False, dtype=torch.bfloat16)
    module.weight.main_grad = None
    module.weight.grad_added_to_main_grad = False
    return module


def holder_for(owner: torch.nn.Parameter) -> SimpleNamespace:
    """Supply fields to real FSDP consumption methods, without mocking their arithmetic."""
    holder = SimpleNamespace(_unsharded_param=owner, _orig_size=owner.shape,
                             reduce_dtype=torch.float32, unsharded_accumulated_grad=None)
    holder._accumulate_fused_grad_if_needed = MethodType(  # pylint: disable=protected-access
        HSDPParamV2._accumulate_fused_grad_if_needed, holder)  # pylint: disable=protected-access
    return holder


class DenseWgradContracts(unittest.TestCase):
    """Cover forward/dgrad equivalence, FP32 ownership, replay and failure boundaries."""

    def setUp(self) -> None:
        """Use a fixed small CPU fixture and restore only owned patches after each test."""
        self.addCleanup(DefaultDeviceType.set_device_type, DefaultDeviceType.get_device_type())
        DefaultDeviceType.set_device_type('cpu')
        torch.manual_seed(20261016)
        self.native = functional.linear
        self.module = managed_linear()
        self.model = torch.nn.ModuleDict({'lm_head': self.module})

    def observer(self) -> LongDenseWgrad:
        """Register cleanup immediately after installing this test's diagnostic."""
        result = LongDenseWgrad(self.model, cpu_accumulate)
        self.addCleanup(result.close)
        return result

    def test_full_row_slice_empty_and_multiple_microbatches(self) -> None:
        """Keep native dX and collect FP32 wgrad across real FSDP handoffs including mixed gradients."""
        observer = self.observer()
        holder = holder_for(self.module.weight)
        exact = torch.zeros_like(self.module.weight, dtype=torch.float64)
        for start, stop, tokens in ((0, 19, 37), (3, 17, 23), (0, 19, 0)):
            with self.subTest(start=start, stop=stop, tokens=tokens):
                inputs = torch.randn(2, tokens, 13, dtype=torch.bfloat16, requires_grad=True)
                upstream = torch.randn(2, tokens, stop-start, dtype=torch.bfloat16)
                weight = self.module.weight[start:stop]
                native = NATIVE_LINEAR(inputs, weight)
                native_dx = torch.autograd.grad(native, inputs, upstream)[0]
                actual = self.module(inputs, rows=slice(start, stop))
                torch.testing.assert_close(actual, native, rtol=0, atol=0)
                actual.backward(upstream)
                torch.testing.assert_close(inputs.grad, native_dx, rtol=0, atol=0)
                exact[start:stop] += (upstream.double().reshape(-1, stop-start).t()
                                      @ inputs.detach().double().reshape(-1, 13))
                self.assertTrue(self.module.weight.grad_added_to_main_grad)
                self.assertEqual(self.module.weight.grad.count_nonzero().item(), 0)
                # An ordinary producer may share the same parameter. FSDP must retain it as well.
                ordinary = torch.full_like(self.module.weight, 0.125)
                self.module.weight.grad.add_(ordinary)
                exact += ordinary.double()
                HSDPParamV2.to_accumulated_grad_if_needed(holder)
                self.assertIsNone(self.module.weight.main_grad)
                self.assertFalse(self.module.weight.grad_added_to_main_grad)
                self.assertIsNone(self.module.weight.grad)
        torch.testing.assert_close(holder.unsharded_accumulated_grad, exact.float(), rtol=1e-6, atol=1e-5)
        coverage = observer.finish_step()
        self.assertEqual(sum(row['calls'] for row in coverage['records'] if row['event'] == 'fp32_wgrad'), 2)
        self.assertEqual(coverage['checked_owner_buffers'], 1)
        self.assertEqual(observer.finish_step(), {'records': [], 'unscoped_native_forward': {},
                                                  'checked_owner_buffers': 0})

    def test_unconsumed_buffer_is_rejected(self) -> None:
        """A successful kernel alone cannot certify delivery to FSDP reduction."""
        observer = self.observer()
        self.module(torch.randn(1, 5, 13, dtype=torch.bfloat16)).sum().backward()
        with self.assertRaisesRegex(RuntimeError, 'did not consume'):
            observer.finish_step()
        HSDPParamV2.to_accumulated_grad_if_needed(holder_for(self.module.weight))
        self.assertEqual(observer.finish_step()['checked_owner_buffers'], 1)

    def test_checkpointed_output_head(self) -> None:
        """Use the production projected loss and avoid duplicate accumulation during replay."""
        values = torch.randn(1, 9, 13, dtype=torch.bfloat16, requires_grad=True)
        labels = torch.randint(0, 19, (1, 9))
        labels[:, 2] = -100

        def loss_fn(*, logits: torch.Tensor, shift_labels: torch.Tensor,
                    num_items_in_batch: torch.Tensor, **_kwargs: object) -> torch.Tensor:
            """Compute the standard token-sum CE with the production chunk denominator."""
            return functional.cross_entropy(logits.float().reshape(-1, 19), shift_labels.reshape(-1),
                                            reduction='sum', ignore_index=-100) / num_items_in_batch

        def score(inputs: torch.Tensor) -> torch.Tensor:
            """Run the real module-owned chunked projection and checkpoint path."""
            return projected_cross_entropy(inputs, labels, head=self.module, loss_fn=loss_fn,
                                           vocab_size=19, chunk_size=4)

        native = score(values)
        native_dx = torch.autograd.grad(native, values)[0]
        observer = self.observer()
        actual_values = values.detach().clone().requires_grad_()
        actual = score(actual_values)
        actual.backward()
        torch.testing.assert_close(actual, native, rtol=0, atol=0)
        torch.testing.assert_close(actual_values.grad, native_dx, rtol=0, atol=0)
        HSDPParamV2.to_accumulated_grad_if_needed(holder_for(self.module.weight))
        rows = observer.finish_step()['records']
        self.assertEqual(sum(row['calls'] for row in rows if row['event'] == 'fp32_wgrad'), 3)
        self.assertGreater(sum(row['calls'] for row in rows if row['event'] == 'forward'), 3)

    def test_owner_views_and_unmanaged_weights_fail(self) -> None:
        """Reject unrelated storage, column slicing and missing managed-gradient ownership."""
        for weight in (self.module.weight[:, ::2], self.module.weight.detach().clone()):
            with self.subTest(shape=list(weight.shape)), self.assertRaises(ValueError):
                row_slice(self.module.weight, weight)
        observer = self.observer()
        del self.module.weight.main_grad
        with self.assertRaisesRegex(ValueError, 'managed FP32-gradient'):
            self.module(torch.randn(1, 3, 13, dtype=torch.bfloat16))
        self.assertEqual(observer.active.get(), ())

    def test_exception_unscoped_calls_and_patch_ownership(self) -> None:
        """Always remove module scopes, preserve native functional calls and reject lost ownership."""
        observer = self.observer()
        inputs = torch.randn(1, 3, 13, dtype=torch.bfloat16)
        with self.assertRaisesRegex(ValueError, 'intentional projection'):
            self.module(inputs, fail=True)
        self.assertEqual(observer.active.get(), ())
        torch.testing.assert_close(functional.linear(inputs, self.module.weight),
                                   NATIVE_LINEAR(inputs, self.module.weight), rtol=0, atol=0)
        self.assertEqual(observer.finish_step()['unscoped_native_forward'], {'torch.bfloat16': 1})
        def foreign(*args: object) -> torch.Tensor:
            """Represent another owner's later functional replacement."""
            return self.native(*args)

        functional.linear = foreign
        try:
            with self.assertRaisesRegex(RuntimeError, 'ownership was lost'):
                observer.close()
            self.assertIs(functional.linear, foreign)
        finally:
            functional.linear = self.native


def main() -> None:
    """Run CPU contracts and parse both exact training configs with the actual runtime parser."""
    suite = unittest.defaultTestLoader.loadTestsFromTestCase(DenseWgradContracts)
    result = unittest.TextTestRunner(verbosity=2).run(suite)
    if not result.wasSuccessful():
        raise SystemExit(1)
    configs = []
    for layout, reference in (('fsdp8', 'r129-f637-fp32-fsdp8-0-200-r4'),
                              ('cp2', 'r129-f637-fp32-cp2-200')):
        case = f'r129-f637-dense-wgrad-{layout}-200-v1'
        path = ROOT / 'configs' / (case + '.yaml')
        actual = parse_training_args([str(path)]).to_dict()
        expected = json.loads((ROOT / 'runs' / reference / 'config.resolved.json').read_bytes())
        expected['checkpoint']['save_ckpt'] = False
        expected['checkpoint']['checkpoint_dir'] = '/work/checkpoints/' + case
        if actual != expected or actual['training']['train_iters'] != 200:
            raise AssertionError('Candidate changed more than checkpoint output: ' + case)
        configs.append({'case': case, 'status': 'PASS', 'sha256': hashlib.sha256(path.read_bytes()).hexdigest()})
    initialized = hasattr(torch, 'npu') and torch.npu.is_initialized()
    if initialized or torch.cuda.is_initialized():
        raise RuntimeError('CPU validation initialized an accelerator')
    names = ('dense_wgrad_experiment.py', 'dense_wgrad_long_observer.py',
             'capture_dense_wgrad_200_training.py', 'check_dense_wgrad_long_cpu.py')
    report = {'status': 'CPU_ONLY_PASS', 'test_count': result.testsRun, 'resolved_configs': configs,
              'npu_initialized': initialized, 'torch': torch.__version__,
              'source_sha256': {name: hashlib.sha256((ROOT / 'tools' / name).read_bytes()).hexdigest()
                                for name in names},
              'scope': 'Small CPU derivative, real FSDP handoff and chunk replay contracts; no 200-step NPU verdict'}
    with (ROOT / 'evidence/f637-dense-wgrad-long-cpu-v1.json').open('x', encoding='utf-8') as handle:
        json.dump(report, handle, ensure_ascii=False, indent=2)
    print(json.dumps(report, ensure_ascii=False))


if __name__ == '__main__':
    main()
