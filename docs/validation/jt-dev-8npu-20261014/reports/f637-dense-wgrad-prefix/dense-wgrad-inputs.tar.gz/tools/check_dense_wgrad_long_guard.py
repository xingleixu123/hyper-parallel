# Copyright 2026 Huawei Technologies Co., Ltd
#
# Licensed under the Apache License, Version 2.0 (the "License");
# you may not use this file except in compliance with the License.
# You may obtain a copy of the License at
#
# http://www.apache.org/licenses/LICENSE-2.0
#
# Unless required by applicable law or agreed to in writing, software
# distributed under the License is distributed on an "AS IS" BASIS,
# WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
# See the License for the specific language governing permissions and
# limitations under the License.
# ============================================================================

"""Reject unprepared dense-gradient reservations before touching external resources."""

import hashlib
from pathlib import Path
import tempfile
import unittest
from unittest.mock import patch

from check_pr214_guard import GUARD


class DenseWgradGuardTests(unittest.TestCase):
    """Keep the paired experiment's host, device count, budget and ports fixed."""

    def setUp(self) -> None:
        """Use a private source fixture and mocked resource snapshots."""
        directory = self.enterContext(tempfile.TemporaryDirectory())  # pylint: disable=consider-using-with
        root = Path(directory)
        (root / 'repo').mkdir()
        self.enterContext(patch.object(GUARD, 'ROOT', root))
        self.request = {'host': '129', 'case': 'r129-f637-dense-wgrad-fsdp8-200-v1', 'cards': 8,
                        'timeout_seconds': 900, 'port': 30382, 'runner': '/work/tools/run_fair_dense_wgrad_200.sh',
                        'source': 'fixed-source', 'patch_sha256': hashlib.sha256(b'').hexdigest(),
                        'files': {}, 'image': sorted(GUARD.ALLOWED_IMAGES)[0]}

    def test_unprepared_reservations_fail_before_external_commands(self) -> None:
        """Reject smaller runs, another host, a longer hold, swapped ports and unprepared retries."""
        changes = ({'cards': 4}, {'host': '125'}, {'timeout_seconds': 840}, {'timeout_seconds': 901},
                   {'port': 30383}, {'case': 'r129-f637-dense-wgrad-fsdp8-200-v2'})
        for change in changes:
            with self.subTest(change=change), patch.object(GUARD.subprocess, 'check_output') as external:
                with self.assertRaises(ValueError):
                    GUARD.remote_job({**self.request, **change})
                external.assert_not_called()

    def test_both_arms_wait_if_fewer_than_eight_cards_are_free(self) -> None:
        """No container may start when the original eight-device requirement is unavailable."""
        idle = {'healthy': True, 'empty': True, 'pids': [], 'core': 0, 'hbm_mb': 3000}
        for layout, port in (('fsdp8', 30382), ('cp2', 30383)):
            request = {**self.request, 'case': f'r129-f637-dense-wgrad-{layout}-200-v1', 'port': port}
            with self.subTest(layout=layout), \
                    patch.object(GUARD.subprocess, 'check_output', side_effect=['fixed-source\n', b'']), \
                    patch.object(GUARD, 'card_snapshot', return_value={index: idle for index in range(7)}), \
                    patch.object(GUARD.subprocess, 'run') as execute:
                receipt = GUARD.remote_job(request)
            self.assertFalse(receipt['attempted'])
            self.assertEqual(receipt['reason'], 'insufficient-free-devices')
            execute.assert_not_called()


if __name__ == '__main__':
    unittest.main(verbosity=2)
