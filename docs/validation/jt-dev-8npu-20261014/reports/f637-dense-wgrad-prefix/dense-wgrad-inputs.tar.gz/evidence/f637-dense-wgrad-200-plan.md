# 普通 Linear FP32 权重梯度累积：匹配 FSDP8 / CP2 诊断计划

## 目的与冻结条件

输入梯度候选已在共有 1–163 步以主 LM loss 最大差 0.0120849609375 被否决。本轮检验另一项独立假设：普通 Linear 的 BF16 局部权重梯度舍入在分区/多微批组合下累积，改用 FP32 直接累积是否改善当前主 loss 对齐。

固定 JT_dev `f637ef7ee4d4b416800716f1ebaaae7709b8a06a`、集成源 `18602c4524dc664b81b2bad9a7b624455ce1494f`、镜像 `sha256:5f9e677f439d11ab4e7c888f54b142335a27eee7411cbd2ce894a4798a70146d`、CANN9.2.0-beta.2。保持原 BF16 前向和输入梯度，专家 FP32 wgrad、Muon NS FP32、数据/初始化、LR0.0001、MTP0.3、aux0.0001不变。没有把已否决的 FP32 输入梯度叠加进来。

两个新实验均在129用8卡、从同一初始化各跑200步。先 `r129-f637-dense-wgrad-fsdp8-200-v1`（端口30382），释放后至少1200秒，再检查空卡运行 `r129-f637-dense-wgrad-cp2-200-v1`（30383）。单轮最长900秒，runner内部840秒；冲突仅停止本任务自有容器。旧配方参考用于身份/诊断，不能替代本轮数值配方的匹配 FSDP 参考。

## 实现与计算覆盖

复用冻结的 `dense_wgrad_experiment.py` 中 `DenseWeightGradient`、`row_slice` 和 `npu_accumulate` 数学实现，SHA见manifest。新增 bounded observer 按 `isinstance(nn.Linear)` 选择模块，包括 FSDP 动态派生类和 lm_head；不调用旧 helper 的 `install_dense_wgrad`，其“functional head excluded”历史说明不作为本轮范围。模型中的 lm_head 是实际模块路径，必须记录到 FP32 累积回调。

原生 BF16 Linear 计算前向和 dX；实际 NPU `npu_grouped_matmul_add_` 把 dW 直接累积到明确 owner 的 FP32 main_grad，返回中性 BF16梯度供已有FSDP hook运行。只接受本地连续矩阵及明确所属的连续行切片；TP DTensor、bias、不匹配的owner/数据类型拒绝执行。本轮不宣称TP覆盖。

每步记录模块名、输入/权重形状、行起点和实际 FP32 累积次数；未进入模块作用域的原生functional调用另外计数。记录限于标量元数据，每步每rank最多64KiB，不保存激活或全参数逐步dump。步末检查观察到的参数main_grad已由FSDP清空或对象已释放；输出头未实际累积或缓冲未被消费即失败。关闭时恢复仅属本实验的patch并移除hooks。

## 已做前置验证与限制

5项CPU检查通过：原生前向/dX精确相同，完整/行切片/空输入及多个微批FP64 oracle，真实HSDPParamV2梯度接管与混合普通梯度，生产projected_cross_entropy的checkpoint重放，错误owner、漏消费、异常作用域、未作用域调用和patch所有权。两份实际parser输出仅更改checkpoint关闭/目的地，其他字段与原参考完全相同。当前源码SHA与CPU容器实测一致，NPU未初始化，CPU容器已移除。

首轮4项通过、checkpoint用例在原生参考反向中因TorchNPU默认设备类型尝试NPU初始化而失败；没有设备映射，未获得任何NPU训练结果。按仓库已有CPU测试方式设置并恢复DefaultDeviceType('cpu')后重跑通过，首轮源码/日志/收据保留。未删除用例、放宽数值断言或改变训练代码。

旧小形状NPU算子oracle和旧源码三步dense诊断仅提供历史可行性，不能作为本轮200步通过。新增observer及CPU测试已按当前仓库pylint通过；调度守卫28项通过。当前检视由主代理完成，没有冒称新增独立审阅者。

## 验收和存储

用未修改的严格比较器检查全部8rank、完整200步的主LM loss最大绝对差<=0.005，另核验退出/完成标记、输入、初始化、配方/源码、LR和计数。MTP/aux保留实际系数还原的观测，当前主loss全部通过后按用户要求先汇报，不继续扩展专项。若数值配方有希望，仍需重建对应续训/独立连续400和其他拓扑，不能挪用原配方的通过结论。

采集显存与逐步耗时，但单次、含观测且精度未通过的诊断不作为生产性能收益。FP32中间梯度和中性梯度可能增加峰值及计算开销，使用实际全rank数据核实。

关闭本轮checkpoint输出，保留已有129 step200 checkpoint。预计元数据、普通日志和小规模集成构建报告合计不超过128MiB/轮；启动前重新检查/home任务挂载、Docker根目录和主机资源。当前129任务文件系统约210GB空闲。只清理经大小/SHA和归属验证且已用完的任务重复件，保留失败记录及复现依赖。
