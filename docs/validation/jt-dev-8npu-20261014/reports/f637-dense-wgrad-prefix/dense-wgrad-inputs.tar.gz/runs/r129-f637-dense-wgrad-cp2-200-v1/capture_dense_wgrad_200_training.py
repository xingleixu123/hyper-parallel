# Copyright 2026 Huawei Technologies Co., Ltd
#
# Licensed under the Apache License, Version 2.0 (the "License");
# you may not use this file except in compliance with the License.
# You may obtain a copy of the License at
#
# http://www.apache.org/licenses/LICENSE-2.0
#
# Unless required by applicable law or agreed to in writing, software
# distributed under the License is distributed on an "AS IS" BASIS,
# WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
# See the License for the specific language governing permissions and
# limitations under the License.
# ============================================================================

"""Matched FSDP8/CP2 dense-weight-gradient experiment with bounded actual coverage."""

import json
from typing import Any

import capture_training
from dense_wgrad_long_observer import LongDenseWgrad

from hyper_parallel.trainer.callbacks.base import Callback


NATIVE_TRAINER = capture_training.TextTrainer
OBSERVER = None


class DenseGradientCoverage(Callback):
    """Record actual FP32 accumulator calls and their FSDP consumption each step."""

    def on_step_end(self, state: object, **kwargs: object) -> None:
        """Reject an inactive experiment or a main gradient left outside FSDP reduction."""
        result = OBSERVER.finish_step()
        calculated = {row['module'] for row in result['records'] if row['event'] == 'fp32_wgrad'}
        if not calculated or 'lm_head' not in calculated:
            raise RuntimeError("Dense FP32 accumulation did not cover the output head")
        result.update(step=state.global_step, rank=capture_training.RANK)
        payload = json.dumps(result, allow_nan=False) + '\n'
        if len(payload.encode()) > 64 * 1024:
            raise RuntimeError("Dense gradient coverage exceeded the per-step metadata bound")
        path = capture_training.OUTPUT / f'dense-wgrad-step-coverage-rank{capture_training.RANK}.jsonl'
        with path.open('a', encoding='utf-8') as handle:
            handle.write(payload)


def build_trainer(*args: Any, **kwargs: Any) -> Any:
    """Install after managed parameters exist and before the first training step."""
    global OBSERVER  # pylint: disable=global-statement
    trainer = NATIVE_TRAINER(*args, **kwargs)
    base = trainer.base
    if (base.train_iters != 200 or base.state.global_step != 0 or base.mesh.tp_size != 1
            or base.mesh.ep_size != 1 or base.mesh.cp_size not in (1, 2) or base.mesh.pp_size != 1
            or base.mesh.dp_size * base.mesh.cp_size != 8):
        raise ValueError("Dense diagnostic requires a fresh eight-card TP1/EP1/PP1 FSDP8 or CP2 200-step run")
    OBSERVER = LongDenseWgrad(base.model)
    base._callbacks.append(DenseGradientCoverage(base))  # pylint: disable=protected-access
    capture_training.write_json(f'dense-wgrad-long-experiment-rank{capture_training.RANK}.json', {
        'numeric_recipe_changed': True, 'production_source_unchanged': True,
        'steps': 200, 'cp_size': base.mesh.cp_size, 'modules': OBSERVER.modules,
        'forward_and_dgrad': 'native BF16', 'wgrad': 'FP32 grouped-matmul-add into explicit owner main_grad',
        'expert_wgrad': 'existing configured FP32 GMM', 'muon_ns': 'existing configured FP32',
        'comparison': 'only against the new FSDP8 reference with the same changed numerical recipe',
        'scope': 'diagnostic; output head is included, unscoped functional calls are reported separately',
    })
    return trainer


def main() -> None:
    """Run the normal evidence collector and release this experiment's hooks."""
    capture_training.TextTrainer = build_trainer
    try:
        capture_training.main()
    finally:
        if OBSERVER is not None:
            OBSERVER.close()


if __name__ == '__main__':
    main()
