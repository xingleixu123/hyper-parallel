"""Diagnostic BF16 Linear forward/dgrad with explicitly owned FP32 weight gradients."""

import json
from pathlib import Path

import torch
from torch.nn import functional as F


NATIVE_LINEAR = F.linear


def row_slice(owner, weight):
    """Accept only the named module parameter or its contiguous CP head-row view."""
    if type(owner) not in (torch.Tensor, torch.nn.Parameter) or type(weight) not in (torch.Tensor, torch.nn.Parameter):
        raise ValueError('Dense diagnostic requires local Torch tensors')
    if owner.ndim != 2 or weight.ndim != 2 or not owner.is_contiguous() or not weight.is_contiguous():
        raise ValueError('Dense diagnostic requires contiguous matrix weights')
    if owner.shape[1] != weight.shape[1] or owner.untyped_storage().data_ptr() != weight.untyped_storage().data_ptr():
        raise ValueError('Linear weight is not a row slice of its explicit module owner')
    offset = weight.storage_offset() - owner.storage_offset()
    width = owner.shape[1]
    if offset < 0 or offset % width or offset // width + weight.shape[0] > owner.shape[0]:
        raise ValueError('Linear weight row slice is outside its explicit owner')
    return offset // width


def npu_accumulate(destination, grad_output, inputs):
    """Use the same CANN FP32 accumulator already exercised by expert-gradient ST."""
    import torch_npu  # Optional NPU dependency; CPU oracle supplies an independent accumulator.
    groups = torch.tensor([inputs.shape[0]], dtype=torch.int64, device=inputs.device)
    torch_npu.npu_grouped_matmul_add_(
        destination.unsqueeze(0), grad_output, inputs, groups,
        transpose_x=True, transpose_weight=False, group_type=2)


class DenseWeightGradient(torch.autograd.Function):
    """Change only weight-gradient accumulation, retaining BF16 forward and dgrad."""

    @staticmethod
    def forward(ctx, inputs, weight, owner, accumulate):
        if inputs.dtype != torch.bfloat16 or weight.dtype != torch.bfloat16:
            raise ValueError('Dense diagnostic requires BF16 inputs and weights')
        if not hasattr(owner, 'main_grad') or not hasattr(owner, 'grad_added_to_main_grad'):
            raise ValueError('Explicit owner has no managed FP32-gradient protocol')
        ctx.start = row_slice(owner, weight)
        ctx.owner = owner
        ctx.accumulate = accumulate
        ctx.save_for_backward(inputs, weight)
        return NATIVE_LINEAR(inputs, weight)

    @staticmethod
    def backward(ctx, gradient):
        inputs, weight = ctx.saved_tensors
        gradient = gradient.contiguous()
        input_gradient = NATIVE_LINEAR(gradient, weight.t()) if ctx.needs_input_grad[0] else None
        weight_gradient = None
        if ctx.needs_input_grad[1]:
            owner = ctx.owner
            if owner.main_grad is None:
                owner.main_grad = torch.zeros(owner.shape, dtype=torch.float32, device=owner.device)
            buffer = owner.main_grad
            if (buffer.dtype != torch.float32 or buffer.shape != owner.shape or buffer.device != owner.device
                    or not buffer.is_contiguous() or buffer.requires_grad):
                raise ValueError('Managed dense main_grad has an incompatible contract')
            if inputs.numel():
                target = buffer.narrow(0, ctx.start, weight.shape[0])
                ctx.accumulate(target, gradient.reshape(-1, weight.shape[0]), inputs.reshape(-1, inputs.shape[-1]))
            owner.grad_added_to_main_grad = True
            weight_gradient = torch.zeros_like(weight)
        return input_gradient, weight_gradient, None, None


def install_dense_wgrad(model, output: Path, rank: int):
    """Instrument actual nn.Linear calls; functional loss-head projections are excluded."""
    original = F.linear
    active = []
    handles = []
    selected = []
    seen = set()

    def linear(inputs, weight, bias=None):
        if not active:
            return original(inputs, weight, bias)
        name, module = active[-1]
        if bias is not None:
            raise ValueError('Bias support is outside this diagnostic')
        result = DenseWeightGradient.apply(inputs, weight, module.weight, npu_accumulate)
        signature = (name, tuple(inputs.shape), tuple(weight.shape))
        if signature not in seen:
            seen.add(signature)
            with (output / f'dense-wgrad-calls-rank{rank}.jsonl').open('a') as handle:
                handle.write(json.dumps({'module': name, 'input_shape': list(inputs.shape),
                                         'weight_shape': list(weight.shape), 'owner_shape': list(module.weight.shape),
                                         'row_start': row_slice(module.weight, weight)}) + '\n')
        return result

    def begin(name):
        def hook(module, _args):
            active.append((name, module))
        return hook

    def end(name):
        def hook(_module, _args, result):
            if not active or active.pop()[0] != name:
                raise RuntimeError('Dense diagnostic scope mismatch')
            return result
        return hook

    for name, module in model.named_modules():
        if type(module) is torch.nn.Linear:
            selected.append(name)
            handles.append(module.register_forward_pre_hook(begin(name)))
            handles.append(module.register_forward_hook(end(name), always_call=True))
    if not selected:
        raise ValueError('No Linear modules found')
    F.linear = linear
    (output / f'dense-wgrad-rank{rank}.json').write_text(json.dumps({
        'modules': selected, 'forward_and_dgrad': 'original BF16', 'wgrad': 'FP32 GMM-add accumulator',
        'scope': 'Diagnostic only; functional loss-head projection is outside this module hook',
    }, indent=2) + '\n')

    def remove():
        F.linear = original
        for handle in handles:
            handle.remove()
    return remove
