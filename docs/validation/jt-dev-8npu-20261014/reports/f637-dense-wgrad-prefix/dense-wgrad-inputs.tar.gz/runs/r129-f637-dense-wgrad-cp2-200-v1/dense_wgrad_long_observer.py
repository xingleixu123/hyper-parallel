# Copyright 2026 Huawei Technologies Co., Ltd
#
# Licensed under the Apache License, Version 2.0 (the "License");
# you may not use this file except in compliance with the License.
# You may obtain a copy of the License at
#
# http://www.apache.org/licenses/LICENSE-2.0
#
# Unless required by applicable law or agreed to in writing, software
# distributed under the License is distributed on an "AS IS" BASIS,
# WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
# See the License for the specific language governing permissions and
# limitations under the License.
# ============================================================================

"""Bounded actual FP32 weight-gradient coverage around the frozen diagnostic math."""

from __future__ import annotations

from collections import Counter
from collections.abc import Callable
from contextvars import ContextVar
from functools import partial
import weakref

# The experiment directly exercises the current native Torch implementation.
import torch  # pylint: disable=forbidden-backend-import
from torch.nn import functional  # pylint: disable=forbidden-backend-import

from dense_wgrad_experiment import DenseWeightGradient, NATIVE_LINEAR, npu_accumulate, row_slice


class LongDenseWgrad:
    """Change managed BF16 Linear wgrad only, including the module-owned output head.

    The frozen arithmetic returns a neutral BF16 autograd weight gradient while
    FSDP consumes the explicitly owned FP32 main_grad. TP DTensor owners and bias
    are outside this diagnostic and fail rather than silently claim coverage.
    """

    def __init__(self, model: torch.nn.Module, accumulator: Callable = npu_accumulate) -> None:
        """Install owned module scopes and scalar metadata without retaining activations."""
        self.original = functional.linear
        if self.original is not NATIVE_LINEAR:
            raise RuntimeError("An unrelated functional Linear patch is already installed")
        self.accumulator = accumulator
        self.active = ContextVar('dense_wgrad_module_scope', default=())
        self.records = Counter()
        self.unscoped = Counter()
        self.pending_owners = {}
        self.handles = []
        self.closed = False
        selected = [(name, module) for name, module in model.named_modules()
                    if isinstance(module, torch.nn.Linear)]
        if not selected or any(module.bias is not None for _, module in selected):
            raise ValueError("The diagnostic requires managed bias-free Linear modules")
        self.modules = {name: type(module).__name__ for name, module in selected}
        for name, module in selected:
            self.handles.append(module.register_forward_pre_hook(partial(self._begin, name)))
            self.handles.append(module.register_forward_hook(partial(self._end, name), always_call=True))
        self.replacement = self._linear
        functional.linear = self.replacement

    def _begin(self, name: str, module: torch.nn.Module, _args: tuple) -> None:
        stack = self.active.get()
        if self.closed or len(stack) >= 32:
            raise RuntimeError("Invalid or unbounded Linear module scope")
        self.active.set((*stack, (name, module)))

    def _end(self, name: str, _module: torch.nn.Module, _args: tuple, output: object) -> object:
        stack = self.active.get()
        if not stack or stack[-1][0] != name:
            raise RuntimeError("Dense diagnostic module scope mismatch")
        self.active.set(stack[:-1])
        return output

    def _record(self, signature: tuple, event: str) -> None:
        if self.closed:
            raise RuntimeError("A derivative ran after diagnostic removal")
        self.records[(signature, event)] += 1
        if len(self.records) > 512:
            raise RuntimeError("Dense gradient metadata exceeded its per-step bound")

    def _linear(self, inputs: torch.Tensor, weight: torch.Tensor,
                bias: torch.Tensor | None = None) -> torch.Tensor:
        stack = self.active.get()
        if not stack:
            self.unscoped[str(weight.dtype)] += 1
            return self.original(inputs, weight, bias)
        name, module = stack[-1]
        if bias is not None:
            raise ValueError("Bias gradients are outside this diagnostic")
        if inputs.dtype != torch.bfloat16 or weight.dtype != torch.bfloat16:
            raise ValueError("Selected managed Linear must use BF16 inputs and weights")
        if type(inputs) not in (torch.Tensor, torch.nn.Parameter):
            raise ValueError("Selected managed Linear requires local inputs")
        owner = module.weight
        start = row_slice(owner, weight)
        signature = (name, tuple(inputs.shape), tuple(weight.shape), start)
        self._record(signature, 'forward')
        owner_reference = weakref.ref(owner)
        owner_identity = id(owner)
        self.pending_owners[owner_identity] = owner_reference

        def accumulate(destination: torch.Tensor, gradient: torch.Tensor, values: torch.Tensor) -> None:
            """Count the operation only after the actual FP32 accumulator call succeeds."""
            self.accumulator(destination, gradient, values)
            self._record(signature, 'fp32_wgrad')

        return DenseWeightGradient.apply(inputs, weight, owner, accumulate)

    def finish_step(self) -> dict:
        """Require FSDP to have consumed every observed main_grad, then release metadata."""
        if self.closed or self.active.get():
            raise RuntimeError("Cannot finish a step while a Linear scope is active or closed")
        for reference in self.pending_owners.values():
            owner = reference()
            if owner is not None and (getattr(owner, 'main_grad', None) is not None
                                      or getattr(owner, 'grad_added_to_main_grad', False)):
                raise RuntimeError("FSDP did not consume an observed dense FP32 main_grad")
        result = {'records': [
            {'module': key[0][0], 'input_shape': list(key[0][1]), 'weight_shape': list(key[0][2]),
             'row_start': key[0][3], 'event': key[1], 'calls': count}
            for key, count in sorted(self.records.items())],
                  'unscoped_native_forward': dict(self.unscoped),
                  'checked_owner_buffers': len(self.pending_owners)}
        self.records.clear()
        self.unscoped.clear()
        self.pending_owners.clear()
        return result

    def close(self) -> None:
        """Remove owned hooks and restore only our functional patch."""
        if self.closed:
            return
        self.closed = True
        for handle in self.handles:
            handle.remove()
        self.handles.clear()
        if functional.linear is not self.replacement:
            raise RuntimeError("Functional Linear patch ownership was lost")
        functional.linear = self.original
        if self.active.get():
            raise RuntimeError("Dense diagnostic closed with an active module scope")
