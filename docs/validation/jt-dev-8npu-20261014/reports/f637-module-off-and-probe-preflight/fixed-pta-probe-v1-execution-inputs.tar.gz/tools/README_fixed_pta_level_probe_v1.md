# 固定 PTA level 1 / level 2 单卡算子探针：准备稿，NOT_RUN

本轮仅新增独立文件，没有运行语法/lint、CPU 合约、容器或 NPU，没有修改 guard、训练源码、既有 helper、模块成本实验或已完成的 A/B/C/D。此探针不是修复，也不构成新的 200 步精度结论。四臂 dgrad 结果由主任务单独归档，不能用这里尚未执行的方案解释其根因。

## 固定边界与已确认源码

- HyperParallel：`18602c4524dc664b81b2bad9a7b624455ce1494f`；镜像：`sha256:5f9e677f439d11ab4e7c888f54b142335a27eee7411cbd2ce894a4798a70146d`。
- 已安装 PTA：`2.12.0`，Git `fa0f83fe49d309dcbc31e264e9e6ed6e5dc49d2d`，来自[已读取的 version.py](../references/installed-torch-npu-version.py)。Torch `2.12.0+cpu`、Transformers `5.13.1` 来自[固定基线环境](../runs/r129-f637-fp32-fsdp8-0-200-r4/integration/environment.json)。它们仍须在未来 worker 中逐项核对。
- 精确 PTA [Python setter](../references/torch-npu-fa0f83fe49d3-torch_npu-npu-__init__.py) 第 603–617 行明确警告之后不要再调用 `torch.use_deterministic_algorithms`；第 620–630 行的私有 getter 可能写回状态。新 worker 不调用普通 setter，也不调用任何私有 level getter。`set_deterministic_level` 内部先同步普通 flag、再设置级别，不能把这一内部实现错误说成探针额外覆盖 level 2。[固定官方入口](https://github.com/Ascend/pytorch/blob/fa0f83fe49d309dcbc31e264e9e6ed6e5dc49d2d/torch_npu/npu/__init__.py#L603)
- [Runtime 分支](../references/torch-npu-fa0f83fe49d3-torch_npu-csrc-core-npu-sys_ctrl-npu_sys_ctrl.cpp) 第 52–79 行只接受 0/1/2；level 1 请求 deterministic=1、strong consistency=0，level 2 请求两者均为 1，另有 CANN runtime 版本分支。请求成功不等于 BF16 算子或不同形状已满足强一致性。整个[上游 FLOAT32 测试类](../references/torch-npu-fa0f83fe49d3-test-npu-test_deterministic_level.py)被 skip；这里不引用 level 3。[固定官方 runtime](https://github.com/Ascend/pytorch/blob/fa0f83fe49d309dcbc31e264e9e6ed6e5dc49d2d/torch_npu/csrc/core/npu/sys_ctrl/npu_sys_ctrl.cpp#L52)
- JT [builder](../fixes/latest-jt-validation-f637/hyper_parallel/models/jt_deepseek_v3/adapter/jt_builder.py) 第 125 行会设置普通 deterministic API，因此探针不经过 Trainer 或 builder。它直接构造 [JT 文件](../fixes/latest-jt-validation-f637/hyper_parallel/models/jt_deepseek_v3/modeling_jt_deepseek_v3.py) 第 35 行导入、595–596 行实际使用的 `DeepseekV32RMSNorm`。q_b_proj 的构造维度来自同文件第 325 行及[固定配置](../configs/r129-f637-fp32-fsdp8-0-200-r4.yaml)：`1536 → 128×(128+64)=24576`，不使用 152064 词表 head。

本地还没有已安装 Transformers 的 `modeling_deepseek_v32.py` 源文件。不能在设计稿中把常见 HF RMSNorm 公式当作该镜像的已确认实现，也不能换成 `torch_npu.npu_rms_norm` 后仍称实际 JT 类。未来 worker 将记录真实类 `forward` 源文件、整文件 SHA、函数 SHA、行号、最多四层装饰链与有限源码，并要求两级身份完全相同。已安装 PTA 的公开 allocator-cap 函数仅在当前下载入口的 export 列表中确认；worker 会检查签名并调用其公开 API，无法设置 cap 就失败，不无界继续。**这些运行时检查仍为 NOT_RUN。**

## 两级分别运行的精确矩阵

每级在全新的 Python 进程内完成以下两种原生算子。每个进程只设置一次 level；先完成固定编译/HF32 配置，再调用公开 level setter，再初始化单卡。程序只接受 1 或 2。所有变体使用相同 dispatcher 观察 mode，mode 只转发原算子并记名称/shape/dtype，不保存 Tensor 或修改输出。

| 优先级 | 算子与真实 batch-one 形状 | 数据/梯度/权重 | 比较对象 |
|---|---|---|---|
| 1 | JT `DeepseekV32RMSNorm`，`[1,4096,5120]`，epsilon=`1e-6` | CPU FP32 固定随机数各自舍入到 BF16，再复制 NPU | 原生 forward 与输入梯度 dX |
| 2 | `nn.Linear(1536,24576,bias=False)`，`[1,4096,1536] → [1,4096,24576]` | 同上；权重缩放 0.02 | 原生 forward 与输入梯度 dX |

本轮显式冻结权重，仅请求 `autograd.grad(output, input, grad_outputs)`。这是隔离的 forward/dX 探针，不代表训练时联合 dX/wgrad 的全部调度；不计算或比较 norm weight grad，不把局部分区 wgrad 与全序列混比。没有自定义 dgrad、wgrad、残差、FP32 compute 或 `USE_FP32_ADD` override。HF32 关闭、`CLOSE_MATMUL_K_SHIFT=1`、`jit_compile=False` 在两级相同；普通只读 flag、cube_math_type、相关环境和警告会记录。

每种算子依次完成七次原生 forward/backward 调用，构成以下五组：

1. `reference`：4096 全行结果，保留在当前进程 CPU 内存中，不落大张量文件。
2. `repeat`：相同 4096 全行再算一次，验证本级原生重复性。
3. `partition`：按全局 `[0:2048]` 和 `[2048:4096]` 分成两次，分别对全行参考中相同 global rows 比较。
4. `permutation`：4096 行按固定 CPU permutation 排列；输入和 output gradient 使用同一 permutation。候选第 i 行对比 `reference[permutation[i]]`。
5. `permuted_partition`：置换序列再切为两个 2048 块，仍按每块保存的 global row IDs 取参考。

每个变体运行前验证所有分组合起来恰好覆盖 4096 个 global rows 一次；每次对齐拒绝重复或越界 ID。所有分组误差按元素 count、绝对和、平方和合并，不平均分组均值。汇总包含全部 forward/dX 坐标的 `max_abs`、非零差异数量、平均绝对误差和 RMS 误差，及每次真实 dtype、shape、stride、grad_fn、实际 dispatcher 算子分支。dispatcher 轨迹只能证明 PyTorch 调用分支，不能读出 CANN 内部算法或 strong-consistency runtime 值。

两个进程使用独立 **CPU** generator，相同 seed 和相同生成顺序：RMSNorm 为 `20261016`，Linear 为 `20261017`，两级对应算子完全相同。输入、权重、output gradient、permutation 均保存原始字节 SHA。coordinator 要求两级输入身份与导入源码完全相同。每级与它自己的 native full reference 比较；两级只保存全行结果 SHA 和最多 8×8 个 dX 样本，不凭摘要声称重建了跨级别全量逐元素差。

CPU FP64 oracle 单独列为数学参考：RMSNorm 只取最多八个 global rows 的全部 hidden 列；Linear 只取最多八行与八个输出/dX 列。它基于已经 BF16 舍入的相同操作数，不使用全尺寸 FP64 大 GEMM。RMSNorm 解析 dX 对应理想归一化公式，可能与实际 HF 混合 dtype 中间舍入不同；它不验证 NPU kernel，也不作为 200 步或 level 2 生效门禁。

## 资源与执行控制

- 只允许一个可见 NPU，要求实际设备名包含 `910B3`。入口不改变设备可见性，不创建容器，尚未加入 guard allowlist，也没有生成运行请求。
- 先要求初始化后的全卡已用显存小于 4 GiB，再把本进程 Torch allocator cap 设为 **8 GiB**。原生矩阵中最大单个 BF16 输出约 192 MiB；不同时持有两种算子的 NPU 图，不生成 head 大矩阵。每次完成后采样；allocator 累计 allocated/reserved 达到 12 GiB、采样全卡 used 达到 16 GiB 就终止。
- 目标为单卡实际峰值 **小于 16 GiB**。allocator cap 不覆盖所有驱动/库分配，步骤间采样也不能证明未观察到的物理瞬时峰值。因此未来外层 guard 接入必须补全本任务物理显存监视与超界仅终止本任务的措施，才可把物理峰值上限作为已执行保证；现在不能把理论张量大小当实测峰值。
- worker 从 main 开始在 100 秒软预算边界停止新增算子；coordinator 给每个独立进程 **110 秒**，超时仅对自己创建的进程组 TERM，再最多 3 秒，必要时 KILL 再最多 3 秒。即每级受控等待不超过约 116 秒；退出/超时/仍未回收分别记录，不启动下一等级掩盖失败。操作系统异常的不可中断退出只能由外层守卫继续核验，不能伪造已释放。
- 两级串行；未来外层固定请求总 timeout **600 秒**。coordinator 不在总已用 420 秒后再启动新子进程。两级属于同一次单卡保留窗口，完成后仍需原有全局释放后 1200 秒冷却及所有权检查。当前没有更改守卫或正在使用的调度边界。
- 每份最终 JSON、progress JSONL 上限 2 MiB；算子轨迹最多 128 种明确记录加 overflow 汇总；RMSNorm/Linear 源函数文本分别有截断标记。没有 `.pt`/`.npy` 激活或梯度文件。CPU 只持有当前算子的输入、全行 native 参考、当前候选及分块统计工作区，结束即释放。
- 每次时长包含数据复制、观察和同步，未作无插桩性能测量。此计时只服务预算与定位，不能据此选择“更快训练配方”。

## 新文件与未来检查

- [fixed_pta_probe_common.py](fixed_pta_probe_common.py)：CPU 固定输入、global-row 对齐、分块误差、有限 oracle 和算子轨迹。
- [check_fixed_pta_level_probe.py](check_fixed_pta_level_probe.py)：单级单卡 worker。设置前核对 editable、source SHA、固定 PTA/Transformers/Torch；必须显式提供 `/usr/local/Ascend` 下包含真实 CANN 9.2 版本信息的小文件，设计稿不猜其实际文件名。
- [run_fixed_pta_level_probe.py](run_fixed_pta_level_probe.py)：不导入框架的 coordinator，两级独立子进程、超时/自有进程组回收及对照摘要。
- [check_fixed_pta_probe_cpu.py](check_fixed_pta_probe_cpu.py)：待执行八个 CPU 小测试：种子/全局 RNG 不污染、各变体行覆盖、错误局部坐标必须出现差异、分区统计一次计数、mode 不改变原生小 BF16 Linear forward/dX、FP64 RMSNorm 解析式对 autograd、非有限/shape 错误、worker AST 禁止私有 getter 或覆盖普通 setter。
- [冻结 manifest](../scheduling/fixed-pta-level-probe-v1.manifest.json)：新文件与精确已下载源码 SHA，状态为 `PREPARED_NOT_RUN`。

未来检查顺序：静态语法/lint → 无设备 CPU 小验证 → 精确版本/实际 HF forward 源码与 allocator API 检查 → 两轴 review → 外层单卡/显存/600 秒/20 分钟冷却接入 review → 获准窗口执行。下面仅给命令模板，**尚未执行**：

```bash
/work/venvs/validation/bin/python /work/tools/check_fixed_pta_probe_cpu.py \
  --output /work/evidence/fixed-pta-probe-cpu-v1.json

# 以下版本文件路径必须先从固定镜像只读核实，不能原样使用占位符。
/work/venvs/validation/bin/python /work/tools/run_fixed_pta_level_probe.py \
  --root /work --repo /workspace/hyper-parallel \
  --cann-version-file /usr/local/Ascend/CONFIRMED_VERSION_FILE
```

预计输出目录 `runs/r129-f637-pta-levels12-1npu-v1`，要求不存在并排他创建。结果只会标记完成测量或失败/未完成，不使用训练精度 PASS。若 level 2 对行置换或分区无效、重复本身不一致、API 不支持、实际 RMSNorm dtype 改变或预算不足，原样记录，不切换 level 3、不静默改配方、不重写既有 A/B/C/D 证据。

## 2026-10-16 准备复核更新

用户已取消固定20分钟间隔，历史设计中的1200秒冷却不再适用。当前每轮仍只使用一张空卡，总预算600秒，执行后核对释放；守卫记录物理显存采样最大值，达到16GiB仅停止本任务。采样不能证明未观测到的瞬时峰值。首轮无设备CPU8项通过；安装身份检查发现Ascend入口是软链接，路径边界现改为比较同一解析后的目录，保留首次失败证据并重新验证。

## 最新指示及安装别名复核

用户随后明确恢复每轮实验至少20分钟间隔，以本节及resource-policy-20261016-restored-20min.json为准，前节取消间隔仅为历史记录。镜像的/usr/local/Ascend/ascend-toolkit/latest/version.cfg实际解析到/workspace/Ascend/cann-9.2.0-beta.2/version.cfg；检查分别保存入口别名和解析目标，不再假定目标在入口目录内。两轮CPU8项合约均通过，安装检查的两次路径失败日志保留；NPU仍未执行。
