# Copyright 2026 Huawei Technologies Co., Ltd
#
# Licensed under the Apache License, Version 2.0 (the "License");
# you may not use this file except in compliance with the License.
# You may obtain a copy of the License at
#
# http://www.apache.org/licenses/LICENSE-2.0
#
# Unless required by applicable law or agreed to in writing, software
# distributed under the License is distributed on an "AS IS" BASIS,
# WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
# See the License for the specific language governing permissions and
# limitations under the License.
# ============================================================================

"""Verify installed probe identities inside the fixed image without NPU devices."""

import argparse
import hashlib
import inspect
import json
from pathlib import Path

import torch  # pylint: disable=forbidden-backend-import

from check_fixed_pta_level_probe import check_identity, code_identity, write_new_json


def main() -> None:
    """Record real version files and the actual imported HF and allocator implementations."""
    root = Path('/work')
    paths = []
    for pattern in ('ascend-toolkit/*/version.cfg', 'ascend-toolkit/*/*/version.info',
                    'ascend-toolkit/*/*/ascend_toolkit_install.info',
                    'cann/*/version.cfg', 'cann/*/*/version.info', 'cann/*/*/ascend_toolkit_install.info'):
        paths.extend(Path('/usr/local/Ascend').glob(pattern))
    versions = {}
    for path in paths:
        resolved = path.resolve()
        if resolved.is_file() and resolved.stat().st_size < 65536:
            data = resolved.read_bytes()
            if b'9.2' in data:
                versions[str(path.absolute())] = {'resolved': str(resolved),
                                                'text': data.decode('utf-8', errors='backslashreplace')}
    if not versions:
        raise RuntimeError('No bounded installed CANN 9.2 version evidence found')
    version_file = Path(sorted(versions)[0])
    manifest = root / 'scheduling/fixed-pta-level-probe-v1.manifest.json'
    args = argparse.Namespace(root=root, repo=Path('/workspace/hyper-parallel'),
                              manifest_sha=hashlib.sha256(manifest.read_bytes()).hexdigest(),
                              cann_version_file=version_file)
    identity = check_identity(args)
    setter = torch.npu.set_per_process_memory_fraction
    if 'fraction' not in inspect.signature(setter).parameters:
        raise RuntimeError('Expected public allocator fraction API')
    if torch.npu.is_initialized() or torch.cuda.is_initialized():
        raise RuntimeError('Device-free identity inspection must not initialize an accelerator')
    write_new_json(root / 'evidence/fixed-pta-probe-installed-preflight-v1.json', {
        'status': 'PASS_DEVICE_FREE_IDENTITY_ONLY', 'identity': identity,
        'cann_version_candidates': versions, 'selected_cann_version_file': str(version_file),
        'allocator_api': code_identity(setter), 'accelerator_initialized': False,
    })
    print(json.dumps({'status': 'PASS_DEVICE_FREE_IDENTITY_ONLY', 'cann_version_file': str(version_file)}))


if __name__ == '__main__':
    main()
