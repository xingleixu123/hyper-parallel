# Copyright 2026 Huawei Technologies Co., Ltd
#
# Licensed under the Apache License, Version 2.0 (the "License");
# you may not use this file except in compliance with the License.
# You may obtain a copy of the License at
#
# http://www.apache.org/licenses/LICENSE-2.0
#
# Unless required by applicable law or agreed to in writing, software
# distributed under the License is distributed on an "AS IS" BASIS,
# WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
# See the License for the specific language governing permissions and
# limitations under the License.
# ============================================================================

"""待执行 CPU 小验证：只检查探针身份/统计/数学 oracle，不验证 PTA 或 NPU。"""

import argparse
import ast
import hashlib
import io
import json
from pathlib import Path
import unittest

import torch  # pylint: disable=forbidden-backend-import
from torch.nn import functional  # pylint: disable=forbidden-backend-import

from fixed_pta_probe_common import (
    EPSILON, OperatorTrace, aligned_reference, combine_stats, difference_stats, make_data, oracle_samples,
    row_groups, sample_indices, tensor_sha256,
)


class FixedPtaProbeCpuContract(unittest.TestCase):
    """只运行很小的 CPU 张量，不导入设备 worker 或 JT 模型。"""

    def test_cpu_seed_is_reproducible_and_does_not_change_global_generator(self) -> None:
        """独立进程输入相同的前提由原始 BF16 字节 hash 表达。"""
        before = torch.get_rng_state().clone()
        first = make_data("rmsnorm", rows=8, hidden=16)
        second = make_data("rmsnorm", rows=8, hidden=16)
        self.assertEqual(first.metadata(), second.metadata())
        torch.testing.assert_close(torch.get_rng_state(), before, rtol=0, atol=0)

    def test_all_variants_cover_exact_global_rows(self) -> None:
        """两分区与置换的拼接都必须覆盖相同原始行一次。"""
        data = make_data("linear", rows=8, linear_in=6, linear_out=4)
        for variant in ("reference", "repeat", "partition", "permutation", "permuted_partition"):
            with self.subTest(variant=variant):
                groups = row_groups(data, variant)
                torch.testing.assert_close(torch.cat(groups).sort().values, torch.arange(8), rtol=0, atol=0)
                if "partition" in variant:
                    self.assertEqual([len(group) for group in groups], [4, 4])

    def test_row_alignment_detects_wrong_local_coordinates(self) -> None:
        """错误地把置换局部行对回未置换全局行必须得到非零误差。"""
        reference = torch.arange(32).reshape(8, 4).to(torch.bfloat16)
        order = torch.tensor([5, 4, 3, 2, 1, 0, 7, 6])
        actual = reference.index_select(0, order)
        self.assertEqual(difference_stats(actual, aligned_reference(reference, order))["nonzero_count"], 0)
        self.assertEqual(difference_stats(actual, reference)["nonzero_count"], 32)
        for invalid in (torch.tensor([0, 0]), torch.tensor([-1]), torch.tensor([8])):
            with self.subTest(ids=invalid.tolist()):
                with self.assertRaises(ValueError):
                    aligned_reference(reference, invalid)

    def test_partition_error_statistics_count_elements_once(self) -> None:
        """不等长小分块按 count/sum 合并，而非平均各块均值。"""
        expected = torch.zeros(5)
        actual = torch.tensor([1.0, -2.0, 0.0, 4.0, -3.0])
        combined = combine_stats([difference_stats(actual[:2], expected[:2]),
                                  difference_stats(actual[2:], expected[2:])])
        direct = difference_stats(actual, expected)
        for name in ("count", "nonzero_count", "max_abs", "absolute_sum", "squared_sum", "mean_abs", "rms_abs"):
            self.assertEqual(combined[name], direct[name], name)
        self.assertEqual(combined["count"], 5)
        self.assertEqual(combined["nonzero_count"], 4)

    def test_cpu_native_linear_and_trace_keep_forward_and_dx(self) -> None:
        """小 CPU BF16 算例核对观察 mode 不改变数学，不能据此外推 NPU。"""
        data = make_data("linear", rows=8, linear_in=6, linear_out=4)
        original_input = data.inputs.unsqueeze(0).clone().requires_grad_(True)
        original = functional.linear(original_input, data.weight)
        original_gradient, = torch.autograd.grad(original, original_input, data.output_gradient.unsqueeze(0))
        candidate_input = data.inputs.unsqueeze(0).clone().requires_grad_(True)
        trace = OperatorTrace()
        with trace:
            candidate = functional.linear(candidate_input, data.weight)
            trace.phase = "backward"
            candidate_gradient, = torch.autograd.grad(candidate, candidate_input, data.output_gradient.unsqueeze(0))
        torch.testing.assert_close(candidate, original, rtol=0, atol=0)
        torch.testing.assert_close(candidate_gradient, original_gradient, rtol=0, atol=0)
        expected_gradient = (data.output_gradient.double() @ data.weight.double()).to(torch.bfloat16)
        torch.testing.assert_close(candidate_gradient[0], expected_gradient, rtol=0, atol=0)
        self.assertTrue(trace.metadata()["counts"])
        self.assertFalse(trace.metadata()["truncated"])
        self.assertIsNone(data.weight.grad)

    def test_fp64_rmsnorm_formula_matches_autograd(self) -> None:
        """验证样本 oracle 的解析 dX；这是数学公式，不是未知已安装 HF 实现的替身。"""
        data = make_data("rmsnorm", rows=8, hidden=16)
        inputs = data.inputs.double().requires_grad_(True)
        output = inputs * (inputs.square().mean(-1, keepdim=True) + EPSILON).rsqrt() * data.weight.double()
        gradient, = torch.autograd.grad(output, inputs, data.output_gradient.double())
        result = oracle_samples(data, output.detach(), gradient.detach())
        self.assertLess(result["forward"]["max_abs"], 1e-12)
        self.assertLess(result["input_gradient"]["max_abs"], 1e-12)

    def test_nonfinite_wrong_shape_and_sampling_edges(self) -> None:
        """错误输入不得被统计为零差异。"""
        with self.assertRaises(ValueError):
            difference_stats(torch.tensor([float("nan")]), torch.zeros(1))
        with self.assertRaises(ValueError):
            difference_stats(torch.zeros(2), torch.zeros(1))
        self.assertEqual(sample_indices(1).tolist(), [0])
        self.assertEqual(sample_indices(2).tolist(), [0, 1])
        self.assertNotEqual(tensor_sha256(torch.zeros(2)), tensor_sha256(torch.ones(2)))

    def test_worker_does_not_override_or_observe_level_through_private_getter(self) -> None:
        """只解析 worker AST；CPU 检查不导入它，更不执行设备设置。"""
        worker = Path(__file__).with_name("check_fixed_pta_level_probe.py")
        tree = ast.parse(worker.read_bytes())
        calls = [node.func.attr for node in ast.walk(tree)
                 if isinstance(node, ast.Call) and isinstance(node.func, ast.Attribute)]
        self.assertEqual(calls.count("set_deterministic_level"), 1)
        for forbidden in ("use_deterministic_algorithms", "_get_deterministic_level", "_npu_get_deterministic_level"):
            self.assertNotIn(forbidden, calls)


def main() -> None:
    """排他保存 CPU 结果；无设备环境与无初始化状态均为执行前提。"""
    parser = argparse.ArgumentParser()
    parser.add_argument("--output", type=Path, required=True)
    args = parser.parse_args()
    if args.output.exists():
        raise FileExistsError(args.output)
    npu = getattr(torch, "npu", None)
    if any(Path("/dev").glob("davinci[0-9]*")) or torch.cuda.is_initialized() or (npu and npu.is_initialized()):
        raise RuntimeError("CPU-only contracts require no mapped/initialized accelerator")
    stream = io.StringIO()
    suite = unittest.defaultTestLoader.loadTestsFromTestCase(FixedPtaProbeCpuContract)
    result = unittest.TextTestRunner(stream=stream, verbosity=2).run(suite)
    initialized = torch.cuda.is_initialized() or bool(npu and npu.is_initialized())
    files = [Path(__file__), Path(__file__).with_name("fixed_pta_probe_common.py"),
             Path(__file__).with_name("check_fixed_pta_level_probe.py")]
    payload = {"status": "CPU_ONLY_PASS" if result.wasSuccessful() and not initialized else "FAIL",
               "tests": result.testsRun, "failures": len(result.failures), "errors": len(result.errors),
               "accelerators_initialized": initialized, "torch": torch.__version__, "log": stream.getvalue(),
               "files": {str(path): hashlib.sha256(path.read_bytes()).hexdigest() for path in files},
               "scope": "small CPU observer/alignment/statistics/oracle contracts only; PTA levels and NPU untested"}
    with args.output.open("x", encoding="utf-8", newline="\n") as handle:
        json.dump(payload, handle, ensure_ascii=False, indent=2)
        handle.write("\n")
    print(stream.getvalue())
    raise SystemExit(0 if payload["status"] == "CPU_ONLY_PASS" else 1)


if __name__ == "__main__":
    main()
