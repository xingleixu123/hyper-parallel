# 固定 PTA 单卡一致性探针 v2

目的：隔离主 LM loss 跨拓扑漂移可能涉及的算子行划分敏感性。沿用 v1 的两级、两类算子和全坐标对齐设计，未改变输入、dtype、计算公式或误差统计。每级独立进程依次测原生重复、分区、置换、置换后分区；只测 forward/dX，权重冻结，不比较局部分区 wgrad 与全序列 wgrad。

固定环境：源 `18602c4524dc664b81b2bad9a7b624455ce1494f`，PTA `fa0f83fe49d309dcbc31e264e9e6ed6e5dc49d2d`，镜像 `sha256:5f9e677f439d11ab4e7c888f54b142335a27eee7411cbd2ce894a4798a70146d`，CANN 9.2.0-beta.2 / V100R001C12B086。实际 HF `DeepseekV32RMSNorm.forward` 已在无设备容器内检查：先转 FP32 做行内均方/rsqrt，再转回输入 dtype 并乘权重。完整文件 SHA、函数 SHA 和源码在已安装实现核对凭据中。

v1 的 NPU 预约仅使用129的0号卡，6.296秒后释放。启动器对 `sys.executable` 做 `resolve()`，把 venv 入口替换为系统 Python，子进程在 import torch 时失败；没有算子结果或精度结论。其8个原始文件、释放凭据与22份执行输入已分别收集和冻结，未覆盖。v2 保留当前 venv 入口，并增加符号链接合约测试，以及真实子进程的 Python prefix / Torch 版本 / 导入路径检查。

实际矩阵：RMSNorm `[1,4096,5120]`；Linear `[1,4096,1536]→[1,4096,24576]`，BF16，同一固定 CPU seed 输入。分区为两个2048行；全局行身份显式校验，所有forward/dX坐标参与统计。FP64仅有限CPU数学样本，不当作kernel验证。level1/2独立进程设置，之后不调用普通 deterministic setter 或有副作用的私有 getter。

资源：仅一张空闲卡，单轮600秒、每级110秒加有界自有进程清理；Torch allocator8GiB，宿主容器16GiB/4CPU。每次采样物理使用达到16GiB仅停止本任务；采样最大值不代表可证明的瞬时物理峰值。按用户**最新指示**，释放后至少间隔1200秒，再检查空卡。不得停止其他人的实验。

状态：v2 尚未运行 NPU。CPU和实际子解释器检查需按新manifest重新执行；先前8项CPU通过不替代新增检查。此探针不覆盖完整训练、wgrad、集体通信或200步验收。主LM loss全矩阵200步对齐至0.005以内后先汇报，MTP/aux专项是否继续由用户决定。
