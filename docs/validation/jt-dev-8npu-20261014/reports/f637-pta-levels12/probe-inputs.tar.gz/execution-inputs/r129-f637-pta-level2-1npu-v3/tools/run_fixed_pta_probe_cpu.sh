#!/usr/bin/env bash
set -eo pipefail
source /workspace/env.sh
export OMP_NUM_THREADS=1 PYTHONDONTWRITEBYTECODE=1
cd /workspace/hyper-parallel
python_bin=/work/venvs/validation/bin/python
"$python_bin" /work/tools/check_fixed_pta_probe_cpu.py --output /work/evidence/fixed-pta-probe-cpu-v5.json
"$python_bin" /work/tools/preflight_fixed_pta_probe_cpu.py
