# Copyright 2026 Huawei Technologies Co., Ltd
#
# Licensed under the Apache License, Version 2.0 (the "License");
# you may not use this file except in compliance with the License.
# You may obtain a copy of the License at
#
# http://www.apache.org/licenses/LICENSE-2.0
#
# Unless required by applicable law or agreed to in writing, software
# distributed under the License is distributed on an "AS IS" BASIS,
# WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
# See the License for the specific language governing permissions and
# limitations under the License.
# ============================================================================

"""待接入守卫的轻量入口：两个独立单卡子进程，不导入框架或创建容器。"""

import argparse
import hashlib
import json
import os
from pathlib import Path
import signal
import subprocess
import sys
import time
from typing import Any


CASE = "r129-f637-pta-levels12-1npu-v2"
MANIFEST = "scheduling/fixed-pta-level-probe-v2.manifest.json"


def write_new_json(path: Path, value: Any) -> None:
    """排他写入小型子进程凭据。"""
    with path.open("x", encoding="utf-8", newline="\n") as handle:
        json.dump(value, handle, ensure_ascii=False, indent=2, allow_nan=False)
        handle.write("\n")


def verify_bundle(root: Path) -> str:
    """所有依赖保持冻结；路径不能逃出本任务根。"""
    payload = (root / MANIFEST).read_bytes()
    manifest = json.loads(payload)
    for relative, digest in manifest["files"].items():
        path = (root / relative).resolve()
        if root not in path.parents or hashlib.sha256(path.read_bytes()).hexdigest() != digest:
            raise ValueError(f"Frozen probe file changed: {relative}")
    return hashlib.sha256(payload).hexdigest()


def stop_owned_process(process: subprocess.Popen) -> bool:
    """只终止本次 start_new_session 的子进程组；不搜索或处理其他任务。"""
    # The entry point rejects Windows; these are native Linux process-group APIs.
    for action in (signal.SIGTERM, signal.SIGKILL):  # pylint: disable=no-member
        if process.poll() is not None:
            return True
        try:
            os.killpg(process.pid, action)  # pylint: disable=no-member
        except ProcessLookupError:
            pass
        try:
            process.wait(timeout=3)
            return True
        except subprocess.TimeoutExpired:
            continue
    return process.poll() is not None


def worker_interpreter() -> str:
    """Keep the venv executable alias: resolving its symlink changes Python's environment."""
    path = Path(sys.executable)
    if not path.is_absolute() or not path.is_file():
        raise RuntimeError('The running virtual environment must have an absolute executable path')
    return str(path)


def run_level(args: argparse.Namespace, output: Path, level: int, manifest_sha: str) -> dict[str, Any]:
    """110 秒软超时加最多 6 秒终止等待；完成、超时和残留分开记录。"""
    command = [worker_interpreter(), str(args.root / "tools/check_fixed_pta_level_probe.py"),
               "--root", str(args.root), "--repo", str(args.repo), "--level", str(level),
               "--manifest-sha", manifest_sha, "--cann-version-file", str(args.cann_version_file),
               "--output", str(output / f"level{level}.json")]
    environment = dict(os.environ, CLOSE_MATMUL_K_SHIFT="1", OMP_NUM_THREADS="4", PYTHONDONTWRITEBYTECODE="1",
                       PYTHONHASHSEED="20261016", PYTORCH_NPU_ALLOC_CONF="expandable_segments:True")
    started = time.monotonic()
    timed_out, reaped = False, False
    with (output / f"level{level}.log").open("xb") as log:
        # Popen.__exit__ can wait without a bound; the owned process has explicit bounded cleanup below.
        # pylint: disable=consider-using-with
        process = subprocess.Popen(command, cwd=args.repo, env=environment, stdout=log, stderr=subprocess.STDOUT,
                                   start_new_session=True)
        try:
            process.wait(timeout=110)
            reaped = True
        except subprocess.TimeoutExpired:
            timed_out = True
            reaped = stop_owned_process(process)
        except BaseException:
            stop_owned_process(process)
            raise
    elapsed = time.monotonic() - started
    result = {"level": level, "command": command, "pid": process.pid, "exit_code": process.poll(),
              "timed_out": timed_out, "child_reaped": reaped, "elapsed_seconds": elapsed,
              "within_level_budget": elapsed < 120,
              "visible_devices_changed_by_launcher": False,
              "note": "单个自有子进程退出；卡释放与外部进程归属仍由外层守卫核验。"}
    write_new_json(output / f"level{level}.process.json", result)
    return result


def compare_summaries(output: Path) -> dict[str, Any]:
    """只在版本、代码和 CPU 输入完全相同后并列展示每级自己的布局误差。"""
    reports = [json.loads((output / f"level{level}.json").read_bytes()) for level in (1, 2)]
    if any(row["status"] != "COMPLETED_MEASUREMENT_NOT_TRAINING_PASS" for row in reports):
        raise ValueError("Both level measurements must complete")
    left, right = reports
    if left["identity"] != right["identity"]:
        raise ValueError("Levels used different source, versions or imported RMSNorm implementation")
    comparisons = {}
    for kind in ("rmsnorm", "linear"):
        first, second = left["operators"][kind], right["operators"][kind]
        if first["input_identity"] != second["input_identity"]:
            raise ValueError(f"Different CPU generated inputs: {kind}")
        comparisons[kind] = {
            "native_repeat_exact": {"level1": first["native_repeat_exact"], "level2": second["native_repeat_exact"]},
            "reference_hash_equal_between_levels": {
                name: first[name] == second[name]
                for name in ("reference_forward_sha256", "reference_input_gradient_sha256")},
            "within_level_layout_errors": {
                variant: {f"level{level}": {name: report["operators"][kind]["variants"][variant][name]
                                            for name in ("forward", "input_gradient")}
                          for level, report in zip((1, 2), reports, strict=True)}
                for variant in ("repeat", "partition", "permutation", "permuted_partition")},
        }
    return {"status": "COMPLETED_COMPARISON_NOT_TRAINING_PASS", "operators": comparisons,
            "scope": "分别比较每级 native full-row reference；摘要不能重建跨级别全量逐元素差。",
            "level_reports_sha256": {f"level{level}": hashlib.sha256((output / f"level{level}.json").read_bytes())
                                     .hexdigest() for level in (1, 2)}}


def main() -> None:
    """固定两个级别，不做设备选择；本入口尚未加入 fair guard allowlist。"""
    parser = argparse.ArgumentParser()
    parser.add_argument("--root", type=Path, required=True)
    parser.add_argument("--repo", type=Path, required=True)
    parser.add_argument("--cann-version-file", type=Path, required=True)
    args = parser.parse_args()
    if sys.platform != "linux":
        raise RuntimeError("This prepared launcher is Linux-only")
    args.root, args.repo = args.root.resolve(), args.repo.resolve()
    args.cann_version_file = args.cann_version_file.absolute()
    manifest_sha = verify_bundle(args.root)
    output = args.root / "runs" / CASE
    output.mkdir()
    started = time.monotonic()
    report = {"status": "INCOMPLETE", "case": CASE, "manifest_sha256": manifest_sha, "processes": []}
    try:
        for level in (1, 2):
            if time.monotonic() - started >= 420:
                raise TimeoutError("No new child may start after the total reservation budget")
            result = run_level(args, output, level, manifest_sha)
            report["processes"].append(result)
            if (result["exit_code"] != 0 or result["timed_out"] or not result["child_reaped"]
                    or not result["within_level_budget"]):
                raise RuntimeError(f"Level {level} did not finish cleanly; remaining level not started")
        if verify_bundle(args.root) != manifest_sha:
            raise ValueError("Probe files changed during execution")
        write_new_json(output / "comparison.json", compare_summaries(output))
        if time.monotonic() - started >= 600:
            raise TimeoutError("Total probe elapsed time exceeded 600 seconds")
        report["status"] = "COMPLETED_MEASUREMENT_NOT_TRAINING_PASS"
    except Exception as error:  # pylint: disable=broad-exception-caught
        report["status"] = "FAILED_OR_INCOMPLETE"
        report["error"] = {"type": type(error).__name__, "message": str(error)[:4096]}
    finally:
        report["elapsed_seconds"] = time.monotonic() - started
        report["total_limit_seconds"] = 600
        report["outer_guard_required"] = (
            "one NPU, sampled physical-memory monitor, owned-process release, then at least 1200 seconds between runs")
        write_new_json(output / "coordinator.json", report)
    raise SystemExit(0 if report["status"] == "COMPLETED_MEASUREMENT_NOT_TRAINING_PASS" else 1)


if __name__ == "__main__":
    main()
