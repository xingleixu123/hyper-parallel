#!/usr/bin/env bash
set -eo pipefail
source /workspace/env.sh
test "$#" = 3
test "$1" = r129-f637-pta-level2-1npu-v3
test "$2" = 30377
test "$3" = 1
python_bin=/work/venvs/validation/bin/python
test -x "$python_bin"
export PYTHONDONTWRITEBYTECODE=1 OMP_NUM_THREADS=4
cd /workspace/hyper-parallel
output="/work/runs/$1"
test ! -e "$output"
record_exit() {
  result=$?
  if test -d "$output"; then
    printf '%s\n' "$result" > "$output/EXIT_CODE"
    /usr/bin/git rev-parse HEAD > "$output/source-commit.txt"
    /usr/bin/git diff --binary HEAD > "$output/source.patch"
    cp /work/scheduling/fixed-pta-level-probe-v2.manifest.json "$output/probe-manifest.json"
  fi
}
trap record_exit EXIT
cann_version_file=$("$python_bin" -c 'import json; print(json.load(open("/work/evidence/fixed-pta-probe-installed-preflight-v2.json"))["selected_cann_version_file"])')
"$python_bin" /work/tools/run_fixed_pta_level2_retry.py --root /work --repo /workspace/hyper-parallel \
  --cann-version-file "$cann_version_file"
