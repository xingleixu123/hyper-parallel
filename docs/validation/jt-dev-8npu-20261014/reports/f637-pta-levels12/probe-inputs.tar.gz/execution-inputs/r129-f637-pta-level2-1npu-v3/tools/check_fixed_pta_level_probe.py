# Copyright 2026 Huawei Technologies Co., Ltd
#
# Licensed under the Apache License, Version 2.0 (the "License");
# you may not use this file except in compliance with the License.
# You may obtain a copy of the License at
#
# http://www.apache.org/licenses/LICENSE-2.0
#
# Unless required by applicable law or agreed to in writing, software
# distributed under the License is distributed on an "AS IS" BASIS,
# WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
# See the License for the specific language governing permissions and
# limitations under the License.
# ============================================================================

"""待执行：固定 PTA 的单级别、单卡原生 forward/dX 行一致性探针。"""

from __future__ import annotations

import argparse
import gc
import hashlib
import inspect
import json
import os
from pathlib import Path
import platform
import subprocess
import time
import traceback
from typing import Any
import warnings

# 当前规范要求 Torch 顶层导入；固定仓库的旧 Platform lint 规则已不适用。
# pylint: disable=forbidden-backend-import
import torch
import torch_npu
from torch_npu import version as pta_version
import transformers

from fixed_pta_probe_common import (
    EPSILON, IMAGE, LINEAR_IN, LINEAR_OUT, PTA_COMMIT, SOURCE, OperatorTrace, ProbeData,
    aligned_reference, combine_stats, difference_stats, make_data, oracle_samples, row_groups,
    sample_indices, tensor_metadata, tensor_sha256,
)

import hyper_parallel
from hyper_parallel.models.jt_deepseek_v3 import modeling_jt_deepseek_v3 as jt_model


GIB = 1024 ** 3
MANIFEST = "scheduling/fixed-pta-level-probe-v2.manifest.json"
JT_MODEL_FILE = "hyper_parallel/models/jt_deepseek_v3/modeling_jt_deepseek_v3.py"
JT_MODEL_SHA = "2ddd28910688710ea777f1724fb8aeb8821c6045a01f18f21eea4e92507fd906"


def write_new_json(path: Path, value: Any) -> None:
    """拒绝覆盖旧证据，并限制单份摘要大小。"""
    payload = (json.dumps(value, ensure_ascii=False, indent=2, allow_nan=False) + "\n").encode("utf-8")
    if len(payload) > 2 * 1024 ** 2:
        raise ValueError("Probe summary exceeds the 2 MiB limit")
    with path.open("xb") as handle:
        handle.write(payload)


def code_identity(function: Any) -> dict[str, Any]:
    """保留真实已安装代码身份；有限源码不替代固定镜像的完整来源凭据。"""
    rows = []
    for _ in range(4):
        file = Path(inspect.getsourcefile(function)).resolve()
        source, line = inspect.getsourcelines(function)
        text = "".join(source)
        rows.append({"function": f"{function.__module__}.{function.__qualname__}", "file": str(file),
                     "file_sha256": hashlib.sha256(file.read_bytes()).hexdigest(), "line": line,
                     "function_sha256": hashlib.sha256(text.encode()).hexdigest(),
                     "source": text[:16384], "source_truncated": len(text) > 16384})
        if not hasattr(function, "__wrapped__"):
            break
        function = function.__wrapped__
    return {"decorator_chain": rows}


def check_identity(args: argparse.Namespace) -> dict[str, Any]:
    """在初始化卡之前核对固定源码、镜像内版本和全部准备依赖。"""
    root, repo = args.root.resolve(), args.repo.resolve()
    payload = (root / MANIFEST).read_bytes()
    if hashlib.sha256(payload).hexdigest() != args.manifest_sha:
        raise ValueError("Probe manifest changed after coordinator verification")
    manifest = json.loads(payload)
    for relative, digest in manifest["files"].items():
        path = (root / relative).resolve()
        if root not in path.parents or hashlib.sha256(path.read_bytes()).hexdigest() != digest:
            raise ValueError(f"Probe dependency changed: {relative}")
    commit = subprocess.check_output(["/usr/bin/git", "-C", str(repo), "rev-parse", "HEAD"], text=True).strip()
    status = subprocess.check_output(["/usr/bin/git", "-C", str(repo), "status", "--porcelain=v1"], text=True)
    if commit != SOURCE or status or Path(hyper_parallel.__file__).resolve() != repo / "hyper_parallel/__init__.py":
        raise ValueError("Wrong editable source or modified checkout")
    if Path(jt_model.__file__).resolve() != repo / JT_MODEL_FILE:
        raise ValueError("JT module was imported from a different source")
    if hashlib.sha256((repo / JT_MODEL_FILE).read_bytes()).hexdigest() != JT_MODEL_SHA:
        raise ValueError("JT model file differs from the reviewed fixed commit")
    if pta_version.git_version != PTA_COMMIT or torch_npu.__version__ != "2.12.0":
        raise ValueError("Installed PTA differs from the reviewed exact version")
    if transformers.__version__ != "5.13.1" or torch.__version__ != "2.12.0+cpu":
        raise ValueError("Torch/Transformers versions differ from the fixed training image")
    installed_sources = {}
    for installed, relative in (
            (Path(pta_version.__file__), "references/installed-torch-npu-version.py"),
            (Path(torch_npu.npu.npu_config.__file__), "references/installed-torch-npu-npu-npu_config.py"),
            (Path(inspect.getsourcefile(torch_npu.npu.set_deterministic_level)),
             "references/torch-npu-fa0f83fe49d3-torch_npu-npu-__init__.py")):
        digest = hashlib.sha256(installed.read_bytes()).hexdigest()
        if digest != manifest["files"][relative]:
            raise ValueError(f"Installed PTA Python source differs from the inspected source: {installed}")
        installed_sources[relative] = {"installed_path": str(installed.resolve()), "sha256": digest}
    version_alias = args.cann_version_file.absolute()
    if Path("/usr/local/Ascend") not in version_alias.parents or '..' in version_alias.parts:
        raise ValueError("CANN version evidence must be an explicit file under /usr/local/Ascend")
    # The image's toolkit alias resolves to its versioned installation under /workspace/Ascend.
    version_file = version_alias.resolve()
    if version_file.stat().st_size > 65536:
        raise ValueError("CANN version evidence exceeds its bounded metadata size")
    version_payload = version_file.read_bytes()
    if len(version_payload) > 65536 or b"9.2" not in version_payload:
        raise ValueError("CANN version file must be bounded and identify 9.2")
    return {"source": commit, "jt_model_sha256": JT_MODEL_SHA, "manifest_sha256": args.manifest_sha,
            "expected_image": IMAGE, "actual_image_validation": "external coordinator/guard responsibility",
            "python": platform.python_version(), "torch": torch.__version__, "torch_npu": torch_npu.__version__,
            "pta_git_version": pta_version.git_version, "transformers": transformers.__version__,
            "installed_pta_python_sources": installed_sources,
            "hyper_parallel_import": str(Path(hyper_parallel.__file__).resolve()),
            "cann_version_file": {"path": str(version_file), "installation_alias": str(version_alias),
                                  "sha256": hashlib.sha256(version_payload).hexdigest(),
                                  "text": version_payload.decode("utf-8", errors="backslashreplace")},
            "rmsnorm_forward": code_identity(jt_model.DeepseekV32RMSNorm.forward),
            "linear_forward": code_identity(torch.nn.Linear.forward),
            "pta_setter": code_identity(torch_npu.npu.set_deterministic_level)}


def configure_level(level: int) -> dict[str, Any]:
    """每进程只调用一次公开 level setter，之后不再设置普通 deterministic API。"""
    if torch.npu.is_initialized() or torch.cuda.is_initialized() or torch.npu.device_count() != 1:
        raise RuntimeError("Probe requires exactly one visible, initially uninitialized NPU")
    if os.environ.get("CLOSE_MATMUL_K_SHIFT") != "1":
        raise ValueError("CLOSE_MATMUL_K_SHIFT must be fixed before process import")
    before = torch.are_deterministic_algorithms_enabled()
    torch.npu.set_compile_mode(jit_compile=False)
    torch.npu.matmul.allow_hf32 = False
    with warnings.catch_warnings(record=True) as recorded:
        warnings.simplefilter("always")
        torch_npu.npu.set_deterministic_level(level)
    torch.npu.set_device(0)
    device_name = torch.npu.get_device_name(0)
    if "910B3" not in device_name:
        raise RuntimeError(f"Expected the fixed Ascend 910B3 hardware, got {device_name}")
    free, total = torch.npu.mem_get_info(0)
    if total - free >= 4 * GIB:
        raise RuntimeError("Initial device usage must be below 4 GiB for the bounded probe")
    setter = torch.npu.set_per_process_memory_fraction
    if "fraction" not in inspect.signature(setter).parameters:
        raise RuntimeError("Unverified public allocator limit API; refusing an unbounded fallback")
    fraction = min(1.0, (8 * GIB) / total)
    setter(fraction, device=0)
    torch.npu.reset_peak_memory_stats(0)
    if torch.npu.matmul.allow_hf32 is not False or not torch.are_deterministic_algorithms_enabled():
        raise RuntimeError("Public deterministic/HF32 state does not match the request")
    return {"requested_level": level, "setter_returned": True, "ordinary_flag_before": before,
            "ordinary_flag_after": torch.are_deterministic_algorithms_enabled(),
            "effective_runtime_level": "UNOBSERVABLE: no read-only public getter in inspected source",
            "probe_called_private_level_getter": False, "probe_called_ordinary_setter_after_level": False,
            "hf32": torch.npu.matmul.allow_hf32, "compile_mode_requested": "jit_compile=False",
            "cube_math_type_observed": str(torch.npu.matmul.cube_math_type),
            "ordinary_warn_only": torch.is_deterministic_algorithms_warn_only_enabled(),
            "allocator_cap_bytes": 8 * GIB, "allocator_fraction": fraction,
            "allocator_limit_api": code_identity(setter), "initial_used_device_bytes": total - free,
            "device_name": device_name,
            "environment": {name: os.environ.get(name) for name in (
                "ASCEND_HOME_PATH", "ASCEND_OPP_PATH", "LD_LIBRARY_PATH", "PYTHONPATH", "ASCEND_VISIBLE_DEVICES",
                "ASCEND_RT_VISIBLE_DEVICES", "CLOSE_MATMUL_K_SHIFT", "PYTORCH_NPU_ALLOC_CONF", "OMP_NUM_THREADS")},
            "warnings": [str(item.message)[:1024] for item in recorded[:16]],
            "warnings_truncated": len(recorded) > 16}


def resource_snapshot(started: float) -> dict[str, Any]:
    """同步采样及累计 allocator 峰值；物理显存采样不是瞬时全程峰值证明。"""
    torch.npu.synchronize()
    free, total = torch.npu.mem_get_info(0)
    allocated, reserved = torch.npu.max_memory_allocated(0), torch.npu.max_memory_reserved(0)
    used = total - free
    if max(allocated, reserved) >= 12 * GIB or used >= 16 * GIB:
        raise RuntimeError(f"Probe memory bound exceeded: allocated={allocated}, reserved={reserved}, used={used}")
    elapsed = time.monotonic() - started
    if elapsed >= 100:
        raise TimeoutError(f"Probe soft budget reached at {elapsed:.6f} seconds before the next operation")
    return {"elapsed_seconds": elapsed, "max_allocated_bytes": allocated, "max_reserved_bytes": reserved,
            "sampled_device_used_bytes": used}


def make_module(data: ProbeData) -> torch.nn.Module:
    """直接使用 JT 的类身份，避开会覆盖 deterministic 设置的 Trainer/builder。"""
    if data.kind == "rmsnorm":
        module = jt_model.DeepseekV32RMSNorm(data.inputs.shape[1], eps=EPSILON)
        module = module.to(device="npu:0", dtype=torch.bfloat16)
        with torch.no_grad():
            module.weight.copy_(data.weight)
        module.weight.requires_grad_(False)
    else:
        module = torch.nn.Linear(LINEAR_IN, LINEAR_OUT, bias=False, device="meta", dtype=torch.bfloat16)
        module.weight = torch.nn.Parameter(data.weight.to("npu:0"), requires_grad=False)
    return module.train()


def native_call(module: torch.nn.Module, data: ProbeData,
                global_rows: torch.Tensor) -> tuple[torch.Tensor, torch.Tensor, dict[str, Any]]:
    """原生 BF16 forward 与仅 dX 的 autograd；不计算或比较 wgrad。"""
    begin = time.monotonic()
    inputs = data.inputs.index_select(0, global_rows).unsqueeze(0).to("npu:0").requires_grad_(True)
    gradient = data.output_gradient.index_select(0, global_rows).unsqueeze(0).to("npu:0")
    trace = OperatorTrace()
    with trace:
        output = module(inputs)
        output_meta = tensor_metadata(output)
        grad_fn = type(output.grad_fn).__name__
        trace.phase = "backward"
        input_gradient, = torch.autograd.grad(output, inputs, grad_outputs=gradient)
    torch.npu.synchronize()
    if output.shape != gradient.shape or input_gradient.shape != inputs.shape:
        raise ValueError(f"Native shapes differ: output={output.shape}, dY={gradient.shape}, "
                         f"dX={input_gradient.shape}, input={inputs.shape}")
    if output.dtype != torch.bfloat16 or input_gradient.dtype != torch.bfloat16:
        raise ValueError(f"Actual output={output.dtype}, dX={input_gradient.dtype}; expected native BF16")
    result = output.detach()[0].cpu(), input_gradient.detach()[0].cpu()
    details = {"global_row_count": global_rows.numel(), "global_rows_sha256": tensor_sha256(global_rows),
               "global_rows_first_last": [int(global_rows[0]), int(global_rows[-1])],
               "input": tensor_metadata(inputs), "weight": tensor_metadata(module.weight),
               "output_gradient": tensor_metadata(gradient), "output": output_meta,
               "input_gradient": tensor_metadata(input_gradient), "forward_grad_fn": grad_fn,
               "weight_requires_grad": False, "trace": trace.metadata(),
               "elapsed_seconds_including_transfers": time.monotonic() - begin}
    return result[0], result[1], details


def run_operator(kind: str, started: float, journal: Any) -> dict[str, Any]:
    """先保留原生全行参考，再逐组比较；每次只保留当前候选 CPU 结果。"""
    data = make_data(kind)
    identity = data.metadata()
    journal({"stage": f"{kind}/cpu-inputs", "input_identity": identity})
    module = make_module(data)
    all_rows = row_groups(data, "reference")[0]
    forward, input_gradient, native_metadata = native_call(module, data, all_rows)
    resource = resource_snapshot(started)
    journal({"stage": f"{kind}/reference", "resource": resource, "call": native_metadata})
    rows = sample_indices(data.inputs.shape[0])
    columns = sample_indices(data.inputs.shape[1])
    result = {"input_identity": identity, "reference": native_metadata,
              "representative_fqn": "model.layers.0.input_layernorm" if kind == "rmsnorm"
              else "model.layers.0.self_attn.q_b_proj",
              "reference_forward_sha256": tensor_sha256(forward),
              "reference_input_gradient_sha256": tensor_sha256(input_gradient),
              "input_gradient_samples": {"global_rows": rows.tolist(), "columns": columns.tolist(),
                                         "values": input_gradient.index_select(0, rows).index_select(1, columns)
                                         .float().tolist()},
              "sampled_fp64_oracle": oracle_samples(data, forward, input_gradient), "variants": {}}
    for variant in ("repeat", "partition", "permutation", "permuted_partition"):
        forward_stats, gradient_stats, calls = [], [], []
        groups = row_groups(data, variant)
        if not torch.equal(torch.cat(groups).sort().values, all_rows):
            raise ValueError("Candidate row groups do not cover each global row exactly once")
        for global_rows in groups:
            resource_snapshot(started)
            actual, actual_gradient, details = native_call(module, data, global_rows)
            journal({"stage": f"{kind}/{variant}/native-call", "call": details})
            forward_stats.append(difference_stats(actual, aligned_reference(forward, global_rows)))
            gradient_stats.append(difference_stats(actual_gradient, aligned_reference(input_gradient, global_rows)))
            calls.append(details)
            del actual, actual_gradient
        result["variants"][variant] = {"forward": combine_stats(forward_stats),
                                       "input_gradient": combine_stats(gradient_stats), "calls": calls,
                                       "global_row_coverage_exact": True,
                                       "resource": resource_snapshot(started)}
        journal({"stage": f"{kind}/{variant}", "summary": result["variants"][variant]})
    result["native_repeat_exact"] = all(result["variants"]["repeat"][name]["nonzero_count"] == 0
                                         for name in ("forward", "input_gradient"))
    del module, data, forward, input_gradient
    gc.collect()
    torch.npu.empty_cache()
    return result


def main() -> None:
    """仅由独立进程 coordinator 调用；失败和未完成不冒称精度通过。"""
    parser = argparse.ArgumentParser()
    parser.add_argument("--root", type=Path, required=True)
    parser.add_argument("--repo", type=Path, required=True)
    parser.add_argument("--level", type=int, choices=(1, 2), required=True)
    parser.add_argument("--manifest-sha", required=True)
    parser.add_argument("--cann-version-file", type=Path, required=True)
    parser.add_argument("--output", type=Path, required=True)
    args = parser.parse_args()
    output = args.output.resolve()
    if args.root.resolve() not in output.parents or output.exists() or not output.parent.is_dir():
        raise ValueError("Output must be a new file inside this task root")
    progress = output.with_suffix(".progress.jsonl")
    started = time.monotonic()
    report = {"status": "INCOMPLETE", "level": args.level, "operators": {},
              "scope": ("single-NPU synthetic native BF16 forward/dX only; "
                        "no wgrad, collectives, or training acceptance")}
    with progress.open("x", encoding="utf-8") as stream:
        def journal(row: dict[str, Any]) -> None:
            """有限进度落盘，超时进程仍留下已完成边界。"""
            line = json.dumps(row, ensure_ascii=False, allow_nan=False) + "\n"
            if len(line.encode()) > 256 * 1024 or stream.tell() + len(line.encode()) > 2 * 1024 ** 2:
                raise ValueError("Progress evidence exceeded its bound")
            stream.write(line)
            stream.flush()

        try:
            report["identity"] = check_identity(args)
            journal({"stage": "identity-checked", "identity": report["identity"]})
            report["settings"] = configure_level(args.level)
            journal({"stage": "configured", "settings": report["settings"]})
            for kind in ("rmsnorm", "linear"):
                report["operators"][kind] = run_operator(kind, started, journal)
            report["resource"] = resource_snapshot(started)
            report["status"] = "COMPLETED_MEASUREMENT_NOT_TRAINING_PASS"
        except Exception as error:  # pylint: disable=broad-exception-caught
            report["status"] = "FAILED_OR_INCOMPLETE"
            report["error"] = {"type": type(error).__name__, "message": str(error)[:4096],
                               "traceback": traceback.format_exc(limit=6)[-8192:]}
        finally:
            report["elapsed_seconds"] = time.monotonic() - started
            write_new_json(output, report)
    raise SystemExit(0 if report["status"] == "COMPLETED_MEASUREMENT_NOT_TRAINING_PASS" else 1)


if __name__ == "__main__":
    main()
