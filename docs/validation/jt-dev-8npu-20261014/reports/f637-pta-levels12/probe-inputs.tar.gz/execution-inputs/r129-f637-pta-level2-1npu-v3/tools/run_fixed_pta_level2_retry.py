# Copyright 2026 Huawei Technologies Co., Ltd
#
# Licensed under the Apache License, Version 2.0 (the "License");
# you may not use this file except in compliance with the License.
# You may obtain a copy of the License at
#
# http://www.apache.org/licenses/LICENSE-2.0
#
# Unless required by applicable law or agreed to in writing, software
# distributed under the License is distributed on an "AS IS" BASIS,
# WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
# See the License for the specific language governing permissions and
# limitations under the License.
# ============================================================================

"""Retry only the interrupted level-2 measurement with the unchanged v2 worker."""

import argparse
import json
from pathlib import Path
import sys
import time

from run_fixed_pta_level_probe import run_level, verify_bundle, write_new_json


CASE = "r129-f637-pta-level2-1npu-v3"


def main() -> None:
    """Run one bounded child; retain failure status without merging interrupted measurements."""
    parser = argparse.ArgumentParser()
    parser.add_argument("--root", type=Path, required=True)
    parser.add_argument("--repo", type=Path, required=True)
    parser.add_argument("--cann-version-file", type=Path, required=True)
    args = parser.parse_args()
    if sys.platform != "linux":
        raise RuntimeError("The fixed probe launcher requires Linux")
    args.root, args.repo = args.root.resolve(), args.repo.resolve()
    args.cann_version_file = args.cann_version_file.absolute()
    manifest_sha = verify_bundle(args.root)
    output = args.root / "runs" / CASE
    output.mkdir()
    started = time.monotonic()
    report = {"status": "INCOMPLETE", "case": CASE, "manifest_sha256": manifest_sha, "processes": [],
              "scope": "fresh level-2 measurement; no samples reused from the interrupted reservation",
              "reference_case": "r129-f637-pta-levels12-1npu-v2"}
    try:
        result = run_level(args, output, 2, manifest_sha)
        report["processes"].append(result)
        if (result["exit_code"] != 0 or result["timed_out"] or not result["child_reaped"]
                or not result["within_level_budget"]):
            raise RuntimeError("Level 2 did not finish cleanly")
        measurement = json.loads((output / "level2.json").read_bytes())
        if measurement["status"] != "COMPLETED_MEASUREMENT_NOT_TRAINING_PASS":
            raise RuntimeError("The measurement is incomplete")
        if verify_bundle(args.root) != manifest_sha:
            raise ValueError("Frozen worker inputs changed during execution")
        report["status"] = "COMPLETED_MEASUREMENT_NOT_TRAINING_PASS"
    except Exception as error:  # pylint: disable=broad-exception-caught
        report["status"] = "FAILED_OR_INCOMPLETE"
        report["error"] = {"type": type(error).__name__, "message": str(error)[:4096]}
    finally:
        report["elapsed_seconds"] = time.monotonic() - started
        report["total_limit_seconds"] = 600
        report["outer_guard_required"] = "one NPU; owned-process release; then at least 1200 seconds between runs"
        write_new_json(output / "coordinator.json", report)
    raise SystemExit(0 if report["status"] == "COMPLETED_MEASUREMENT_NOT_TRAINING_PASS" else 1)


if __name__ == "__main__":
    main()
