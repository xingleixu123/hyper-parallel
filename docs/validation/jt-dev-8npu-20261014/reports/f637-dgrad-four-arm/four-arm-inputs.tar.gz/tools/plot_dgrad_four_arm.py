# Copyright 2026 Huawei Technologies Co., Ltd
#
# Licensed under the Apache License, Version 2.0 (the "License");
# you may not use this file except in compliance with the License.
# You may obtain a copy of the License at
#
# http://www.apache.org/licenses/LICENSE-2.0
#
# Unless required by applicable law or agreed to in writing, software
# distributed under the License is distributed on an "AS IS" BASIS,
# WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
# See the License for the specific language governing permissions and
# limitations under the License.
# ============================================================================

"""Show matched cross-layout diagnostics without implying a 200-step pass."""

import hashlib
import json
from pathlib import Path

import matplotlib

matplotlib.use('Agg')
import matplotlib.pyplot as plt  # pylint: disable=wrong-import-position

ROOT = Path(__file__).resolve().parents[1]


def main() -> None:
    """Plot only A-B and C-D; keep within-layout interventions separate."""
    scalar_path = ROOT / 'evidence/f637-dgrad-four-arm-scalar-comparison.json'
    activation_path = ROOT / 'evidence/f637-dgrad-four-arm-activation-comparison.json'
    scalar = json.loads(scalar_path.read_bytes())['comparisons']
    activation = json.loads(activation_path.read_bytes())['comparisons']
    plt.rcParams.update({'font.family': 'Microsoft YaHei', 'font.size': 11, 'svg.fonttype': 'none',
                         'axes.spines.top': False, 'axes.spines.right': False})
    figure, axes = plt.subplots(1, 3, figsize=(14.8, 7.4))
    for axis, (key, divisor, label) in zip(axes, [
            ('lm', 1.0, 'LM loss'), ('mtp', 0.3, 'MTP loss（日志除以 0.3）'),
            ('aux', 0.0001, 'Aux loss（日志除以 0.0001）')]):
        for name, title, color in [('native_layout', 'A−B：原生 dgrad', '#126B68'),
                                    ('fp32_layout', 'C−D：FP32 dgrad', '#B55B4F')]:
            report = scalar[name]
            assert report['steps'] == [1, 3] and report['ranks'] == 8
            values = [value / divisor for value in report['step_errors']['training/foundation_loss/' + key]]
            axis.plot([1, 2, 3], values, marker='o', linewidth=2, color=color, label=title)
        axis.set_title(label, loc='left', weight='bold', pad=15)
        axis.set_xticks([1, 2, 3])
        axis.set_xlabel('训练步')
        axis.set_ylim(bottom=0)
        axis.ticklabel_format(axis='y', style='sci', scilimits=(-3, -3), useMathText=True)
        axis.grid(alpha=0.18)
    axes[0].set_ylabel('逐步全部 8 个 rank 最大绝对差')
    axes[0].legend(loc='upper left', frameon=False, fontsize=10)
    native = activation['native_layout']['summary']
    changed = activation['fp32_layout']['summary']
    assert native['forward']['different_coordinates'] == changed['forward']['different_coordinates'] == 0
    figure.text(0.045, 0.945, 'Linear dgrad 改成 FP32，CP2 跨布局误差未整体改善', fontsize=20, weight='bold')
    figure.text(0.045, 0.897, '129 · CANN 9.2.0-beta.2 · 18602c4 · 独立四组，各 3 步；不满足 200 步验收',
                fontsize=11, color='#475569')
    figure.text(0.045, 0.203,
                f"首步采样梯度：{native['gradient']['coordinates']:,} 个匹配坐标；"
                f"非零差异数 {native['gradient']['different_coordinates']:,} → "
                f"{changed['gradient']['different_coordinates']:,}。\n"
                f"最大梯度绝对差 {native['gradient']['max_abs']:.8g} → "
                f"{changed['gradient']['max_abs']:.8g}；"
                f"前向 {native['forward']['coordinates']:,} 个采样坐标两组均相同。",
                fontsize=11, linespacing=1.65)
    figure.text(0.045, 0.075,
                '梯度与前向只覆盖首步 stride128 的已记录模块边界；不是全张量相等或已定位首个致因算子。\n'
                '每个跨布局比较使用相同数值配方；A−C、B−D 的布局内干预单独见报告。三步诊断不用于生产性能排序。',
                fontsize=10, color='#475569', linespacing=1.6)
    figure.subplots_adjust(left=0.09, right=0.975, top=0.76, bottom=0.38, wspace=0.4)
    outputs = []
    for extension in ('png', 'svg'):
        path = ROOT / 'figures' / ('f637-dgrad-four-arm-zh.' + extension)
        if path.exists():
            raise FileExistsError(path)
        figure.savefig(path, dpi=180)
        outputs.append({'path': path.relative_to(ROOT).as_posix(),
                        'sha256': hashlib.sha256(path.read_bytes()).hexdigest()})
    plt.close(figure)
    record = {'inputs': {path.relative_to(ROOT).as_posix(): hashlib.sha256(path.read_bytes()).hexdigest()
                         for path in (scalar_path, activation_path, Path(__file__))}, 'figures': outputs}
    with (ROOT / 'evidence/f637-dgrad-four-arm-figure-source.json').open('x', encoding='utf-8') as handle:
        handle.write(json.dumps(record, ensure_ascii=False, indent=2) + '\n')
    print(json.dumps(record, ensure_ascii=False))


if __name__ == '__main__':
    main()
