# Copyright 2026 Huawei Technologies Co., Ltd
#
# Licensed under the Apache License, Version 2.0 (the "License");
# you may not use this file except in compliance with the License.
# You may obtain a copy of the License at
#
# http://www.apache.org/licenses/LICENSE-2.0
#
# Unless required by applicable law or agreed to in writing, software
# distributed under the License is distributed on an "AS IS" BASIS,
# WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
# See the License for the specific language governing permissions and
# limitations under the License.
# ============================================================================

"""Report three-step scalar differences without relaxing final acceptance."""

import hashlib
import json
from pathlib import Path

from analyze_dgrad_four_arm import CASES, PAIRS, ROOT
from strict_compare_runs import audit


def main() -> None:
    """Keep the strict comparator's 200-step failure visible in every pair."""
    comparisons = {}
    for name, (left, right) in PAIRS.items():
        reference, candidate = (ROOT / 'runs' / CASES[key] for key in (left, right))
        manifests = [ROOT / 'evidence' / (CASES[key].removeprefix('r129-') + '-evidence-manifest.json')
                     for key in (left, right)]
        result = audit(reference, candidate, 1, 3, reference_manifest=manifests[0],
                       candidate_manifest=manifests[1])
        if result['findings'] != ['Final acceptance requires exactly 200 consecutive steps']:
            raise ValueError(result['findings'])
        if result['input_mismatch_count'] or result['initial_mismatches']:
            raise ValueError('Input or initial state mismatch')
        comparisons[name] = result
    result = {
        'scope': '全8rank的1–3步标量差异；不满足200步验收，严格比较器未改动。',
        'comparison_order': 'A-B/C-D分别为原生/FP32 dgrad配方内跨布局；A-C/B-D为布局内干预。',
        'unweighted_note': 'MTP与aux由日志值分别除以0.3和0.0001还原，不是单独采集的加权前张量。',
        'performance_note': '高频诊断采集与FP32临时张量使这些短跑不适合作生产性能比较。',
        'auditor_sha256': hashlib.sha256(Path(__file__).read_bytes()).hexdigest(),
        'strict_comparator_sha256': hashlib.sha256((ROOT / 'tools/strict_compare_runs.py').read_bytes()).hexdigest(),
        'comparisons': comparisons,
    }
    output = ROOT / 'evidence/f637-dgrad-four-arm-scalar-comparison.json'
    with output.open('x', encoding='utf-8', newline='\n') as handle:
        handle.write(json.dumps(result, ensure_ascii=False, indent=2) + '\n')
    print(json.dumps({name: {'errors': value['errors'], 'unweighted': value['unweighted_error_diagnostics']}
                      for name, value in comparisons.items()}, ensure_ascii=False))


if __name__ == '__main__':
    main()
