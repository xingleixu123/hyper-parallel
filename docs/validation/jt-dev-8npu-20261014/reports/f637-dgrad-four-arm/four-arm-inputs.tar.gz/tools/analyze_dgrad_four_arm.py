# Copyright 2026 Huawei Technologies Co., Ltd
#
# Licensed under the Apache License, Version 2.0 (the "License");
# you may not use this file except in compliance with the License.
# You may obtain a copy of the License at
#
# http://www.apache.org/licenses/LICENSE-2.0
#
# Unless required by applicable law or agreed to in writing, software
# distributed under the License is distributed on an "AS IS" BASIS,
# WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
# See the License for the specific language governing permissions and
# limitations under the License.
# ============================================================================

"""Compare four diagnostic arms one input batch at a time, with bounded memory."""

import argparse
from collections import defaultdict
from collections.abc import Iterator
import hashlib
import json
import math
from pathlib import Path

from audit_dgrad_short_run import check_sample


ROOT = Path(__file__).resolve().parents[1]
CASES = {
    'A': 'r129-f637-dgrad-fsdp8-native-3',
    'B': 'r129-f637-dgrad-cp2-native-3',
    'C': 'r129-f637-dgrad-fsdp8-fp32-3',
    'D': 'r129-f637-dgrad-cp2-fp32-3',
}
PAIRS = {'native_layout': ('A', 'B'), 'fp32_layout': ('C', 'D'),
         'fsdp_intervention': ('A', 'C'), 'cp_intervention': ('B', 'D')}


def index_arm(case: str) -> dict:
    """Index line offsets, verifying each activation file against its manifest."""
    directory = ROOT / 'runs' / case
    manifest_path = ROOT / 'evidence' / (case.removeprefix('r129-') + '-evidence-manifest.json')
    manifest_bytes = manifest_path.read_bytes()
    entries = {entry['path']: entry for entry in json.loads(manifest_bytes)['files']}
    batches = defaultdict(list)
    files = []
    if (directory / 'EXIT_CODE').read_text().strip() != '0':
        raise ValueError(f'Incomplete diagnostic: {case}')
    for rank in range(8):
        path = directory / f'activations-rank{rank}.jsonl'
        entry = entries[path.relative_to(ROOT).as_posix()]
        digest = hashlib.sha256()
        size = 0
        with path.open('rb') as handle:
            while line := handle.readline():
                digest.update(line)
                row = json.loads(line)
                if row['rank'] != rank or not row['batch_sha256']:
                    raise ValueError('Invalid activation rank or batch')
                check_sample(row)
                batches[row['batch_sha256']].append((path, size, len(line)))
                size += len(line)
        if size != entry['bytes'] or digest.hexdigest() != entry['sha256']:
            raise ValueError('Activation file differs from collection manifest')
        files.append(entry)
    if len(batches) != 8:
        raise ValueError('Expected eight unique logical input batches')
    return {'case': case, 'batches': dict(batches), 'files': files,
            'manifest_sha256': hashlib.sha256(manifest_bytes).hexdigest()}


def read_indexed(entry: tuple) -> dict:
    """Read one previously indexed bounded record."""
    path, offset, length = entry
    with path.open('rb') as handle:
        handle.seek(offset)
        return json.loads(handle.read(length))


def coordinates(row: dict) -> Iterator[tuple[tuple[int, int, int], float]]:
    """Yield sampled global coordinates without retaining whole tensor data."""
    cursor = 0
    for batch in range(row['sample_shape'][0]):
        for position in row['positions']:
            for feature in row['features']:
                yield (batch, position, feature), row['values'][cursor]
                cursor += 1


def logical_signature(row: dict) -> tuple:
    """Keep dtype and full logical dimensions while allowing CP local sequence shards."""
    return row['dtype'], row['shape'][0], row['global_sequence'], row['shape'][2]


def reference_batch(entries: list) -> dict:
    """Build at most one logical batch's coordinate map, rejecting replicas."""
    groups = {}
    for entry in entries:
        row = read_indexed(entry)
        key = (row['module'], row['call'], row['stage'])
        group = groups.setdefault(key, {'signature': logical_signature(row), 'values': {}})
        if group['signature'] != logical_signature(row):
            raise ValueError('Reference partitions have different logical tensor signatures')
        values = group['values']
        for coordinate, value in coordinates(row):
            if coordinate in values:
                raise ValueError('Duplicated reference coordinate')
            values[coordinate] = value
    return groups


def compare_batch(reference: dict, entries: list, totals: dict) -> None:
    """Consume matched candidate coordinates exactly once and add error moments."""
    for key in reference:
        totals.setdefault(key, {'count': 0, 'different': 0, 'max_abs': 0.0,
                                'sum_delta2': 0.0, 'sum_reference2': 0.0})
    for entry in entries:
        row = read_indexed(entry)
        key = (row['module'], row['call'], row['stage'])
        if key not in reference:
            raise ValueError('Unexpected candidate module/call/stage')
        if reference[key]['signature'] != logical_signature(row):
            raise ValueError('Candidate dtype or logical tensor shape differs')
        remaining = reference[key]['values']
        target = totals[key]
        for coordinate, value in coordinates(row):
            if coordinate not in remaining:
                raise ValueError('Unexpected or duplicated candidate coordinate')
            expected = remaining.pop(coordinate)
            delta = value - expected
            target['count'] += 1
            target['different'] += delta != 0
            target['max_abs'] = max(target['max_abs'], abs(delta))
            target['sum_delta2'] += delta * delta
            target['sum_reference2'] += expected * expected
    if any(group['values'] for group in reference.values()):
        raise ValueError('Missing candidate module/call/stage coordinates')


def compare_pair(reference: dict, candidate: dict) -> dict:
    """Compare equal input cohorts; strict coordinates make coverage explicit."""
    if set(reference['batches']) != set(candidate['batches']):
        raise ValueError('Logical input batches differ')
    totals = {}
    for batch, entries in reference['batches'].items():
        values = reference_batch(entries)
        compare_batch(values, candidate['batches'][batch], totals)
    rows = []
    for key, value in totals.items():
        rows.append({'module': key[0], 'call': key[1], 'stage': key[2], **value,
                     'relative_l2': math.sqrt(value['sum_delta2'] / value['sum_reference2'])
                     if value['sum_reference2'] else None})
    summary = {}
    for category in ('forward', 'gradient'):
        selected = [row for row in rows if ('gradient' in row['stage']) == (category == 'gradient')]
        summary[category] = {'groups': len(selected), 'different_groups': sum(row['different'] > 0 for row in selected),
                             'coordinates': sum(row['count'] for row in selected),
                             'different_coordinates': sum(row['different'] for row in selected),
                             'max_abs': max(row['max_abs'] for row in selected)}
    return {'reference': reference['case'], 'candidate': candidate['case'], 'unique_batches': len(reference['batches']),
            'summary': summary, 'groups': rows, 'missing_coordinates': 0, 'duplicate_coordinates': 0}


def main() -> None:
    """Write separate layout and intervention effects, without a final PASS claim."""
    parser = argparse.ArgumentParser()
    parser.add_argument('--output', required=True, type=Path)
    args = parser.parse_args()
    if args.output.resolve().parent != ROOT / 'evidence':
        raise ValueError('Output must stay in task evidence')
    arms = {name: index_arm(case) for name, case in CASES.items()}
    comparisons = {name: compare_pair(arms[left], arms[right]) for name, (left, right) in PAIRS.items()}
    result = {'scope': '四臂首步stride128采样；并非全张量或200步验收。A/B为原生，C/D为FP32 Linear dgrad。',
              'comparison_order': 'A-B与C-D为跨布局；A-C与B-D为各布局内干预；不可混作同配方参考。',
              'coverage': '逻辑dtype/全局尺寸匹配，允许CP局部序长不同；每组采样坐标恰好一次，缺失或重复均拒绝。',
              'auditor_sha256': hashlib.sha256(Path(__file__).read_bytes()).hexdigest(),
              'inputs': {key: {field: value[field] for field in ('case', 'files', 'manifest_sha256')}
                         for key, value in arms.items()}, 'comparisons': comparisons}
    with args.output.open('x', encoding='utf-8') as handle:
        handle.write(json.dumps(result, ensure_ascii=False, indent=2) + '\n')
    print(json.dumps({name: result['summary'] for name, result in comparisons.items()}, ensure_ascii=False))


if __name__ == '__main__':
    main()
