# Copyright 2026 Huawei Technologies Co., Ltd
#
# Licensed under the Apache License, Version 2.0 (the "License");
# you may not use this file except in compliance with the License.
# You may obtain a copy of the License at
#
# http://www.apache.org/licenses/LICENSE-2.0
#
# Unless required by applicable law or agreed to in writing, software
# distributed under the License is distributed on an "AS IS" BASIS,
# WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
# See the License for the specific language governing permissions and
# limitations under the License.
# ============================================================================

"""Audit short diagnostic execution and observation coverage without a 200-step claim."""

import argparse
from collections import Counter, defaultdict
import hashlib
import json
import math
from pathlib import Path
import re

from strict_compare_runs import audit


ROOT = Path(__file__).resolve().parents[1]


def read_json(path: Path) -> dict:
    """Read exact JSON evidence without modifying it."""
    return json.loads(path.read_bytes())


def read_rows(path: Path) -> list:
    """Reject missing or empty observation streams."""
    rows = [json.loads(line) for line in path.read_bytes().splitlines()]
    if not rows:
        raise AssertionError(f'Empty required observation stream: {path.name}')
    return rows


def check_sample(row: dict) -> None:
    """Validate finite samples and their explicit coordinate/value correspondence."""
    shape, sample = row['shape'], row['sample_shape']
    if len(shape) != 3 or len(sample) != 3 or any(
            not isinstance(size, int) or isinstance(size, bool) or size <= 0 for size in shape + sample):
        raise AssertionError('Invalid activation or sample shape')
    if sample != [shape[0], len(row['positions']), len(row['features'])]:
        raise AssertionError('Activation coordinates disagree with sample dimensions')
    for name, bound in (('positions', row['global_sequence']), ('features', shape[2])):
        coordinates = row[name]
        if (coordinates != sorted(set(coordinates)) or
                any(not isinstance(value, int) or isinstance(value, bool)
                    or not 0 <= value < bound for value in coordinates)):
            raise AssertionError('Invalid activation coordinate')
    if len(row['values']) != math.prod(sample) or any(
            isinstance(value, bool) or not isinstance(value, (int, float)) or not math.isfinite(value)
            for value in row['values']):
        raise AssertionError('Missing or nonfinite activation samples')


def check_linear_stages(calls: dict, sampled: dict) -> None:
    """Require one sampled Linear call per functional call, including replay entries."""
    if set(sampled) != set(range(len(calls))):
        raise AssertionError('Activation Linear calls differ from functional call coverage')
    for index, call in enumerate(calls.values()):
        if 'forward_enter' not in call['events'] or len(call['metadata']['input_shape']) != 3:
            raise AssertionError('Unsupported or incomplete watched Linear call')
        stages = sampled[index]
        if 'input' not in stages:
            raise AssertionError('Missing watched Linear input sample')
        for event, stage in (('forward_return', 'output'), ('output_gradient_observed', 'output_gradient')):
            if (event in call['events']) != (stage in stages):
                raise AssertionError('Functional Linear event differs from activation stage coverage')


def check_activation_calls(activations: list, events: list, watched: set) -> dict:
    """Cross-check watched Linear calls against an independent functional observer."""
    sampled = defaultdict(dict)
    for row in activations:
        key = (row['batch_sha256'], row['module'])
        stages = sampled[key].setdefault(row['call'], set())
        if row['stage'] in stages:
            raise AssertionError('Duplicated activation call/stage')
        stages.add(row['stage'])
    for calls in sampled.values():
        if sorted(calls) != list(range(len(calls))):
            raise AssertionError('Non-contiguous activation call indices')
    linear = defaultdict(dict)
    for row in events:
        if row['step'] != 1 or row['module'] not in watched:
            continue
        key = (row['first_step_batch_sha256'], row['module'])
        call = linear[key].setdefault(row['call_id'], {'events': set(), 'metadata': row})
        if row['event'] in call['events']:
            raise AssertionError('Duplicated functional Linear call/event')
        call['events'].add(row['event'])
    batches = {row['batch_sha256'] for row in activations}
    linear_names = {row['module'] for row in events} & watched
    if set(linear) != {(batch, module) for batch in batches for module in linear_names}:
        raise AssertionError('Missing watched Linear first-step batch coverage')
    for key, calls in linear.items():
        check_linear_stages(calls, sampled[key])
    return {'watched_linear_batch_modules': len(linear),
            'watched_linear_calls': sum(len(calls) for calls in linear.values()),
            'scope': ('Linear input/output/output-gradient calls cross-checked; other modules have '
                      'module-level coverage and unique contiguous observed calls, not a complete call oracle.')}


def check_objectives(objectives: list, batches: set, stages: list) -> None:
    """Require all three finite objective gradients once per batch and boundary."""
    expected_losses = Counter({(batch, stage, f'foundation_loss/{name}'): 1
                               for batch in batches for stage in stages for name in ('lm', 'mtp', 'aux')})
    actual_losses = Counter((row['batch_sha256'], row['stage'], row['name']) for row in objectives)
    if actual_losses != expected_losses:
        raise AssertionError('Missing, duplicated or mismatched first-step objective identities')
    for row in objectives:
        for name in ('forward_value', 'gradient'):
            value = row[name]
            if isinstance(value, bool) or not isinstance(value, (int, float)) or not math.isfinite(value):
                raise AssertionError('Nonfinite objective value or derivative')


def first_step_coverage(directory: Path, rank: int, batches: set, protocol: dict, events: list) -> dict:
    """Join first-step Linear, activation and objective observations by batch identity."""
    start = read_json(directory / f'start-rank{rank}.json')
    complete = read_json(directory / f'complete-rank{rank}.json')
    if start['global_step'] != 0 or complete['global_step'] != 3 or start['train_iters'] != 3:
        raise AssertionError('Short-run start/completion markers are not exactly zero/three')
    if len(batches) != start['micro_batches']:
        raise AssertionError('Missing or ambiguous first-step microbatch identities')
    probe = read_json(directory / f'cp-backward-probe-rank{rank}.json')
    if probe['cp_size'] != protocol['cp_size'] or probe['tp_size'] != 1:
        raise AssertionError('Boundary observer layout differs from the diagnostic protocol')
    watched = {row['name'] for row in probe['watched']}
    activations = read_rows(directory / f'activations-rank{rank}.jsonl')
    expected_modules = {(batch, module) for batch in batches for module in watched}
    forward, backward = set(), set()
    for row in activations:
        key = (row['batch_sha256'], row['module'])
        if (row['rank'], row['cp_rank'], row['tp_rank']) != (rank, probe['cp_rank'], 0):
            raise AssertionError('Invalid activation rank identity')
        if (key not in expected_modules or not isinstance(row['call'], int)
                or isinstance(row['call'], bool) or row['call'] < 0):
            raise AssertionError('Invalid activation identity, module, rank or call')
        if row['stage'] in ('input', 'output'):
            forward.add(key)
        elif row['stage'] in ('input_gradient', 'output_gradient'):
            backward.add(key)
        else:
            raise AssertionError('Unknown activation stage')
        check_sample(row)
    if not watched or forward != expected_modules or backward != expected_modules:
        raise AssertionError('Missing per-batch module forward or backward samples')
    calls = check_activation_calls(activations, events, watched)
    objectives = read_rows(directory / f'loss-gradients-rank{rank}.jsonl')
    stages = ['after_model_forward'] + (['before_cp_sum'] if protocol['cp_size'] == 2 else [])
    check_objectives(objectives, batches, stages)
    return {'activation_records': len(activations), 'objective_records': len(objectives),
            'watched_modules': len(watched), 'first_step_batches': len(batches), 'objective_stages': stages,
            'call_coverage': calls,
            'scope': 'Nonempty finite stride samples with matching identities; not full-tensor equality.'}


def coverage(directory: Path, rank: int) -> dict:
    """Require actual calls, backward observations, and correctly bounded batch identity."""
    summary = read_json(directory / f'linear-dgrad-coverage-rank{rank}.json')
    protocol = read_json(directory / f'linear-dgrad-experiment-rank{rank}.json')
    events = [json.loads(line) for line in
              (directory / f'linear-dgrad-events-rank{rank}.jsonl').read_text().splitlines()]
    if not events or len(events) != summary['records'] or summary['function_patch_ownership_lost']:
        raise AssertionError(f'Invalid observer completion at rank {rank}')
    expected = Counter({(row['module'], row['event'], row['treatment']): row['count'] for row in summary['counts']})
    actual = Counter((row['module'], row['event'], row['treatment']) for row in events)
    if expected != actual or summary['calls_entered'] != sum(row['event'] == 'forward_enter' for row in events):
        raise AssertionError('Coverage summary differs from raw events')
    if protocol['training_steps'] != 3 or protocol['mode'] not in ('native', 'fp32'):
        raise AssertionError('Invalid short-run protocol')
    changed = protocol['mode'] == 'fp32'
    if changed != summary['changed_dgrad'] or changed != protocol['numeric_recipe_changed']:
        raise AssertionError('Treatment metadata is inconsistent')
    for row in events:
        if row['step'] not in (1, 2, 3) or row['npu_matmul_allow_hf32'] is not False:
            raise AssertionError('Unexpected step or NPU backend precision')
        batch = row['first_step_batch_sha256']
        if (row['step'] == 1 and not re.fullmatch(r'[0-9a-f]{64}', batch or '')) or (
                row['step'] != 1 and batch is not None):
            raise AssertionError('Missing active identity or stale later-step identity')
        treatment = 'fp32_dgrad' if changed and row['eligible_local_bf16'] else 'native'
        if row['treatment'] != treatment:
            raise AssertionError('Actual intervention differs from the recorded arm')
    steps = []
    for step in (1, 2, 3):
        selected = [row for row in events if row['step'] == step]
        counts = Counter(row['event'] for row in selected)
        if not counts['forward_enter'] or not counts['output_gradient_observed']:
            raise AssertionError(f'No actual forward/backward observation: rank {rank}, step {step}')
        if bool(counts['derivative_calculated']) != changed:
            raise AssertionError('Changed derivative did not execute or native arm was modified')
        steps.append({'step': step, 'events': dict(counts)})
    observed = {row['module'] for row in events}
    missing = [row['name'] for row in summary['registered_modules'] if row['name'] not in observed]
    if missing:
        raise AssertionError(f'Registered Linear modules were not observed: {missing}')
    boundaries = first_step_coverage(directory, rank, {
        row['first_step_batch_sha256'] for row in events if row['step'] == 1}, protocol, events)
    return {'rank': rank, 'mode': protocol['mode'], 'records': len(events), 'steps': steps,
            'first_step_batch_occurrences': dict(Counter(row['first_step_batch_sha256'] for row in events
                                                        if row['step'] == 1 and row['event'] == 'forward_enter')),
            'registered_without_observed_call': missing, 'first_step_boundaries': boundaries,
            'module_event_counts': summary['counts']}


def main() -> None:
    """Keep final acceptance ineligible and report short-window equality separately."""
    parser = argparse.ArgumentParser()
    parser.add_argument('reference', type=Path)
    parser.add_argument('candidate', type=Path)
    parser.add_argument('--reference-manifest', type=Path, required=True)
    parser.add_argument('--candidate-manifest', type=Path, required=True)
    parser.add_argument('--output', type=Path, required=True)
    args = parser.parse_args()
    if args.output.resolve().parent != ROOT / 'evidence':
        raise ValueError('Audit output must stay outside the input runs, in task evidence')
    strict = audit(args.reference, args.candidate, 1, 3, reference_manifest=args.reference_manifest,
                   candidate_manifest=args.candidate_manifest)
    if strict['findings'] != ['Final acceptance requires exactly 200 consecutive steps']:
        raise AssertionError(strict['findings'])
    if strict['input_mismatch_count'] or strict['initial_mismatches']:
        raise AssertionError('Input or initial state differs from the matched reference')
    manifest = read_json(args.candidate_manifest)
    bound_paths = {entry['path'] for entry in manifest['files']}
    prefixes = ('linear-dgrad-coverage', 'linear-dgrad-experiment', 'linear-dgrad-events',
                'cp-backward-probe', 'activations', 'loss-gradients')
    for rank in range(8):
        for prefix in prefixes:
            extension = 'jsonl' if prefix in ('linear-dgrad-events', 'activations', 'loss-gradients') else 'json'
            path = args.candidate / f'{prefix}-rank{rank}.{extension}'
            if path.resolve().relative_to(ROOT).as_posix() not in bound_paths:
                raise AssertionError('Observation is not bound to the collected manifest')
    for entry in manifest['files']:
        path = (ROOT / entry['path']).resolve()
        if ROOT not in path.parents or not path.is_file():
            raise ValueError('Collected evidence path is missing or outside the task')
        contents = path.read_bytes()
        if len(contents) != entry['bytes'] or hashlib.sha256(contents).hexdigest() != entry['sha256']:
            raise AssertionError('Raw evidence no longer matches the collection manifest')
    ranks = [coverage(args.candidate, rank) for rank in range(8)]
    modes = {row['mode'] for row in ranks}
    if len(modes) != 1:
        raise AssertionError('Ranks executed different treatments')
    exact = all(row['max_abs'] == 0 for row in strict['errors'].values())
    result = {'scope': '三步诊断；不满足最终200步验收。FP32臂改变数值配方，不作生产性能结论。',
              'execution_and_observation_audit': 'PASS',
              'native_observation_transparency': ('EXACT_FOR_THIS_THREE_STEP_WINDOW' if exact else 'NONZERO_DELTA')
              if modes == {'native'} else 'NOT_APPLICABLE_CHANGED_DERIVATIVE',
              'final_training_acceptance': 'NOT_EVALUATED_THREE_STEPS', 'strict_200_step_audit': strict,
              'coverage': ranks, 'raw_files_verified': len(manifest['files']),
              'auditor_sha256': hashlib.sha256(Path(__file__).read_bytes()).hexdigest()}
    with args.output.open('x', encoding='utf-8') as handle:
        handle.write(json.dumps(result, ensure_ascii=False, indent=2) + '\n')
    print(json.dumps({key: value for key, value in result.items() if key not in ('coverage', 'strict_200_step_audit')},
                     ensure_ascii=False))
    print(json.dumps({'errors': strict['errors'], 'unweighted': strict['unweighted_error_diagnostics']}))


if __name__ == '__main__':
    main()
