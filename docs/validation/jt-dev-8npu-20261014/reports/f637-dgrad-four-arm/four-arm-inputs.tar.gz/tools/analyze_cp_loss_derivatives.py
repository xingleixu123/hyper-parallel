"""Compare scalar loss derivatives before CP redistribution by full input identity."""

import argparse
from collections import defaultdict
import json
from pathlib import Path


def records(directory, stage):
    assert (directory / 'EXIT_CODE').read_text().strip() == '0', directory
    result = defaultdict(list)
    for rank in range(8):
        for line in (directory / f'loss-gradients-rank{rank}.jsonl').read_text().splitlines():
            row = json.loads(line)
            if row['stage'] == stage:
                assert row['batch_sha256'] is not None
                result[(row['batch_sha256'], row['name'])].append({'rank': rank, **row})
    return result


def compare(reference, candidate):
    expected = records(reference, 'after_model_forward')
    actual = records(candidate, 'before_cp_sum')
    if set(expected) != set(actual):
        raise ValueError('Objective/batch coverage mismatch')
    rows = []
    for key, observations in expected.items():
        values = {row['gradient'] for row in observations}
        assert len(values) == 1, ('Non-identical FSDP replicas', key)
        value = next(iter(values))
        candidates = actual[key]
        rows.append({'batch_sha256': key[0], 'objective': key[1], 'reference_gradient': value,
                     'candidate_gradients': [row['gradient'] for row in candidates],
                     'candidate_ranks': [row['rank'] for row in candidates],
                     'max_abs': max(abs(row['gradient']-value) for row in candidates)})
    summary = {name: {'max_abs': max(r['max_abs'] for r in rows if r['objective'] == name),
                      'differing_batches': sum(r['max_abs'] != 0 for r in rows if r['objective'] == name)}
               for name in sorted({r['objective'] for r in rows})}
    return {'reference': reference.name, 'candidate': candidate.name,
            'scope': 'First-step scalar autograd derivatives: FSDP objective vs local CP objective before root sum',
            'after_cp_sum_note': 'Root CP replica derivatives have different local token weights and are not compared directly.',
            'unique_batches': len({key[0] for key in expected}), 'summary': summary, 'records': rows}


if __name__ == '__main__':
    parser = argparse.ArgumentParser()
    parser.add_argument('reference', type=Path)
    parser.add_argument('candidate', type=Path)
    parser.add_argument('--output', type=Path, required=True)
    args = parser.parse_args()
    report = compare(args.reference, args.candidate)
    args.output.write_text(json.dumps(report, indent=2) + '\n')
    print(json.dumps({'batches': report['unique_batches'], 'summary': report['summary']}))
