# Copyright 2026 Huawei Technologies Co., Ltd
#
# Licensed under the Apache License, Version 2.0 (the "License");
# you may not use this file except in compliance with the License.
# You may obtain a copy of the License at
#
# http://www.apache.org/licenses/LICENSE-2.0
#
# Unless required by applicable law or agreed to in writing, software
# distributed under the License is distributed on an "AS IS" BASIS,
# WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
# See the License for the specific language governing permissions and
# limitations under the License.
# ============================================================================

"""Run one isolated arm of the current-recipe native/FP32 dgrad diagnostic."""

import os
from typing import Any

import capture_cp_loss_training as traced
import capture_training
from linear_dgrad_trace_experiment import LinearDgradTrace


OBSERVER = None


def build_trainer(*args: Any, **kwargs: Any) -> Any:
    """Install exactly the same observation boundaries after normal model creation."""
    global OBSERVER  # pylint: disable=global-statement
    mode = os.environ['JT_LINEAR_DGRAD_MODE']
    if mode not in ('native', 'fp32'):
        raise ValueError('Expected an explicit native or fp32 diagnostic arm')
    trainer = traced.build_traced_trainer(*args, **kwargs)
    base = trainer.base
    if base.train_iters != 3 or base.mesh.tp_size != 1 or base.mesh.cp_size not in (1, 2):
        raise ValueError('This observer is restricted to TP1/CP1-or-2, three steps')

    def identity() -> dict:
        return {'step': base.state.global_step + 1, 'first_step_batch_sha256': traced.batch_identity()}

    OBSERVER = LinearDgradTrace(base.model, capture_training.OUTPUT, capture_training.RANK,
                               changed=mode == 'fp32', identity=identity)
    capture_training.write_json(f'linear-dgrad-experiment-rank{capture_training.RANK}.json', {
        'mode': mode, 'production_source_unchanged': True,
        'numeric_recipe_changed': mode == 'fp32', 'training_steps': 3,
        'tp_size': base.mesh.tp_size, 'cp_size': base.mesh.cp_size,
        'scope': ('Local plain BF16 Linear operands only; native forward and weight-gradient replay. '
                  'Three-step diagnostic, not a 200-step acceptance or production performance result.'),
    })
    return trainer


def main() -> None:
    """Use the real Trainer with nonpersistent first-step boundary observations."""
    traced.install_cp_loss_trace(capture_training.OUTPUT, capture_training.RANK, traced.batch_identity)
    capture_training.TextTrainer = build_trainer
    capture_training.InputIdentityRecorder = traced.TracedInputRecorder
    try:
        capture_training.main()
    finally:
        if OBSERVER is not None:
            OBSERVER.close()


if __name__ == '__main__':
    main()
