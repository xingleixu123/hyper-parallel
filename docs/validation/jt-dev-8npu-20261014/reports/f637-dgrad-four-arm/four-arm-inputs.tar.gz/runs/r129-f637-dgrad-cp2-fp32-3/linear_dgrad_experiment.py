"""Isolate FP32 local Linear input gradients while preserving BF16 forward/wgrad."""

import json

import torch
from torch.autograd.function import once_differentiable
from torch.nn import functional as F


NATIVE_LINEAR = F.linear


class LinearInputGradient(torch.autograd.Function):
    """Diagnostic first-order derivative; no change to the forward calculation."""

    @staticmethod
    def forward(ctx, inputs, weight, bias):
        if inputs.dtype != torch.bfloat16 or weight.dtype != torch.bfloat16:
            raise ValueError('This diagnostic requires BF16 local operands')
        ctx.save_for_backward(inputs, weight, bias)
        ctx.has_bias = bias is not None
        return NATIVE_LINEAR(inputs, weight, bias)

    @staticmethod
    @once_differentiable
    def backward(ctx, gradient):
        inputs, weight, bias = ctx.saved_tensors
        input_gradient = weight_gradient = bias_gradient = None
        if ctx.needs_input_grad[0]:
            input_gradient = NATIVE_LINEAR(gradient.float(), weight.t().float()).to(inputs.dtype)
        need_weight = ctx.needs_input_grad[1]
        need_bias = ctx.has_bias and ctx.needs_input_grad[2]
        if need_weight or need_bias:
            with torch.enable_grad():
                detached_weight = weight.detach().requires_grad_(need_weight)
                detached_bias = bias.detach().requires_grad_(need_bias) if bias is not None else None
                replay = NATIVE_LINEAR(inputs.detach(), detached_weight, detached_bias)
                targets = ([detached_weight] if need_weight else []) + ([detached_bias] if need_bias else [])
                native_gradients = torch.autograd.grad(replay, targets, gradient)
            if need_weight:
                weight_gradient = native_gradients[0]
            if need_bias:
                bias_gradient = native_gradients[-1]
        return input_gradient, weight_gradient, bias_gradient


def install_linear_dgrad(output, rank):
    original = F.linear
    seen = set()

    def linear(inputs, weight, bias=None):
        local = (type(inputs) in (torch.Tensor, torch.nn.Parameter) and
                 type(weight) in (torch.Tensor, torch.nn.Parameter))
        if not local or inputs.dtype != torch.bfloat16 or weight.dtype != torch.bfloat16:
            return original(inputs, weight, bias)
        hf32 = torch.npu.matmul.allow_hf32 if inputs.device.type == 'npu' else None
        if hf32:
            raise ValueError('FP32 operand diagnostic requires NPU matmul HF32 disabled')
        signature = (tuple(inputs.shape), tuple(weight.shape), bias is not None)
        if signature not in seen:
            seen.add(signature)
            with (output / f'linear-dgrad-calls-rank{rank}.jsonl').open('a') as handle:
                handle.write(json.dumps({'input_shape': list(inputs.shape), 'weight_shape': list(weight.shape),
                                         'bias': bias is not None, 'forward': 'native BF16',
                                         'npu_matmul_allow_hf32': hf32,
                                         'dgrad': 'FP32 matmul then cast to input dtype',
                                         'wgrad': 'native BF16 Linear autograd replay; additional diagnostic overhead'}) + '\n')
        return LinearInputGradient.apply(inputs, weight, bias)

    F.linear = linear

    def remove():
        if F.linear is not linear:
            raise RuntimeError('Unexpected concurrent functional Linear patch')
        F.linear = original
    return remove
