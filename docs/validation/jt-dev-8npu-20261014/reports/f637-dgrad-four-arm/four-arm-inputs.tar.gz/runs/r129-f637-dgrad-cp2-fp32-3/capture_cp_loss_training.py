# Copyright 2026 Huawei Technologies Co., Ltd
#
# Licensed under the Apache License, Version 2.0 (the "License");
# you may not use this file except in compliance with the License.
# You may obtain a copy of the License at
#
# http://www.apache.org/licenses/LICENSE-2.0
#
# Unless required by applicable law or agreed to in writing, software
# distributed under the License is distributed on an "AS IS" BASIS,
# WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
# See the License for the specific language governing permissions and
# limitations under the License.
# ============================================================================

"""Trace the first CP loss/head derivatives without changing their arithmetic."""

import os

import capture_training
from cp_backward_trace import CPBackwardTrace
from loss_gradient_trace import install_cp_loss_trace, install_root_loss_trace


ORIGINAL_TRAINER = capture_training.TextTrainer
ORIGINAL_RECORDER = capture_training.InputIdentityRecorder
TRACE = None


def batch_identity() -> str | None:
    """Return an identity only while the first-step observation is active."""
    return None if TRACE is None or not TRACE.enabled else TRACE.batch


def build_traced_trainer(*args, **kwargs):
    global TRACE
    trainer = ORIGINAL_TRAINER(*args, **kwargs)
    TRACE = CPBackwardTrace(trainer.base, capture_training.OUTPUT, capture_training.RANK,
                            include_head=os.environ.get('JT_HEAD_TRACE', '1') == '1')
    install_root_loss_trace(trainer.base.model, capture_training.OUTPUT, capture_training.RANK, batch_identity)
    trainer.base._callbacks.append(TRACE)
    return trainer


class TracedInputRecorder(ORIGINAL_RECORDER):
    def record(self, model_inputs, loss_inputs):
        super().record(model_inputs, loss_inputs)
        TRACE.begin_batch(model_inputs, loss_inputs)


if __name__ == '__main__':
    install_cp_loss_trace(capture_training.OUTPUT, capture_training.RANK, batch_identity)
    capture_training.TextTrainer = build_traced_trainer
    capture_training.InputIdentityRecorder = TracedInputRecorder
    capture_training.main()
