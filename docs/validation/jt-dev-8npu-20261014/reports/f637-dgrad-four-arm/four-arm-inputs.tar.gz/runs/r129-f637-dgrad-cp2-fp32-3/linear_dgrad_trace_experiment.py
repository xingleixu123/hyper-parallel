# Copyright 2026 Huawei Technologies Co., Ltd
#
# Licensed under the Apache License, Version 2.0 (the "License");
# you may not use this file except in compliance with the License.
# You may obtain a copy of the License at
#
# http://www.apache.org/licenses/LICENSE-2.0
#
# Unless required by applicable law or agreed to in writing, software
# distributed under the License is distributed on an "AS IS" BASIS,
# WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
# See the License for the specific language governing permissions and
# limitations under the License.
# ============================================================================

"""Add bounded per-module coverage to the reviewed local Linear dgrad probe."""

from collections import Counter
from contextvars import ContextVar
import json
from pathlib import Path
from typing import Callable

import torch
from torch.nn import functional as F

from linear_dgrad_experiment import LinearInputGradient, NATIVE_LINEAR


class TracedLinearInputGradient(torch.autograd.Function):
    """Run the original first-order probe and observe its actual backward branch."""

    @staticmethod
    def forward(ctx: object, inputs: torch.Tensor, weight: torch.Tensor,
                bias: torch.Tensor | None, observe: Callable) -> torch.Tensor:
        """Keep the reviewed BF16 forward and attach only a scalar callback."""
        ctx.observe = observe
        return LinearInputGradient.forward(ctx, inputs, weight, bias)

    @staticmethod
    def backward(ctx: object, gradient: torch.Tensor) -> tuple:
        """Preserve the reviewed derivative and record which gradients were computed."""
        gradients = LinearInputGradient.backward(ctx, gradient)
        ctx.observe('derivative_calculated', {
            'needs_input_grad': list(ctx.needs_input_grad[:3]),
            'computed_gradients': [value is not None for value in gradients],
            'gradient_shape': list(gradient.shape), 'gradient_dtype': str(gradient.dtype),
        })
        return (*gradients, None)


class LinearDgradTrace:
    """Observe native and changed arms with identical bounded Python instrumentation.

    DTensor/subclass operands and non-BF16 operands remain native. The extra
    autograd replay in the changed arm makes its timing unsuitable for production
    performance claims. Module context hooks never change arguments or outputs.
    """

    def __init__(self, model: torch.nn.Module, output: Path, rank: int, changed: bool,
                 identity: Callable[[], dict]) -> None:
        self.path = output / f'linear-dgrad-events-rank{rank}.jsonl'
        self.summary_path = output / f'linear-dgrad-coverage-rank{rank}.json'
        self.changed = changed
        self.identity = identity
        self.context = ContextVar(f'linear_modules_rank_{rank}', default=())
        self.counts = Counter()
        self.records = 0
        self.call_id = 0
        self.handles = []
        self.original = F.linear
        if self.original is not NATIVE_LINEAR:
            raise RuntimeError('An unrelated functional Linear patch is already installed')
        self.modules = []
        try:
            for name, module in model.named_modules():
                if isinstance(module, torch.nn.Linear):
                    self.modules.append({'name': name, 'class': type(module).__name__})
                    self.handles.append(module.register_forward_pre_hook(self._enter(name)))
                    self.handles.append(module.register_forward_hook(self._leave(name), always_call=True))
        except BaseException:
            self._remove_hooks()
            raise
        self.replacement = self._linear
        F.linear = self.replacement

    def _enter(self, name: str) -> Callable:
        def enter(_module: object, _args: tuple) -> None:
            self.context.set((*self.context.get(), name))
        return enter

    def _leave(self, name: str) -> Callable:
        def leave(_module: object, _args: tuple, _output: object) -> None:
            stack = self.context.get()
            if not stack or stack[-1] != name:
                raise RuntimeError('Linear module context stack is inconsistent')
            self.context.set(stack[:-1])
        return leave

    def _write(self, metadata: dict, event: str, extra: dict | None = None) -> None:
        self.records += 1
        if self.records > 20000:
            raise RuntimeError('Short-run diagnostic exceeded its bounded event budget')
        self.counts[(metadata['module'], event, metadata['treatment'])] += 1
        with self.path.open('a', encoding='utf-8') as handle:
            handle.write(json.dumps({**metadata, 'event': event, **(extra or {})}) + '\n')

    def _linear(self, inputs: torch.Tensor, weight: torch.Tensor,
                bias: torch.Tensor | None = None) -> torch.Tensor:
        local = type(inputs) in (torch.Tensor, torch.nn.Parameter) and type(weight) in (
            torch.Tensor, torch.nn.Parameter)
        local = local and (bias is None or type(bias) in (torch.Tensor, torch.nn.Parameter))
        eligible = local and inputs.dtype == torch.bfloat16 and weight.dtype == torch.bfloat16
        hf32 = torch.npu.matmul.allow_hf32 if inputs.device.type == 'npu' else None
        if hf32:
            raise ValueError('Matched native/FP32 dgrad diagnostics require HF32 disabled')
        stack = self.context.get()
        self.call_id += 1
        # Torch has no public graph-task identifier; this optional hint never selects arithmetic.
        graph_task = getattr(torch._C, '_current_graph_task_id', lambda: None)()  # pylint: disable=protected-access
        metadata = {
            **self.identity(), 'call_id': self.call_id,
            'module': stack[-1] if stack else '<functional-outside-Linear>',
            'input_shape': list(inputs.shape), 'weight_shape': list(weight.shape), 'bias': bias is not None,
            'input_type': type(inputs).__name__, 'weight_type': type(weight).__name__,
            'bias_type': None if bias is None else type(bias).__name__,
            'bias_dtype': None if bias is None else str(bias.dtype),
            'input_dtype': str(inputs.dtype), 'weight_dtype': str(weight.dtype),
            'input_requires_grad': inputs.requires_grad, 'weight_requires_grad': weight.requires_grad,
            'gradient_enabled': torch.is_grad_enabled(), 'graph_task_id': graph_task,
            'forward_during_backward': None if graph_task is None else graph_task >= 0,
            'npu_matmul_allow_hf32': hf32, 'eligible_local_bf16': eligible,
            'treatment': 'fp32_dgrad' if eligible and self.changed else 'native',
        }
        self._write(metadata, 'forward_enter')

        def observe(event: str, extra: dict) -> None:
            self._write(metadata, event, extra)

        if eligible and self.changed:
            output = TracedLinearInputGradient.apply(inputs, weight, bias, observe)
        else:
            output = self.original(inputs, weight, bias)
        self._write(metadata, 'forward_return')
        if output.requires_grad:
            def observe_gradient(gradient: torch.Tensor) -> None:
                observe('output_gradient_observed', {
                    'gradient_shape': list(gradient.shape), 'gradient_dtype': str(gradient.dtype)})
            output.register_hook(observe_gradient)
        return output

    def _remove_hooks(self) -> None:
        for handle in self.handles:
            handle.remove()
        self.handles.clear()

    def close(self) -> None:
        """Always remove our hooks and never overwrite another owner's function patch."""
        ownership_lost = F.linear is not self.replacement
        if not ownership_lost:
            F.linear = self.original
        self._remove_hooks()
        if self.context.get():
            raise RuntimeError('Unclosed Linear module context at diagnostic shutdown')
        summary = {
            'changed_dgrad': self.changed, 'records': self.records, 'calls_entered': self.call_id,
            'function_patch_ownership_lost': ownership_lost,
            'registered_modules': self.modules,
            'counts': [{'module': key[0], 'event': key[1], 'treatment': key[2], 'count': count}
                       for key, count in sorted(self.counts.items())],
            'scope': ('Actual per-module calls and observed backward events only; forward_during_backward '
                      'does not by itself identify a particular checkpoint. Incomplete replay calls are '
                      'retained. DTensor and non-BF16 operands bypass the intervention. No performance claim.'),
        }
        self.summary_path.write_text(json.dumps(summary, indent=2) + '\n', encoding='utf-8')
        if ownership_lost:
            raise RuntimeError('Functional Linear was changed by another owner; our hooks were removed')
