# Copyright 2026 Huawei Technologies Co., Ltd
#
# Licensed under the Apache License, Version 2.0 (the "License");
# you may not use this file except in compliance with the License.
# You may obtain a copy of the License at
#
# http://www.apache.org/licenses/LICENSE-2.0
#
# Unless required by applicable law or agreed to in writing, software
# distributed under the License is distributed on an "AS IS" BASIS,
# WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
# See the License for the specific language governing permissions and
# limitations under the License.
# ============================================================================

"""Observe scalar objective derivatives on either side of the CP root sum."""

from functools import wraps
import json

import torch


def record_objectives(losses, stage, batch, output, rank):
    # A missing identity marks an inactive observation window, not an unknown batch.
    if batch is None:
        return
    for name, tensor in losses.items():
        if not isinstance(tensor, torch.Tensor) or tensor.numel() != 1 or not tensor.requires_grad:
            raise ValueError('Expected a differentiable scalar model objective')
        row = {'name': name, 'stage': stage, 'batch_sha256': batch,
               'forward_value': float(tensor.detach()), 'dtype': str(tensor.dtype)}

        def record_gradient(gradient, observation=row):
            with (output / f'loss-gradients-rank{rank}.jsonl').open('a') as handle:
                handle.write(json.dumps({**observation, 'gradient': float(gradient.detach())}) + '\n')
            return None

        tensor.register_hook(record_gradient)


def install_cp_loss_trace(output, rank, batch_identity):
    from hyper_parallel.models.jt_deepseek_v3.adapter.distributed.context_parallel import _JTTrainingContext
    original = _JTTrainingContext.reduce_losses

    @wraps(original)
    def reduce_losses(self, module, args, result):
        record_objectives(result.loss, 'before_cp_sum', batch_identity(), output, rank)
        return original(self, module, args, result)

    _JTTrainingContext.reduce_losses = reduce_losses


def install_root_loss_trace(model, output, rank, batch_identity):
    def observe(_module, _args, result):
        record_objectives(result.loss, 'after_model_forward', batch_identity(), output, rank)
    return model.register_forward_hook(observe)
