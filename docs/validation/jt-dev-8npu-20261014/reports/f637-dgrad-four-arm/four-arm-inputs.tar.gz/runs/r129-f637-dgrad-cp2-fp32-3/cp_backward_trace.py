"""Non-mutating CP-aware first-step forward and backward boundary observations."""

import hashlib
import json
from pathlib import Path

import torch
import torch.distributed as dist

from hyper_parallel.trainer.callbacks.base import Callback


def sequence_offset(local, full, cp_size, cp_rank, tp_size, tp_rank):
    """Resolve the existing contiguous CP-major sequence partition."""
    if local == full:
        return 0
    if local * cp_size == full:
        return cp_rank * local
    if local * cp_size * tp_size == full:
        return (cp_rank * tp_size + tp_rank) * local
    raise ValueError(f'Unsupported sequence partition: {local}/{full}, CP{cp_size}, TP{tp_size}')


def batch_digest(fields):
    hasher = hashlib.sha256()
    for key, value in fields:
        if value is None:
            continue
        cpu = value.detach().cpu().contiguous()
        hasher.update(f'{key}:{tuple(cpu.shape)}:{cpu.dtype}'.encode())
        hasher.update(cpu.view(torch.uint8).numpy().tobytes())
    return hasher.hexdigest()


class CPBackwardTrace(Callback):
    """Sample full-width module boundaries and their actual tensor gradients."""

    def __init__(self, trainer, output: Path, rank: int, include_head: bool = False):
        super().__init__(trainer)
        self.path = output / f'activations-rank{rank}.jsonl'
        self.rank = rank
        self.tp_rank, self.tp_size = trainer.mesh.tp_rank, trainer.mesh.tp_size
        self.cp_rank, self.cp_size = trainer.mesh.cp_rank, trainer.mesh.cp_size
        self.dp_rank = trainer.mesh.dp_rank
        self.cp_group = trainer.mesh.device_mesh['cp'].get_group() if self.cp_size > 1 else None
        self.enabled = False
        self.batch = None
        self.sequence_length = None
        self.calls = {}
        self.current_calls = {}
        self.handles = []
        watched = []
        for name, module in trainer.model.named_modules():
            leaf = name.rsplit('.', 1)[-1]
            kinds = {base.__name__ for base in type(module).__mro__}
            if not (include_head and leaf == 'lm_head') and leaf not in {'embed_tokens', 'input_layernorm', 'post_attention_layernorm',
                            'linear_qkv', 'q_a_layernorm', 'kv_a_layernorm', 'key_rope_gather',
                            'self_attn', 'mlp', 'norm', 'enorm', 'hnorm', 'eh_proj'} and 'JTDeepseekV3Decoder' not in kinds:
                continue
            watched.append({'name': name, 'class': type(module).__name__})
            self.handles.append(module.register_forward_pre_hook(self._pre_hook(name), with_kwargs=True))
            self.handles.append(module.register_forward_hook(self._post_hook(name)))
        (output / f'cp-backward-probe-rank{rank}.json').write_text(json.dumps({
            'watched': watched, 'sequence_stride': 128, 'feature_stride': 128,
            'include_head': include_head,
            'cp_rank': self.cp_rank, 'cp_size': self.cp_size, 'tp_rank': self.tp_rank, 'tp_size': self.tp_size,
            'scope': 'Step 1 sampled boundaries; tensor hooks return None and do not modify gradients',
            'gradient_scale': 'Raw local autograd gradients; inspect training normalization before cross-layout comparison',
        }, indent=2) + '\n')

    def on_step_begin(self, state, **_kwargs):
        self.enabled = state.global_step == 0

    def on_step_end(self, state, **_kwargs):
        self.enabled = False

    def begin_batch(self, model_inputs, loss_inputs):
        if not self.enabled:
            return
        fields = []
        for key, tensor in [('input_ids', model_inputs['input_ids']), ('shift_labels', loss_inputs.get('shift_labels'))]:
            if tensor is None:
                continue
            if hasattr(tensor, 'to_local'):
                tensor = tensor.to_local()
            value = tensor.detach().cpu().contiguous()
            if self.cp_size > 1:
                gathered = [None] * self.cp_size
                dist.all_gather_object(gathered, value, group=self.cp_group)
                value = torch.cat(gathered, dim=-1)
            fields.append((key, value))
        self.batch = batch_digest(fields)
        self.sequence_length = fields[0][1].shape[-1]
        self.calls, self.current_calls = {}, {}

    def _pre_hook(self, name):
        def observe(_module, args, kwargs):
            if self.enabled and self.batch is not None:
                call = self.calls.get(name, 0)
                self.calls[name] = call + 1
                self.current_calls[name] = call
                self._observe(name, call, 'input', args[0] if args else kwargs.get('hidden_states'))
        return observe

    def _post_hook(self, name):
        def observe(_module, _args, output):
            if self.enabled and self.batch is not None:
                self._observe(name, self.current_calls[name], 'output', output)
        return observe

    def _observe(self, name, call, stage, value):
        if isinstance(value, (tuple, list)):
            value = value[0]
        if not isinstance(value, torch.Tensor) or value.ndim != 3:
            return
        identity = (self.batch, self.sequence_length)
        self._record(name, call, stage, value, identity)
        if value.requires_grad:
            def record_gradient(gradient):
                self._record(name, call, stage + '_gradient', gradient, identity)
                return None
            value.register_hook(record_gradient)

    @torch.no_grad()
    def _record(self, name, call, stage, value, identity):
        tensor = value.detach()
        if hasattr(tensor, 'to_local'):
            tensor = tensor.to_local()
        offset = sequence_offset(tensor.shape[1], identity[1], self.cp_size, self.cp_rank, self.tp_size, self.tp_rank)
        positions = list(range((-offset) % 128, tensor.shape[1], 128))
        features = list(range(0, tensor.shape[2], 128))
        sample = tensor[:, positions][:, :, features].float().cpu()
        row = {'rank': self.rank, 'dp_rank': self.dp_rank, 'cp_rank': self.cp_rank, 'tp_rank': self.tp_rank,
               'batch_sha256': identity[0], 'module': name, 'call': call, 'stage': stage,
               'shape': list(tensor.shape), 'dtype': str(tensor.dtype), 'global_sequence': identity[1],
               'positions': [position + offset for position in positions], 'features': features,
               'sample_shape': list(sample.shape), 'values': sample.reshape(-1).tolist()}
        with self.path.open('a') as handle:
            handle.write(json.dumps(row) + '\n')
