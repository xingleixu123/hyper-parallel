# Copyright 2026 Huawei Technologies Co., Ltd
#
# Licensed under the Apache License, Version 2.0 (the "License");
# you may not use this file except in compliance with the License.
# You may obtain a copy of the License at
#
# http://www.apache.org/licenses/LICENSE-2.0
#
# Unless required by applicable law or agreed to in writing, software
# distributed under the License is distributed on an "AS IS" BASIS,
# WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
# See the License for the specific language governing permissions and
# limitations under the License.
# ============================================================================

"""Audit real-input row VJP observations separately from final training acceptance."""

import hashlib
import json
import math
from pathlib import Path
import re

from strict_compare_runs import audit


ROOT = Path(__file__).resolve().parents[1]
CASE = 'r129-f637-head-row-vjp-fsdp8-3-v1'


def read_json(path: Path) -> dict:
    """Read immutable evidence bytes without changing their representation."""
    return json.loads(path.read_bytes())


def verify_statistics(value: dict, count: int) -> None:
    """Check complete coordinate coverage, finite reductions and consistent scalar aggregates."""
    if value['count'] != count or not 0 <= value['nonzero_count'] <= count:
        raise ValueError('The comparison did not cover the expected derivative coordinates')
    for key in ('max_abs', 'absolute_sum', 'squared_sum', 'mean_abs', 'rms_abs'):
        if not math.isfinite(value[key]) or value[key] < 0:
            raise ValueError('The diagnostic contains a nonfinite or negative error statistic')
    if not math.isclose(value['mean_abs'], value['absolute_sum'] / count, rel_tol=1e-14, abs_tol=1e-30):
        raise ValueError('Mean error does not match its raw sum and coordinate count')
    if not math.isclose(value['rms_abs'] ** 2, value['squared_sum'] / count, rel_tol=1e-14, abs_tol=1e-30):
        raise ValueError('RMS error does not match its raw squared sum and coordinate count')
    if (value['nonzero_count'] == 0) != (value['max_abs'] == 0):
        raise ValueError('The maximum and nonzero-count conclusions disagree')


def main() -> None:
    """Require a transparent three-step run, preserve the strict final-gate rejection, and report local effects."""
    directory = ROOT / 'runs' / CASE
    manifest_path = ROOT / 'evidence/f637-head-row-vjp-fsdp8-3-v1-evidence-manifest.json'
    manifest = read_json(manifest_path)
    for entry in manifest['files']:
        path = (ROOT / entry['path']).resolve()
        if ROOT not in path.parents or path.is_symlink():
            raise ValueError('Collected evidence escaped the task directory')
        contents = path.read_bytes()
        if len(contents) != entry['bytes'] or hashlib.sha256(contents).hexdigest() != entry['sha256']:
            raise ValueError('Collected evidence differs from its file manifest')
    request = read_json(ROOT / 'scheduling' / (CASE + '.request.json'))
    receipt = read_json(ROOT / 'scheduling' / (CASE + '.receipt.json'))
    if (receipt['workspace'] != request['workspace'] or not receipt['released'] or receipt['exit_code'] != 0
            or receipt['remaining_owned_pids'] or receipt['duration_seconds'] > 600):
        raise ValueError('Execution did not finish and release within its actual reserved window')
    for path in directory.glob('*.py'):
        if hashlib.sha256(path.read_bytes()).hexdigest() != request['files']['tools/' + path.name]:
            raise ValueError('An executed observer differs from the frozen request')
    expected_config = read_json(ROOT / 'runs/r129-f637-fp32-fsdp8-0-200-r4/config.resolved.json')
    expected_config['training']['train_iters'] = 3
    expected_config['checkpoint']['save_ckpt'] = False
    expected_config['checkpoint']['checkpoint_dir'] = '/work/checkpoints/' + CASE
    if read_json(directory / 'config.resolved.json') != expected_config:
        raise ValueError('The observer changed the reference numerical configuration')
    for rank in range(8):
        start = read_json(directory / f'start-rank{rank}.json')
        finish = read_json(directory / f'complete-rank{rank}.json')
        mode = read_json(directory / f'head-row-vjp-mode-rank{rank}.json')
        rows = [json.loads(line) for line in (directory / f'metrics-rank{rank}.jsonl').read_bytes().splitlines()]
        if (start['global_step'] != 0 or start['train_iters'] != 3 or finish['global_step'] != 3
                or [row['step'] for row in rows] != [1, 2, 3]
                or mode['selected'] != (rank == 0) or mode['numeric_recipe_changed']):
            raise ValueError('The native observer did not execute its exact three-step, rank0-only protocol')
    strict = audit(ROOT / 'runs/r129-f637-fp32-fsdp8-0-200-r4', directory, 1, 3,
                   reference_manifest=ROOT / 'evidence/f637-fsdp8-r4-complete-evidence-manifest.json',
                   candidate_manifest=manifest_path)
    if strict['findings'] != ['Final acceptance requires exactly 200 consecutive steps']:
        raise ValueError(strict['findings'])
    observed = read_json(directory / 'head-row-vjp-rank0.json')
    if (observed['input_shape'] != [1, 4096, 5120] or observed['weight_shape'] != [152064, 5120]
            or observed['gradient_shape'] != [1, 4096, 152064] or observed['dtype'] != 'torch.bfloat16'
            or observed['reference_vjp_elements'] != 20971520 or observed['private_snapshot_bytes'] != 1599078400
            or observed['training_gradient_replaced'] or observed['production_performance_claim']):
        raise ValueError('The real local VJP differs from the frozen shape, precision or scope')
    identity = observed['identity']
    if (identity['step'], identity['rank'], identity['selected_call'], identity['module']) != (1, 0, 0, 'lm_head'):
        raise ValueError('The selected head is not the declared first main-LM call')
    if set(identity['fields']) != {'input_ids', 'shift_labels'}:
        raise ValueError('Required logical input fields are missing')
    for field in identity['fields'].values():
        if field['shape'] != [1, 4096] or not re.fullmatch(r'[0-9a-f]{64}', field['sha256']):
            raise ValueError('The selected actual batch has an invalid token identity')
    if set(observed['variants']) != {'repeat', 'halves', 'tiles128', 'padded_halves'}:
        raise ValueError('A required local row-shape comparison is missing')
    for statistics in observed['variants'].values():
        verify_statistics(statistics, 20971520)
    sample = observed['sampled_fp64_oracle']
    verify_statistics(sample['difference'], len(sample['rows']) * len(sample['columns']))
    exact = all(value['max_abs'] == 0 for value in strict['errors'].values())
    result = {'execution_and_observation_audit': 'PASS', 'case': CASE,
              'native_three_step_transparency': 'EXACT' if exact else 'NONZERO_DELTA',
              'final_training_acceptance': 'NOT_EVALUATED_THREE_STEPS',
              'local_row_variants_exact': all(value['max_abs'] == 0 for value in observed['variants'].values()),
              'observed': observed, 'strict_200_step_audit': strict,
              'raw_files_verified': len(manifest['files']),
              'auditor_sha256': hashlib.sha256(Path(__file__).read_bytes()).hexdigest(),
              'scope': ('Only the selected real rank0 main-LM head local input derivative; '
                        'not upstream equality or root cause.')}
    with (ROOT / 'evidence/f637-head-row-vjp-fsdp8-3-v1-audit.json').open('x', encoding='utf-8') as output:
        json.dump(result, output, ensure_ascii=False, indent=2)
    print(json.dumps({key: value for key, value in result.items() if key not in ('observed', 'strict_200_step_audit')}))
    print(json.dumps({'local_variants': observed['variants'], 'training_errors': strict['errors'],
                      'sampled_fp64_oracle': sample['difference']}))


if __name__ == '__main__':
    main()
