#!/usr/bin/env bash
set -eo pipefail
source /workspace/env.sh
export PATH="/work/venvs/validation/bin:$PATH"
export OMP_NUM_THREADS=1 PYTHONDONTWRITEBYTECODE=1
export JT_CASE_OUTPUT=/work/evidence/head-row-storage-import-only
cd /work/tools
python - <<'PY'
import hashlib
import json
from pathlib import Path
import hyper_parallel
import torch
from hyper_parallel.trainer.config.parser import parse_training_args
import capture_head_row_vjp_training

root = Path('/work')
case = 'r129-f637-head-row-vjp-fsdp8-3-v1'
assert hyper_parallel.__file__.startswith('/workspace/hyper-parallel/')
assert capture_head_row_vjp_training.ORIGINAL_TRAINER is not None
actual = parse_training_args([str(root / 'configs' / (case + '.yaml'))]).to_dict()
expected = json.loads((root / 'evidence/native-fsdp-config.resolved.json').read_bytes())
expected['training']['train_iters'] = 3
expected['checkpoint']['save_ckpt'] = False
expected['checkpoint']['checkpoint_dir'] = '/work/checkpoints/' + case
assert actual == expected
assert not torch.npu.is_initialized() and not torch.cuda.is_initialized()
result = {'status': 'PASS', 'import_path': hyper_parallel.__file__, 'npu_initialized': False,
          'config': 'matches native reference except length and checkpoint output',
          'data_sha256': hashlib.sha256((root / 'data/sft_data_4k/data-00000-of-00001.arrow').read_bytes()).hexdigest()}
with (root / 'evidence/f637-head-row-storage-preflight.json').open('x') as handle:
    json.dump(result, handle, indent=2)
print(json.dumps(result))
PY
