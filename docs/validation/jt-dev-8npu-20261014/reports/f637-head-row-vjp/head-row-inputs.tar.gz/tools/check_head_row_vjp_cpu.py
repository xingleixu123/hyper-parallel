# Copyright 2026 Huawei Technologies Co., Ltd
#
# Licensed under the Apache License, Version 2.0 (the "License");
# you may not use this file except in compliance with the License.
# You may obtain a copy of the License at
#
# http://www.apache.org/licenses/LICENSE-2.0
#
# Unless required by applicable law or agreed to in writing, software
# distributed under the License is distributed on an "AS IS" BASIS,
# WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
# See the License for the specific language governing permissions and
# limitations under the License.
# ============================================================================

"""Validate observation transparency with the actual chunked/shared production head path on CPU."""

import copy
import hashlib
import json
from pathlib import Path
import unittest
from unittest import mock

import torch  # pylint: disable=forbidden-backend-import
from torch.nn import functional  # pylint: disable=forbidden-backend-import
from torch.utils.checkpoint import DefaultDeviceType  # pylint: disable=forbidden-backend-import

from head_row_vjp_probe import HeadRowVJPProbe, measure, native_vjp
from hyper_parallel.components.losses.chunked_cross_entropy import projected_cross_entropy
from hyper_parallel.trainer.config.parser import parse_training_args


class HeadRowVJPTests(unittest.TestCase):
    """Exercise graph reuse, real nonreentrant checkpoint replay and private-buffer cleanup."""

    def setUp(self) -> None:
        """Use explicit CPU placement without TorchNPU's default checkpoint device initialization."""
        previous = DefaultDeviceType.get_device_type()
        DefaultDeviceType.set_device_type('cpu')
        self.addCleanup(DefaultDeviceType.set_device_type, previous)
        torch.manual_seed(67)

    @staticmethod
    def score(logits: torch.Tensor, labels: None, vocab_size: int, shift_labels: torch.Tensor,
              num_items_in_batch: torch.Tensor, **_kwargs: object) -> torch.Tensor:
        """Use the production helper's pre-shifted labels and valid-token denominator."""
        if logits.shape[-1] != vocab_size or labels is not None:
            raise ValueError('Unexpected vocabulary dimension or unshifted label contract')
        return functional.cross_entropy(logits.reshape(-1, logits.shape[-1]).float(), shift_labels.reshape(-1),
                                         reduction='sum', ignore_index=-100) / num_items_in_batch

    def test_real_shared_checkpoint_head_is_observational(self) -> None:
        """The selected call fires once, replays do not overwrite it, and all training gradients stay exact."""
        plain = torch.nn.Linear(8, 17, bias=False, dtype=torch.bfloat16)
        watched = copy.deepcopy(plain)
        original = torch.randn(1, 16, 8, dtype=torch.bfloat16, requires_grad=True)
        candidate = original.detach().clone().requires_grad_(True)
        labels = torch.arange(16, dtype=torch.int64).reshape(1, -1)
        labels[0, :2] = -100

        def loss(head: torch.nn.Linear, states: torch.Tensor) -> torch.Tensor:
            """Exercise the real chunked loss twice with one shared head and graph input."""
            total = projected_cross_entropy(states, labels, head=head, loss_fn=self.score,
                                             vocab_size=17, chunk_size=8)
            # Reuse both the head and the input graph as the MTP branch does.
            return total + 0.3 * projected_cross_entropy(states * 0.5, labels, head=head, loss_fn=self.score,
                                                        vocab_size=17, chunk_size=8)

        records = []
        probe = HeadRowVJPProbe(watched, records.append, lambda: {'logical_batch': 'cpu-test'})
        self.addCleanup(probe.close)
        expected, actual = loss(plain, original), loss(watched, candidate)
        expected.backward()
        actual.backward()
        self.assertEqual(len(records), 1)
        self.assertEqual(probe.state, 'done')
        self.assertIsNone(probe.inputs)
        self.assertIsNone(probe.weight)
        self.assertEqual(records[0]['input_shape'], [1, 8, 8])
        self.assertFalse(records[0]['training_gradient_replaced'])
        torch.testing.assert_close(actual, expected, rtol=0, atol=0)
        torch.testing.assert_close(candidate.grad, original.grad, rtol=0, atol=0)
        torch.testing.assert_close(watched.weight.grad, plain.weight.grad, rtol=0, atol=0)
        probe.close()
        self.assertFalse(watched._forward_hooks)  # pylint: disable=protected-access

    def test_real_vjp_and_partition_coordinates(self) -> None:
        """Full row coverage and the independent FP64 sample oracle agree on an exact small fixture."""
        values = torch.arange(64, dtype=torch.float32).reshape(1, 8, 8).to(torch.bfloat16) / 64
        weight = torch.eye(8, dtype=torch.bfloat16)
        gradient = values.flip(1)
        before = [value.clone() for value in (values, weight, gradient)]
        result = measure(values, weight, gradient)
        for variant in result['variants'].values():
            self.assertEqual(variant['count'], 64)
            self.assertEqual(variant['nonzero_count'], 0)
            self.assertEqual(variant['max_abs'], 0)
        self.assertEqual(result['sampled_fp64_oracle']['difference']['max_abs'], 0)
        torch.testing.assert_close(native_vjp(values, weight, gradient), gradient, rtol=0, atol=0)
        for after, expected in zip((values, weight, gradient), before):
            torch.testing.assert_close(after, expected, rtol=0, atol=0)

    def test_snapshot_precedes_existing_parameter_reshard_hook(self) -> None:
        """Capture the full weight before an earlier registered owner replaces it after forward."""
        head = torch.nn.Linear(8, 17, bias=False, dtype=torch.bfloat16)
        full_weight = head.weight
        values = torch.randn(1, 8, 8, dtype=torch.bfloat16, requires_grad=True)
        records = []

        def restore_shard(module: torch.nn.Linear, _args: tuple, _output: torch.Tensor) -> None:
            """Represent the existing FSDP owner's post-forward parameter replacement."""
            module.weight = torch.nn.Parameter(full_weight[:3].detach())

        existing = head.register_forward_hook(restore_shard)
        self.addCleanup(existing.remove)
        probe = HeadRowVJPProbe(head, records.append, lambda: {'logical_batch': 'reshard-boundary'})
        self.addCleanup(probe.close)
        output = head(values)
        self.assertEqual(list(head.weight.shape), [3, 8])
        self.assertEqual(list(probe.weight.shape), [17, 8])
        upstream = torch.randn_like(output)
        expected = native_vjp(values, full_weight, upstream)
        output.backward(upstream)
        self.assertEqual(records[0]['weight_shape'], [17, 8])
        torch.testing.assert_close(values.grad, expected, rtol=0, atol=0)
        self.assertIsNone(probe.weight)

    def test_failed_measurement_drops_private_snapshots(self) -> None:
        """An observer failure cannot keep the cloned head weight or leave hooks installed."""
        head = torch.nn.Linear(8, 17, bias=False, dtype=torch.bfloat16)
        values = torch.randn(1, 8, 8, dtype=torch.bfloat16, requires_grad=True)
        probe = HeadRowVJPProbe(head, lambda _value: None, lambda: {'step': 1})
        try:
            output = head(values)
            with mock.patch('head_row_vjp_probe.measure', side_effect=ValueError('oracle failed')):
                with self.assertRaisesRegex(ValueError, 'oracle failed'):
                    output.sum().backward()
            self.assertEqual(probe.state, 'failed')
            self.assertIsNone(probe.inputs)
            self.assertIsNone(probe.weight)
        finally:
            probe.close()
        self.assertFalse(head._forward_hooks)  # pylint: disable=protected-access

    def test_bound_and_nondifferentiable_calls_fail_before_capture(self) -> None:
        """Oversized or nondifferentiable calls cannot silently count as observed derivatives."""
        head = torch.nn.Linear(8, 17, bias=False, dtype=torch.bfloat16)
        values = torch.zeros(1, 8, 8, dtype=torch.bfloat16)
        probe = HeadRowVJPProbe(head, lambda _value: None, lambda: {'step': 1}, snapshot_bytes_limit=1)
        try:
            with self.assertRaisesRegex(ValueError, 'snapshot budget'):
                head(values)
            self.assertIsNone(probe.inputs)
        finally:
            probe.close()
        probe = HeadRowVJPProbe(head, lambda _value: None, lambda: {'step': 1})
        try:
            with torch.no_grad(), self.assertRaisesRegex(ValueError, 'differentiable'):
                head(values)
        finally:
            probe.close()


if __name__ == '__main__':
    test_result = unittest.TextTestRunner(verbosity=2).run(
        unittest.defaultTestLoader.loadTestsFromTestCase(HeadRowVJPTests))
    if not test_result.wasSuccessful():
        raise SystemExit(1)
    root = Path('/work')
    case = 'r129-f637-head-row-vjp-fsdp8-3-v1'
    config_path = root / 'configs' / (case + '.yaml')
    actual_config = parse_training_args([str(config_path)]).to_dict()
    expected_config = json.loads((root / 'runs/r129-f637-fp32-fsdp8-0-200-r4/config.resolved.json').read_bytes())
    expected_config['training']['train_iters'] = 3
    expected_config['checkpoint']['save_ckpt'] = False
    expected_config['checkpoint']['checkpoint_dir'] = '/work/checkpoints/' + case
    if actual_config != expected_config:
        raise AssertionError('The probe config changed more than train length and checkpoint output')
    if torch.cuda.is_initialized() or (hasattr(torch, 'npu') and torch.npu.is_initialized()):
        raise RuntimeError('The device-free probe check initialized an accelerator')
    path = root / 'evidence/f637-head-row-vjp-cpu-v3.json'
    with path.open('x', encoding='utf-8') as handle:
        json.dump({'tests': test_result.testsRun, 'status': 'PASS', 'npu_used': False,
                    'resolved_config': 'PASS', 'config_sha256': hashlib.sha256(config_path.read_bytes()).hexdigest(),
                    'source_sha256': {name: hashlib.sha256((root / 'tools' / name).read_bytes()).hexdigest()
                                      for name in ('head_row_vjp_probe.py', 'check_head_row_vjp_cpu.py',
                                                   'capture_head_row_vjp_training.py', 'fixed_pta_probe_common.py')},
                    'scope': 'CPU observation transparency and lifetime only; no real-head NPU row-invariance claim'},
                   handle, indent=2)
