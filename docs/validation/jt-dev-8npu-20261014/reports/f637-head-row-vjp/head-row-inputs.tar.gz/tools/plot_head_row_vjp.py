# Copyright 2026 Huawei Technologies Co., Ltd
#
# Licensed under the Apache License, Version 2.0 (the "License");
# you may not use this file except in compliance with the License.
# You may obtain a copy of the License at
#
# http://www.apache.org/licenses/LICENSE-2.0
#
# Unless required by applicable law or agreed to in writing, software
# distributed under the License is distributed on an "AS IS" BASIS,
# WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
# See the License for the specific language governing permissions and
# limitations under the License.
# ============================================================================

"""Plot the verified real-input local row-shape effect without implying training acceptance."""

import hashlib
import json
from pathlib import Path

import matplotlib
matplotlib.use('Agg')
import matplotlib.pyplot as plt  # pylint: disable=wrong-import-position


ROOT = Path(__file__).resolve().parents[1]


def main() -> None:
    """Show exact repeats/padding controls beside the complete local derivative differences."""
    source = ROOT / 'evidence/f637-head-row-vjp-fsdp8-3-v1-audit.json'
    audit = json.loads(source.read_bytes())
    if audit['execution_and_observation_audit'] != 'PASS' or audit['native_three_step_transparency'] != 'EXACT':
        raise ValueError('The real-input observer has not passed execution and transparency auditing')
    variants = audit['observed']['variants']
    keys = ['repeat', 'halves', 'tiles128', 'padded_halves']
    labels = ['全 4096 行重复', '拆成两半，各 2048 行', '拆成小块，每块 128 行', '两半补零回 4096 行']
    counts = [variants[key]['nonzero_count'] for key in keys]
    maxima = [variants[key]['max_abs'] for key in keys]
    colors = ['#147A74', '#BC5539', '#C58242', '#147A74']
    plt.rcParams.update({'font.family': 'Microsoft YaHei', 'font.size': 11, 'svg.fonttype': 'none',
                         'axes.spines.top': False, 'axes.spines.right': False})
    figure, axes = plt.subplots(1, 2, figsize=(15.5, 7.2), gridspec_kw={'width_ratios': [1.15, 1]})
    for axis, values, title in zip(axes, (counts, maxima), ('不同坐标数 / 20,971,520', '输入梯度最大绝对差')):
        axis.barh(range(4), values, color=colors, height=0.5)
        axis.set_yticks(range(4), labels if axis is axes[0] else [''] * 4)
        axis.invert_yaxis()
        axis.set_xlim(0, max(values) * 1.35)
        axis.set_title(title, loc='left', weight='bold', pad=18)
        axis.grid(axis='x', alpha=0.15)
        axis.set_axisbelow(True)
        for index, value in enumerate(values):
            text = f'{value:,}' if axis is axes[0] else ('0' if value == 0 else f'{value:.3e}')
            axis.text(value + max(values) * 0.025, index, text, va='center', weight='bold', color=colors[index])
    axes[0].set_xlabel('完整局部输入梯度逐坐标比较')
    axes[1].set_xlabel('局部 dX 绝对差（相同操作数）')
    axes[1].ticklabel_format(axis='x', style='sci', scilimits=(0, 0))
    figure.text(0.06, 0.94, '真实 LM head：行数变化可产生局部反向差异，补回原形状后相等',
                fontsize=19, weight='bold')
    figure.text(0.06, 0.875, '129 · CANN 9.2.0-beta.2 · 原配方 FSDP8 首步 rank0 · BF16 · 固定同一组实际操作数',
                fontsize=11, color='#4B5563')
    figure.text(0.06, 0.175, '观测透明性：3 步 × 8 rank 的主 loss、MTP、aux、total、梯度范数与原参考差值均为 0。',
                fontsize=11, color='#12655F')
    figure.text(0.06, 0.115, '局部结论：完整梯度存在行形状效应；64 个坐标与 FP64 求和后转回 BF16 的结果也相等。',
                fontsize=10.5, color='#374151')
    figure.text(0.06, 0.065, '边界：尚未证明 CP 上游梯度全部相同，也不是 200 步漂移的完整根因；下一步只替换共享 head 的 dX 做因果对照。',
                fontsize=10.5, color='#8A422C')
    figure.subplots_adjust(left=0.24, right=0.97, top=0.76, bottom=0.29, wspace=0.18)
    outputs = {}
    for suffix in ('png', 'svg'):
        path = ROOT / 'figures' / ('f637-head-row-vjp-zh.' + suffix)
        figure.savefig(path, dpi=170, facecolor='white')
        outputs[path.relative_to(ROOT).as_posix()] = hashlib.sha256(path.read_bytes()).hexdigest()
    plt.close(figure)
    report = {'source': source.relative_to(ROOT).as_posix(),
              'source_sha256': hashlib.sha256(source.read_bytes()).hexdigest(), 'outputs': outputs}
    (ROOT / 'evidence/f637-head-row-vjp-figure-manifest.json').write_text(json.dumps(report, indent=2) + '\n')
    print(json.dumps(report))


if __name__ == '__main__':
    main()
