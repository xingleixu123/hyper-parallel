# Copyright 2026 Huawei Technologies Co., Ltd
#
# Licensed under the Apache License, Version 2.0 (the "License");
# you may not use this file except in compliance with the License.
# You may obtain a copy of the License at
#
# http://www.apache.org/licenses/LICENSE-2.0
#
# Unless required by applicable law or agreed to in writing, software
# distributed under the License is distributed on an "AS IS" BASIS,
# WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
# See the License for the specific language governing permissions and
# limitations under the License.
# ============================================================================

"""Check the exact short head-probe reservation before any device/container access."""

import hashlib
from pathlib import Path
import tempfile
import unittest
from unittest.mock import patch

from check_pr214_guard import GUARD


class HeadRowVJPGuardTests(unittest.TestCase):
    """Preserve the eight-card numerical reference and the short reservation limit."""

    def setUp(self) -> None:
        """Use private source paths and simulated free-card reports."""
        directory = self.enterContext(tempfile.TemporaryDirectory())  # pylint: disable=consider-using-with
        root = Path(directory)
        (root / 'repo').mkdir()
        self.enterContext(patch.object(GUARD, 'ROOT', root))
        self.request = {'host': '129', 'case': 'r129-f637-head-row-vjp-fsdp8-3-v1', 'cards': 8,
                        'timeout_seconds': 600, 'port': 30384, 'runner': '/work/tools/run_fair_head_row_vjp.sh',
                        'source': 'fixed-source', 'patch_sha256': hashlib.sha256(b'').hexdigest(),
                        'files': {}, 'image': sorted(GUARD.ALLOWED_IMAGES)[0]}

    def test_unprepared_reservations_fail_before_external_commands(self) -> None:
        """Do not silently reduce cards, switch host, extend the hold, or reuse another case/port."""
        changes = ({'cards': 4}, {'host': '125'}, {'timeout_seconds': 900}, {'timeout_seconds': 599},
                   {'port': 30383}, {'case': 'r129-f637-head-row-vjp-fsdp8-3-v2'})
        for change in changes:
            with self.subTest(change=change), patch.object(GUARD.subprocess, 'check_output') as external:
                with self.assertRaises(ValueError):
                    GUARD.remote_job({**self.request, **change})
                external.assert_not_called()

    def test_seven_free_cards_do_not_start_a_container(self) -> None:
        """A foreign process on any selected device means waiting for eight free devices."""
        idle = {'healthy': True, 'empty': True, 'pids': [], 'core': 0, 'hbm_mb': 3000}
        busy = {**idle, 'empty': False, 'pids': [1234]}
        snapshot = {index: idle for index in range(7)}
        snapshot[7] = busy
        with patch.object(GUARD.subprocess, 'check_output', side_effect=['fixed-source\n', b'']), \
                patch.object(GUARD, 'card_snapshot', return_value=snapshot), \
                patch.object(GUARD.subprocess, 'run') as execute:
            receipt = GUARD.remote_job(self.request)
        self.assertFalse(receipt['attempted'])
        self.assertEqual(receipt['reason'], 'insufficient-free-devices')
        execute.assert_not_called()

    def test_only_recorded_alternate_storage_is_allowed(self) -> None:
        """Do not follow arbitrary paths, another host's path or a disguised traversal."""
        self.assertEqual(GUARD.remote_workspace(self.request), GUARD.ROOT)
        alternate = GUARD.ALTERNATE_ROOT.as_posix()
        self.assertEqual(GUARD.remote_workspace({**self.request, 'workspace': alternate}), GUARD.ALTERNATE_ROOT)
        changes = ({'workspace': '/tmp/unknown'}, {'workspace': alternate + '/../unknown'},
                   {'workspace': alternate, 'host': '125'})
        for change in changes:
            with self.subTest(change=change), patch.object(GUARD.subprocess, 'check_output') as external:
                with self.assertRaisesRegex(ValueError, 'authorized task directories'):
                    GUARD.remote_job({**self.request, **change})
                external.assert_not_called()


if __name__ == '__main__':
    unittest.main(verbosity=2)
