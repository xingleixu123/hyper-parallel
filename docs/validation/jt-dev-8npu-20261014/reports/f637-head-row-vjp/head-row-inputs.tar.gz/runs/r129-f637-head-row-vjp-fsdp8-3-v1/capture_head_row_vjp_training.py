# Copyright 2026 Huawei Technologies Co., Ltd
#
# Licensed under the Apache License, Version 2.0 (the "License");
# you may not use this file except in compliance with the License.
# You may obtain a copy of the License at
#
# http://www.apache.org/licenses/LICENSE-2.0
#
# Unless required by applicable law or agreed to in writing, software
# distributed under the License is distributed on an "AS IS" BASIS,
# WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
# See the License for the specific language governing permissions and
# limitations under the License.
# ============================================================================

"""Observe the first real FSDP head derivative while preserving the native three-step training path."""

import json
from typing import Any

import capture_training
from fixed_pta_probe_common import tensor_sha256
from head_row_vjp_probe import HeadRowVJPProbe

from hyper_parallel.trainer.callbacks.base import Callback


ORIGINAL_TRAINER = capture_training.TextTrainer
ORIGINAL_RECORDER = capture_training.InputIdentityRecorder
OBSERVER = None
BATCH = {}


class HeadInputIdentity(ORIGINAL_RECORDER):
    """Keep the usual all-rank evidence and identify only the selected first local batch."""

    def record(self, model_inputs: dict, loss_inputs: dict) -> None:
        """Record raw local token identities before the chosen real forward executes."""
        super().record(model_inputs, loss_inputs)
        if OBSERVER is None or OBSERVER.state != 'idle':
            return
        for name, value in [('input_ids', model_inputs['input_ids']), ('shift_labels', loss_inputs['shift_labels'])]:
            if hasattr(value, 'to_local'):
                raise ValueError('The first head probe expects unsharded TP1/CP1 input fields')
            BATCH[name] = {'shape': list(value.shape), 'dtype': str(value.dtype),
                           'sha256': tensor_sha256(value.detach().cpu())}


class HeadProbeCompletion(Callback):
    """Require exactly one completed local head observation on the chosen rank."""

    def on_train_end(self, state: object, **kwargs: object) -> None:
        """A successful training exit must also have released the diagnostic's private buffers."""
        if state.global_step != 3:
            raise ValueError('The native observation control did not finish all three steps')
        if capture_training.RANK == 0 and (OBSERVER.state != 'done' or OBSERVER.inputs is not None
                                          or OBSERVER.weight is not None):
            raise ValueError('The selected head VJP was not completed and released')


def build_trainer(*args: Any, **kwargs: Any) -> Any:
    """Observe one first-step head on rank0 of the unchanged native FSDP8 recipe."""
    global OBSERVER  # pylint: disable=global-statement
    trainer = ORIGINAL_TRAINER(*args, **kwargs)
    base = trainer.base
    if (base.train_iters != 3 or base.state.global_step != 0 or base.mesh.tp_size != 1
            or base.mesh.cp_size != 1 or base.mesh.ep_size != 1 or base.mesh.pp_size != 1 or base.mesh.dp_size != 8):
        raise ValueError('This real-input VJP observation requires the three-step native FSDP8 control')

    def identity() -> dict:
        """Bind the selected call to its first optimizer step and actual logical input."""
        if base.state.global_step != 0 or set(BATCH) != {'input_ids', 'shift_labels'}:
            raise ValueError('The selected first head has no current input identity')
        return {'step': 1, 'rank': 0, 'fields': dict(BATCH), 'module': 'lm_head', 'selected_call': 0}

    def record(result: dict) -> None:
        """Persist a bounded scalar summary after checking the actual production dimensions."""
        if result['input_shape'] != [1, 4096, 5120] or result['weight_shape'] != [152064, 5120]:
            raise ValueError('The selected head dimensions differ from the frozen production recipe')
        if len(json.dumps(result).encode()) > 128 * 1024:
            raise ValueError('Head VJP summary exceeds the metadata budget')
        capture_training.write_json('head-row-vjp-rank0.json', result)

    if capture_training.RANK == 0:
        OBSERVER = HeadRowVJPProbe(base.model.lm_head, record, identity)
    base._callbacks.append(HeadProbeCompletion(base))  # pylint: disable=protected-access
    capture_training.write_json(f'head-row-vjp-mode-rank{capture_training.RANK}.json', {
        'selected': capture_training.RANK == 0, 'training_steps': 3, 'numeric_recipe_changed': False,
        'observation': 'first real LM head input VJP; native autograd on identical private operands',
        'maximum_private_snapshot_bytes': 2 * 1024 ** 3,
        'scope': 'No training-gradient replacement; extra diagnostic compute/memory, no production performance claim',
    })
    return trainer


def main() -> None:
    """Run normal Trainer evidence and clean up only this probe's hooks/storage."""
    capture_training.TextTrainer = build_trainer
    capture_training.InputIdentityRecorder = HeadInputIdentity
    try:
        capture_training.main()
    finally:
        if OBSERVER is not None:
            OBSERVER.close()


if __name__ == '__main__':
    main()
