# Copyright 2026 Huawei Technologies Co., Ltd
#
# Licensed under the Apache License, Version 2.0 (the "License");
# you may not use this file except in compliance with the License.
# You may obtain a copy of the License at
#
# http://www.apache.org/licenses/LICENSE-2.0
#
# Unless required by applicable law or agreed to in writing, software
# distributed under the License is distributed on an "AS IS" BASIS,
# WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
# See the License for the specific language governing permissions and
# limitations under the License.
# ============================================================================

"""固定 PTA 探针的数据、行身份与有限统计；不设置设备或确定性状态。"""

from __future__ import annotations

from collections import Counter
from dataclasses import dataclass
import hashlib
import math
from typing import Any

import torch  # pylint: disable=forbidden-backend-import
# 没有公开的逐算子旁路观察接口；此诊断 mode 只转发调用并保留标量元数据。
from torch.utils._python_dispatch import TorchDispatchMode  # pylint: disable=forbidden-backend-import


SEED = 20261016
ROWS = 4096
HIDDEN = 5120
LINEAR_IN = 1536
LINEAR_OUT = 24576
EPSILON = 1.0e-6
SOURCE = "18602c4524dc664b81b2bad9a7b624455ce1494f"
PTA_COMMIT = "fa0f83fe49d309dcbc31e264e9e6ed6e5dc49d2d"
IMAGE = "sha256:5f9e677f439d11ab4e7c888f54b142335a27eee7411cbd2ce894a4798a70146d"


@dataclass
class ProbeData:
    """同一全局行集合的 CPU BF16 输入；每级通过独立 CPU generator 重建。"""

    kind: str
    inputs: torch.Tensor
    weight: torch.Tensor
    output_gradient: torch.Tensor
    permutation: torch.Tensor

    def metadata(self) -> dict[str, Any]:
        """保存输入身份，不保存大张量值。"""
        return {"kind": self.kind, "seed": SEED + (self.kind == "linear"),
                "cpu_generation": "FP32 randn then BF16 round",
                "operands": {name: {**tensor_metadata(value), "sha256": tensor_sha256(value)}
                             for name, value in (("input", self.inputs), ("weight", self.weight),
                                                 ("output_gradient", self.output_gradient),
                                                 ("permutation", self.permutation))}}


def make_data(kind: str, *, rows: int = ROWS, hidden: int = HIDDEN,
              linear_in: int = LINEAR_IN, linear_out: int = LINEAR_OUT) -> ProbeData:
    """只在 CPU 生成；缩小参数仅供独立 CPU 合约测试使用。"""
    if kind not in ("rmsnorm", "linear") or rows < 2 or rows % 2:
        raise ValueError("Expected rmsnorm/linear and a positive even row count")
    if min(hidden, linear_in, linear_out) <= 0:
        raise ValueError("Feature dimensions must be positive")
    generator = torch.Generator(device="cpu").manual_seed(SEED + (kind == "linear"))
    width = hidden if kind == "rmsnorm" else linear_in
    inputs = (torch.randn(rows, width, generator=generator, device="cpu", dtype=torch.float32) * 0.5)
    inputs = inputs.to(torch.bfloat16)
    if kind == "rmsnorm":
        weight = torch.ones(hidden, device="cpu", dtype=torch.float32)
        weight = (weight + torch.randn(hidden, generator=generator, device="cpu", dtype=torch.float32) * 0.1)
        weight = weight.to(torch.bfloat16)
        output_width = hidden
    else:
        weight = torch.randn(linear_out, linear_in, generator=generator, device="cpu", dtype=torch.float32)
        weight = (weight * 0.02).to(torch.bfloat16)
        output_width = linear_out
    output_gradient = torch.randn(rows, output_width, generator=generator, device="cpu", dtype=torch.float32)
    output_gradient = (output_gradient * 0.1).to(torch.bfloat16)
    permutation = torch.randperm(rows, generator=generator, device="cpu")
    return ProbeData(kind, inputs, weight, output_gradient, permutation)


def tensor_metadata(value: torch.Tensor) -> dict[str, Any]:
    """只读取张量布局和 dtype 元数据。"""
    return {"shape": list(value.shape), "stride": list(value.stride()), "dtype": str(value.dtype),
            "device": str(value.device), "requires_grad": value.requires_grad}


def tensor_sha256(value: torch.Tensor) -> str:
    """CPU 连续张量按原始字节计算 SHA，包括 BF16 的真实位模式。"""
    if value.device.type != "cpu":
        raise ValueError("Input hashing requires a CPU tensor")
    array = value.detach().contiguous().view(torch.uint8).numpy()
    return hashlib.sha256(memoryview(array).cast("B")).hexdigest()


def row_groups(data: ProbeData, variant: str) -> list[torch.Tensor]:
    """返回每次计算的 global row IDs；置换后的分区仍使用这份身份。"""
    rows = data.inputs.shape[0]
    order = data.permutation if variant in ("permutation", "permuted_partition") else torch.arange(rows, device="cpu")
    if variant in ("reference", "repeat", "permutation"):
        return [order]
    if variant in ("partition", "permuted_partition"):
        return list(order.split(rows // 2))
    raise ValueError(f"Unknown row transformation: {variant}")


def aligned_reference(reference: torch.Tensor, global_rows: torch.Tensor) -> torch.Tensor:
    """候选第 i 行只能与 reference[global_rows[i]] 比，不比较错误的局部行号。"""
    if reference.device.type != "cpu" or global_rows.device.type != "cpu" or global_rows.dtype != torch.int64:
        raise ValueError("Row alignment requires CPU reference and int64 CPU row IDs")
    if global_rows.ndim != 1 or global_rows.numel() != torch.unique(global_rows).numel():
        raise ValueError("Each comparison group must contain distinct global row IDs")
    if not global_rows.numel() or global_rows.min().item() < 0 or global_rows.max().item() >= reference.shape[0]:
        raise ValueError("Global row IDs are empty or outside the reference")
    return reference.index_select(0, global_rows)


def difference_stats(actual: torch.Tensor, expected: torch.Tensor) -> dict[str, Any]:
    """分块计算全量误差；不因大 Linear 输出一次建立完整 FP64 差分副本。"""
    if actual.device.type != "cpu" or expected.device.type != "cpu" or actual.shape != expected.shape:
        raise ValueError("Comparison requires equal shapes on CPU")
    actual_flat, expected_flat = actual.reshape(-1), expected.reshape(-1)
    count, nonzero, maximum, absolute_sum, squared_sum = actual.numel(), 0, 0.0, 0.0, 0.0
    for start in range(0, count, 262144):
        left = actual_flat[start:start + 262144].double()
        right = expected_flat[start:start + 262144].double()
        if not torch.isfinite(left).all() or not torch.isfinite(right).all():
            raise ValueError("Non-finite output or gradient in comparison")
        delta = (left - right).abs()
        nonzero += int(torch.count_nonzero(delta).item())
        maximum = max(maximum, float(delta.max().item()))
        absolute_sum += float(delta.sum().item())
        squared_sum += float(delta.square().sum().item())
    return {"count": count, "nonzero_count": nonzero, "max_abs": maximum,
            "absolute_sum": absolute_sum, "squared_sum": squared_sum,
            "mean_abs": absolute_sum / max(count, 1), "rms_abs": math.sqrt(squared_sum / max(count, 1)),
            "actual_dtype": str(actual.dtype), "reference_dtype": str(expected.dtype)}


def combine_stats(records: list[dict[str, Any]]) -> dict[str, Any]:
    """把互不重叠分区的原始计数与和合并，避免平均各分区均值。"""
    if not records:
        raise ValueError("Cannot combine an empty comparison")
    count = sum(row["count"] for row in records)
    absolute_sum = sum(row["absolute_sum"] for row in records)
    squared_sum = sum(row["squared_sum"] for row in records)
    return {"count": count, "nonzero_count": sum(row["nonzero_count"] for row in records),
            "max_abs": max(row["max_abs"] for row in records), "absolute_sum": absolute_sum,
            "squared_sum": squared_sum, "mean_abs": absolute_sum / max(count, 1),
            "rms_abs": math.sqrt(squared_sum / max(count, 1))}


def sample_indices(length: int) -> torch.Tensor:
    """固定八个以内分散坐标，用于有限 oracle 和跨级别样本。"""
    if length <= 0:
        raise ValueError("Sample dimension must be positive")
    candidates = {0, 1, length // 4, length // 2 - 1, length // 2, 3 * length // 4, length - 2, length - 1}
    return torch.tensor(sorted(index for index in candidates if 0 <= index < length), dtype=torch.int64, device="cpu")


def oracle_samples(data: ProbeData, forward: torch.Tensor, input_gradient: torch.Tensor) -> dict[str, Any]:
    """CPU FP64 数学样本，仅辅助解释；不宣称验证 NPU 内核或全量误差。"""
    rows = sample_indices(data.inputs.shape[0])
    inputs = data.inputs.index_select(0, rows).double()
    gradient = data.output_gradient.index_select(0, rows).double()
    if data.kind == "rmsnorm":
        weight = data.weight.double()
        inverse = (inputs.square().mean(-1, keepdim=True) + EPSILON).rsqrt()
        scaled = gradient * weight
        expected_forward = inputs * inverse * weight
        expected_gradient = scaled * inverse - inputs * inverse.pow(3) * (scaled * inputs).mean(-1, keepdim=True)
        columns = torch.arange(inputs.shape[-1], device="cpu")
        forward_columns = columns
    else:
        columns = sample_indices(data.inputs.shape[-1])
        forward_columns = sample_indices(data.output_gradient.shape[-1])
        expected_forward = inputs @ data.weight.index_select(0, forward_columns).double().T
        expected_gradient = gradient @ data.weight.index_select(1, columns).double()
    actual_forward = forward.index_select(0, rows).index_select(1, forward_columns)
    actual_gradient = input_gradient.index_select(0, rows).index_select(1, columns)
    return {"scope": "CPU FP64 sampled mathematical oracle, not a NPU acceptance test",
            "global_rows": rows.tolist(), "forward_columns_count": len(forward_columns),
            "input_gradient_columns_count": len(columns),
            "forward": difference_stats(actual_forward, expected_forward),
            "input_gradient": difference_stats(actual_gradient, expected_gradient)}


class OperatorTrace(TorchDispatchMode):
    """转发全部算子，只记录有限名称/形状；不持有参数、输出或 autograd 图。"""

    def __init__(self) -> None:
        """每次原生 forward/backward 都使用相同观察方式。"""
        super().__init__()
        self.phase = "forward"
        self.counts: Counter[str] = Counter()
        self.first_calls: list[dict[str, Any]] = []
        self.truncated = False

    def __torch_dispatch__(self, function: Any, _types: Any, args: tuple = (), kwargs: dict | None = None) -> Any:
        """保留 dispatcher 数学调用与返回对象，仅抽取标量元数据。"""
        result = function(*args, **(kwargs or {}))
        key = f"{self.phase}:{function}"
        if key not in self.counts and len(self.counts) >= 128:
            key = "other_operators_after_limit"
            self.truncated = True
        self.counts[key] += 1
        if self.counts[key] == 1:
            if len(self.first_calls) >= 128:
                self.truncated = True
            else:
                self.first_calls.append({"phase": self.phase, "operator": str(function),
                                         "inputs": [tensor_metadata(arg) for arg in args
                                                    if isinstance(arg, torch.Tensor)][:4],
                                         "output": tensor_metadata(result)
                                         if isinstance(result, torch.Tensor) else type(result).__name__})
        return result

    def metadata(self) -> dict[str, Any]:
        """这些是 dispatcher 分支证据，不是 CANN 内部算法/强一致开关的 readback。"""
        return {"counts": dict(self.counts), "first_calls": self.first_calls, "truncated": self.truncated,
                "scope": "actual PyTorch dispatcher operations; internal CANN algorithm is not observable"}
