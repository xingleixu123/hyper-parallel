# Copyright 2026 Huawei Technologies Co., Ltd
#
# Licensed under the Apache License, Version 2.0 (the "License");
# you may not use this file except in compliance with the License.
# You may obtain a copy of the License at
#
# http://www.apache.org/licenses/LICENSE-2.0
#
# Unless required by applicable law or agreed to in writing, software
# distributed under the License is distributed on an "AS IS" BASIS,
# WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
# See the License for the specific language governing permissions and
# limitations under the License.
# ============================================================================

"""Replay a selected real head VJP on identical operands without modifying training gradients."""

from collections.abc import Callable
from typing import Any

import torch  # pylint: disable=forbidden-backend-import
from torch.nn import functional  # pylint: disable=forbidden-backend-import

from fixed_pta_probe_common import combine_stats, difference_stats, sample_indices, tensor_sha256


NATIVE_LINEAR = functional.linear


def native_vjp(inputs: torch.Tensor, weight: torch.Tensor, gradient: torch.Tensor) -> torch.Tensor:
    """Use ordinary autograd for the local Linear input derivative, isolated from the training graph."""
    with torch.enable_grad():
        values = inputs.detach().requires_grad_(True)
        output = NATIVE_LINEAR(values, weight.detach())
        result, = torch.autograd.grad(output, values, grad_outputs=gradient.detach())
    return result.detach()


def measure(inputs: torch.Tensor, weight: torch.Tensor, gradient: torch.Tensor) -> dict[str, Any]:
    """Compare full rows, repeated rows, halves, fixed tiles and halves padded to full shape."""
    if (inputs.ndim != 3 or inputs.shape[0] != 1 or inputs.shape[1] < 2 or inputs.shape[1] % 2
            or weight.ndim != 2 or weight.shape[1] != inputs.shape[2]
            or gradient.shape != (*inputs.shape[:2], weight.shape[0])):
        raise ValueError('Expected one even-length sequence and an aligned full-vocabulary Linear')
    if any(type(value) not in (torch.Tensor, torch.nn.Parameter) for value in (inputs, weight, gradient)):
        raise ValueError('This local VJP probe excludes DTensor or other tensor subclasses')
    if any(value.dtype != torch.bfloat16 or value.device != inputs.device for value in (inputs, weight, gradient)):
        raise ValueError('This probe requires colocated actual BF16 operands')
    if functional.linear is not NATIVE_LINEAR:
        raise RuntimeError('Another functional Linear intervention is active')
    if inputs.device.type == 'npu' and torch.npu.matmul.allow_hf32:
        raise ValueError('HF32 must remain disabled in the frozen numerical recipe')
    versions = [value._version for value in (inputs, weight, gradient)]  # pylint: disable=protected-access
    rows = inputs.shape[1]
    reference = native_vjp(inputs, weight, gradient).cpu()
    variants = {}
    for name, block, padded in [('repeat', rows, False), ('halves', rows // 2, False),
                                 ('tiles128', min(128, rows), False), ('padded_halves', rows // 2, True)]:
        records = []
        for start in range(0, rows, block):
            stop = min(start + block, rows)
            values, derivative = inputs[:, start:stop], gradient[:, start:stop]
            if padded:
                values = torch.zeros_like(inputs)
                derivative = torch.zeros_like(gradient)
                values[:, start:stop].copy_(inputs[:, start:stop])
                derivative[:, start:stop].copy_(gradient[:, start:stop])
            actual = native_vjp(values, weight, derivative)
            if padded:
                actual = actual[:, start:stop]
            records.append(difference_stats(actual.cpu(), reference[:, start:stop]))
            del values, derivative, actual
        variants[name] = combine_stats(records)
        if variants[name]['count'] != reference.numel():
            raise ValueError('Row comparison did not cover each derivative coordinate once')
    row_ids, columns = sample_indices(rows), sample_indices(weight.shape[1])
    selected_gradient = gradient[0].index_select(0, row_ids.to(gradient.device)).cpu()
    selected_weight = weight.index_select(1, columns.to(weight.device)).cpu()
    expected_samples = (selected_gradient.double() @ selected_weight.double()).to(reference.dtype)
    actual_samples = reference[0].index_select(0, row_ids).index_select(1, columns)
    if versions != [value._version for value in (inputs, weight, gradient)]:  # pylint: disable=protected-access
        raise RuntimeError('The supposedly observational replay modified an operand')
    return {'input_shape': list(inputs.shape), 'weight_shape': list(weight.shape),
            'gradient_shape': list(gradient.shape), 'dtype': str(inputs.dtype),
            'input_sha256': tensor_sha256(inputs.cpu()), 'reference_vjp_sha256': tensor_sha256(reference),
            'reference_vjp_elements': reference.numel(), 'variants': variants,
            'sampled_fp64_oracle': {'rows': row_ids.tolist(), 'columns': columns.tolist(),
                                    'difference': difference_stats(actual_samples, expected_samples),
                                    'gradient_rows_sha256': tensor_sha256(selected_gradient),
                                    'weight_columns_sha256': tensor_sha256(selected_weight)},
            'scope': ('Local Linear VJP on identical real operands only. Full derivative comparisons, '
                      'sampled FP64 oracle. No claim about actual upstream tensor equality, weight gradients, '
                      'communications, whole-training causality or 200-step acceptance.'),
            'training_gradient_replaced': False, 'production_performance_claim': False}


class HeadRowVJPProbe:
    """Observe the first selected head call and release its private snapshots immediately after VJP replay."""

    def __init__(self, module: torch.nn.Linear, sink: Callable[[dict], None],
                 identity: Callable[[], dict], *, snapshot_bytes_limit: int = 2 * 1024 ** 3) -> None:
        """Bind one existing module without altering functional dispatch or module inputs."""
        if not isinstance(module, torch.nn.Linear) or module.bias is not None:
            raise ValueError('A bias-free Linear head is required')
        if (isinstance(snapshot_bytes_limit, bool) or not isinstance(snapshot_bytes_limit, int)
                or snapshot_bytes_limit < 1):
            raise ValueError('A positive private snapshot bound is required')
        self.sink = sink
        self.identity = identity
        self.limit = snapshot_bytes_limit
        self.state = 'idle'
        self.inputs = self.weight = None
        self.gradient_handle = None
        self.handle = module.register_forward_hook(self._forward)

    def _forward(self, module: torch.nn.Linear, args: tuple, output: torch.Tensor) -> None:
        if self.state != 'idle':
            return
        if (not args or not isinstance(args[0], torch.Tensor) or not isinstance(output, torch.Tensor)
                or not output.requires_grad):
            raise ValueError('Selected head call has no differentiable tensor boundary')
        inputs, weight = args[0], module.weight
        if type(inputs) not in (torch.Tensor,) or type(weight) not in (torch.Tensor, torch.nn.Parameter):
            raise ValueError('Head snapshots must be ordinary local tensors')
        needed = inputs.numel() * inputs.element_size() + weight.numel() * weight.element_size()
        if needed > self.limit:
            raise ValueError('The selected head exceeds the private snapshot budget')
        identity = dict(self.identity())
        if not identity:
            raise ValueError('The selected head lacks a logical input identity')
        with torch.no_grad():
            self.inputs = inputs.detach().clone()
            self.weight = weight.detach().clone()
        self.state = 'waiting-for-gradient'

        def observe(gradient: torch.Tensor) -> None:
            """Replay with private operands and return no replacement gradient to autograd."""
            if self.state != 'waiting-for-gradient':
                raise RuntimeError('Selected head derivative observed more than once')
            self.state = 'measuring'
            try:
                result = measure(self.inputs, self.weight, gradient)
                result.update(identity=identity, private_snapshot_bytes=needed)
                self.sink(result)
                self.state = 'done'
            except BaseException:
                self.state = 'failed'
                raise
            finally:
                self.inputs = self.weight = None
        self.gradient_handle = output.register_hook(observe)

    def close(self) -> None:
        """Remove only our hooks and drop private storage on success or interruption."""
        self.handle.remove()
        if self.gradient_handle is not None:
            self.gradient_handle.remove()
        self.inputs = self.weight = None
