# Copyright 2026 Huawei Technologies Co., Ltd
#
# Licensed under the Apache License, Version 2.0 (the "License");
# you may not use this file except in compliance with the License.
# You may obtain a copy of the License at
#
# http://www.apache.org/licenses/LICENSE-2.0
#
# Unless required by applicable law or agreed to in writing, software
# distributed under the License is distributed on an "AS IS" BASIS,
# WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
# See the License for the specific language governing permissions and
# limitations under the License.
# ============================================================================

"""Plot all three observed steps without treating one improved step as complete training acceptance."""

import hashlib
import json
from pathlib import Path

import matplotlib
matplotlib.use('Agg')
import matplotlib.pyplot as plt  # pylint: disable=wrong-import-position


ROOT = Path(__file__).resolve().parents[1]


def main() -> None:
    """Show mixed downstream effects alongside the exact scope and executed local intervention."""
    path = ROOT / 'evidence/e213-head-pad-dx-three-step-errors.json'
    data = json.loads(path.read_bytes())
    audit_path = ROOT / 'evidence/e213-head-pad-dx-causal-audit.json'
    audit = json.loads(audit_path.read_bytes())
    if (data['ranks'] != 8 or [row['step'] for row in data['steps']] != [1, 2, 3]
            or audit['local_intervention']['actual_backward_calls'] != 96):
        raise ValueError('The figure requires all three steps and all actual local interventions')
    plt.rcParams.update({'font.family': 'Microsoft YaHei', 'font.size': 11, 'svg.fonttype': 'none',
                         'axes.spines.top': False, 'axes.spines.right': False})
    figure, axes = plt.subplots(1, 2, figsize=(14.5, 7))
    steps = [row['step'] for row in data['steps']]
    metrics = ('training/foundation_loss/lm', 'training/grad_norm')
    titles = ('主 LM loss：对历史 FSDP 的最大绝对差', '梯度范数：对历史 FSDP 的最大绝对差')
    for axis, key, title in zip(axes, metrics, titles):
        for field, label, color, marker in [('native_vs_fsdp_max', 'CP2 原生对照', '#B65339', 'o'),
                                           ('padded_vs_fsdp_max', 'CP2 仅 head dX 补零', '#147A74', 's')]:
            values = [row['metrics'][key][field] for row in data['steps']]
            axis.plot(steps, values, marker=marker, color=color, label=label, linewidth=2.3, markersize=7)
            axis.annotate(f'{values[-1]:.6g}', (3, values[-1]), xytext=(-8, 12 if field.startswith('native') else -20),
                          textcoords='offset points', ha='right', color=color, weight='bold')
        axis.set_title(title, loc='left', fontsize=12, weight='bold', pad=14)
        axis.set_xticks(steps)
        axis.set_xlim(0.9, 3.15)
        axis.set_ylim(bottom=0)
        axis.set_xlabel('训练步（完整 8 rank 逐步取最大值）')
        axis.grid(alpha=0.2)
        axis.legend(loc='upper left', frameon=False, fontsize=10)
        axis.ticklabel_format(axis='y', style='sci', scilimits=(0, 0))
    figure.text(0.06, 0.94, '共享输出头 dX 补零：短程影响已证实，改善并不单调', fontsize=18, weight='bold')
    figure.text(0.06, 0.875, '129 · CANN 9.2.0-beta.2 · 3 步 × 8 rank · CP 对照/候选源码 558eff5 · LR 与 loss 系数不变',
                fontsize=10.5, color='#4B5563')
    figure.text(0.06, 0.17, '第 2 步 LM 差增大：0.0000534 → 0.0000820；第 3 步减小：0.0003986 → 0.0001450。',
                fontsize=11, color='#7C432E')
    local = audit['local_intervention']
    figure.text(0.06, 0.115, f"第一步前向各 loss 与 CP 原生完全一致；96 次反向中 {local['nonzero_coordinates']:,} 个 dX 坐标改变，"
                f"最大差 {local['maximum_local_change']:.3e}。", fontsize=10.5, color='#374151')
    figure.text(0.06, 0.06, '仅作定位：历史 FSDP 源码为 18602c4，源迁移已做三步透明性对照；本图不代表同源码完整 200 步达标。',
                fontsize=10.5, color='#7C432E')
    figure.subplots_adjust(left=0.08, right=0.97, top=0.74, bottom=0.3, wspace=0.3)
    outputs = {}
    for suffix in ('png', 'svg'):
        output = ROOT / 'figures' / ('e213-head-pad-dx-three-step-zh.' + suffix)
        figure.savefig(output, dpi=170, facecolor='white')
        outputs[output.relative_to(ROOT).as_posix()] = hashlib.sha256(output.read_bytes()).hexdigest()
    plt.close(figure)
    manifest = {'inputs': {str(item.relative_to(ROOT)): hashlib.sha256(item.read_bytes()).hexdigest()
                            for item in (path, audit_path)}, 'outputs': outputs, 'scope': data['scope']}
    (ROOT / 'evidence/e213-head-pad-dx-figure-manifest.json').write_text(json.dumps(manifest, indent=2) + '\n')
    print(json.dumps(manifest))


if __name__ == '__main__':
    main()
