# Copyright 2026 Huawei Technologies Co., Ltd
#
# Licensed under the Apache License, Version 2.0 (the "License");
# you may not use this file except in compliance with the License.
# You may obtain a copy of the License at
#
# http://www.apache.org/licenses/LICENSE-2.0
#
# Unless required by applicable law or agreed to in writing, software
# distributed under the License is distributed on an "AS IS" BASIS,
# WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
# See the License for the specific language governing permissions and
# limitations under the License.
# ============================================================================

"""Exercise single-device selection and the owned-container memory stop path."""

import hashlib
import json
from pathlib import Path
from types import SimpleNamespace
import tempfile
import unittest
from unittest.mock import patch

from check_pr214_guard import GUARD


class ProbeGuardTests(unittest.TestCase):
    """All subprocess/device interactions are mocked, including the complete stop path."""

    def setUp(self) -> None:
        """Give each test an isolated temporary task root."""
        directory = self.enterContext(tempfile.TemporaryDirectory())  # pylint: disable=consider-using-with
        self.root = Path(directory)
        (self.root / 'repo').mkdir()
        self.enterContext(patch.object(GUARD, 'ROOT', self.root))
        self.request = {'host': '129', 'case': 'r129-f637-pta-levels12-1npu-v2', 'cards': 1,
                        'timeout_seconds': 600, 'port': 30376,
                        'runner': '/work/tools/run_fair_fixed_pta_level_probe.sh', 'source': 'fixed-source',
                        'patch_sha256': hashlib.sha256(b'').hexdigest(), 'files': {},
                        'image': sorted(GUARD.ALLOWED_IMAGES)[0]}
        self.idle = {'healthy': True, 'empty': True, 'pids': [], 'core': 0, 'hbm_mb': 3000}

    def test_invalid_request_never_calls_external_commands(self) -> None:
        """Reject expanded resources, another host, or an unreviewed run identity."""
        for change in ({'cards': 8}, {'host': '125'}, {'timeout_seconds': 601},
                       {'timeout_seconds': 599}, {'case': 'another-case'}, {'port': 30377}):
            with self.subTest(change=change), patch.object(GUARD.subprocess, 'check_output') as external:
                with self.assertRaisesRegex(ValueError, 'pinned single-card'):
                    GUARD.remote_job({**self.request, **change})
                external.assert_not_called()

    def test_no_free_card_does_not_create_container(self) -> None:
        """Busy cards never trigger a stop or creation operation."""
        busy = {5: {**self.idle, 'empty': False, 'pids': [77]}}
        with patch.object(GUARD.subprocess, 'check_output', side_effect=['fixed-source\n', b'']) as external, \
                patch.object(GUARD, 'card_snapshot', return_value=busy):
            receipt = GUARD.remote_job(self.request)
        self.assertFalse(receipt['attempted'])
        self.assertEqual(receipt['reason'], 'insufficient-free-devices')
        self.assertEqual(external.call_count, 2)

    def test_level2_retry_keeps_runner_case_port_and_resource_contract(self) -> None:
        """A retry cannot exchange launchers or expand its one-card reservation."""
        retry = {**self.request, 'case': 'r129-f637-pta-level2-1npu-v3', 'port': 30377,
                 'runner': '/work/tools/run_fair_fixed_pta_level2_retry.sh'}
        for change in ({'runner': self.request['runner']}, {'case': self.request['case']},
                       {'cards': 8}, {'host': '125'}, {'timeout_seconds': 601}, {'port': 30376}):
            with self.subTest(change=change), patch.object(GUARD.subprocess, 'check_output') as external:
                with self.assertRaisesRegex(ValueError, 'pinned single-card'):
                    GUARD.remote_job({**retry, **change})
                external.assert_not_called()
        with patch.object(GUARD.subprocess, 'check_output', side_effect=['fixed-source\n', b'']), \
                patch.object(GUARD, 'card_snapshot', return_value={}):
            receipt = GUARD.remote_job(retry)
        self.assertFalse(receipt['attempted'])
        self.assertEqual(receipt['reason'], 'insufficient-free-devices')

    def test_memory_samples_are_bounded_and_not_instantaneous_peak_claims(self) -> None:
        """Retain the maximum observed sample and reject absent or invalid observations."""
        receipt = {}
        for value, expected in ((3000, False), (16383, False), (16384, True), (4000, False)):
            self.assertEqual(GUARD.record_probe_memory(receipt, {5: {'hbm_mb': value}}, [5]), expected)
        self.assertEqual(receipt['sampled_hbm_max_mb'], 16384)
        self.assertEqual(receipt['hbm_sample_count'], 4)
        for snapshot in ({}, {5: {}}, {5: {'hbm_mb': -1}}, {5: {'hbm_mb': True}}):
            with self.subTest(snapshot=snapshot), self.assertRaises(RuntimeError):
                GUARD.record_probe_memory({}, snapshot, [5])

    def test_memory_threshold_stops_and_removes_only_owned_container(self) -> None:
        """Exercise create/start/threshold/owned-stop/release on physical card 5 only."""
        container = 'c' * 64
        running = {'value': True}
        commands = []

        def output(command: list[str], **_kwargs: object) -> object:
            """Supply pinned source and owned-container identity without executing anything."""
            if command[0] == 'git':
                return b'' if 'diff' in command else 'fixed-source\n'
            commands.append(command)
            if command[1] == 'create':
                return container + '\n'
            if command[1] == 'inspect':
                return json.dumps([{'Id': container, 'Config': {'Labels': {'codex.owner': GUARD.OWNER}},
                                    'State': {'Running': running['value'], 'ExitCode': 143, 'Pid': 700}}])
            raise AssertionError(command)

        def execute(command: list[str], **_kwargs: object) -> SimpleNamespace:
            """Model only the selected owned container's stop and removal."""
            commands.append(command)
            if command[1] == 'stop':
                self.assertEqual(command[-1], container)
                running['value'] = False
            elif command[1] == 'rm':
                self.assertEqual(command[-1], container)
            elif command[1] != 'top':
                raise AssertionError(command)
            return SimpleNamespace(returncode=0, stdout='PID\n700\n', stderr='')

        process = SimpleNamespace(poll=lambda: None if running['value'] else 0, wait=lambda **_: 0)
        with patch.object(GUARD.subprocess, 'check_output', side_effect=output), \
                patch.object(GUARD.subprocess, 'run', side_effect=execute), \
                patch.object(GUARD.subprocess, 'Popen', return_value=process), \
                patch.object(GUARD.time, 'sleep'), \
                patch.object(GUARD, 'card_snapshot', return_value={5: self.idle}), \
                patch.object(GUARD, 'card_observation', return_value={
                    'raw': 'bounded test observation', 'cards': {5: {**self.idle, 'hbm_mb': 16384}}}):
            receipt = GUARD.remote_job(self.request)
        self.assertEqual(receipt['reason'], 'probe-sampled-device-memory-threshold')
        self.assertTrue(receipt['released'])
        self.assertEqual(receipt['remaining_owned_pids'], [])
        self.assertEqual(receipt['devices'], [5])
        create = next(command for command in commands if command[1] == 'create')
        actual_devices = [create[index + 1] for index, item in enumerate(create) if item == '--device']
        self.assertEqual(actual_devices, ['/dev/davinci5', '/dev/davinci_manager', '/dev/devmm_svm', '/dev/hisi_hdc'])
        self.assertEqual(sum(command[1] == 'stop' for command in commands), 1)
        self.assertEqual(sum(command[1] == 'rm' for command in commands), 1)


if __name__ == '__main__':
    unittest.main(verbosity=2)
