# Copyright 2026 Huawei Technologies Co., Ltd
#
# Licensed under the Apache License, Version 2.0 (the "License");
# you may not use this file except in compliance with the License.
# You may obtain a copy of the License at
#
# http://www.apache.org/licenses/LICENSE-2.0
#
# Unless required by applicable law or agreed to in writing, software
# distributed under the License is distributed on an "AS IS" BASIS,
# WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
# See the License for the specific language governing permissions and
# limitations under the License.
# ============================================================================

"""无设备检查模块实验的请求边界，保留外部任务保护。"""

import hashlib
from pathlib import Path
import tempfile
import unittest
from unittest.mock import patch

from check_pr214_guard import GUARD


class ModuleCostGuardTests(unittest.TestCase):
    """新增入口不允许扩大卡数、主机、case或端口范围。"""

    def setUp(self) -> None:
        """使用全新临时根，不访问真实仓库或设备。"""
        # unittest owns context exit even when a test raises.
        directory = self.enterContext(tempfile.TemporaryDirectory())  # pylint: disable=consider-using-with
        self.root = Path(directory)
        (self.root / 'repo').mkdir()
        self.enterContext(patch.object(GUARD, 'ROOT', self.root))
        self.request = {'host': '129', 'case': 'r129-f637-module-off-40-v1', 'cards': 8,
                        'timeout_seconds': 900, 'port': 30371,
                        'runner': '/work/tools/run_fair_f637_module_cost.sh', 'source': 'fixed-source',
                        'patch_sha256': hashlib.sha256(b'').hexdigest(), 'files': {},
                        'image': sorted(GUARD.ALLOWED_IMAGES)[0]}

    def test_invalid_requests_never_reach_source_or_devices(self) -> None:
        """逐项错误必须在任何外部调用前被拒绝。"""
        changes = [{'cards': count} for count in (1, 2, 4)] + [
            {'host': '125'}, {'case': 'r129-f637-module-off-200-v1'},
            {'case': 'r129-f637-module-other-40-v1'}, {'port': 30372}]
        for change in changes:
            with self.subTest(change=change), patch.object(GUARD.subprocess, 'check_output') as external:
                with self.assertRaisesRegex(ValueError, 'pinned eight-card'):
                    GUARD.remote_job({**self.request, **change})
                external.assert_not_called()

    def test_all_four_cases_keep_insufficient_device_boundary(self) -> None:
        """四种正确请求仍不能在只有七张空卡时创建容器。"""
        idle = {'healthy': True, 'empty': True, 'pids': [], 'core': 0, 'hbm_mb': 3000}
        cards = {index: idle for index in range(7)}
        for index, arm in enumerate(('off', 'norm6', 'dense1', 'moe2')):
            request = {**self.request, 'case': f'r129-f637-module-{arm}-40-v1', 'port': 30371 + index}
            with self.subTest(arm=arm), patch.object(
                    GUARD.subprocess, 'check_output', side_effect=['fixed-source\n', b'']) as external, \
                    patch.object(GUARD, 'card_snapshot', return_value=cards):
                receipt = GUARD.remote_job(request)
            self.assertFalse(receipt['attempted'])
            self.assertTrue(receipt['released'])
            self.assertEqual(receipt['reason'], 'insufficient-free-devices')
            self.assertEqual(external.call_count, 2)

    def test_external_job_on_second_check_prevents_launch(self) -> None:
        """空卡复查发现其他任务时退出，绝不发停止命令。"""
        idle = {'healthy': True, 'empty': True, 'pids': [], 'core': 0, 'hbm_mb': 3000}
        first = {index: idle for index in range(8)}
        second = {**first, 3: {**idle, 'empty': False, 'pids': [77]}}
        with patch.object(GUARD.subprocess, 'check_output', side_effect=['fixed-source\n', b'']) as external, \
                patch.object(GUARD, 'card_snapshot', side_effect=[first, second]), \
                patch.object(GUARD.time, 'sleep') as delay:
            receipt = GUARD.remote_job(self.request)
        self.assertFalse(receipt['attempted'])
        self.assertEqual(receipt['reason'], 'device-became-busy-before-launch')
        self.assertEqual(external.call_count, 2)
        delay.assert_called_once_with(5)


if __name__ == '__main__':
    unittest.main(verbosity=2)
