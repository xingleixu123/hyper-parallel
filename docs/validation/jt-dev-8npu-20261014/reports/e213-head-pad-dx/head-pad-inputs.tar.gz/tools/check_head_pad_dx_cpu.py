# Copyright 2026 Huawei Technologies Co., Ltd
#
# Licensed under the Apache License, Version 2.0 (the "License");
# you may not use this file except in compliance with the License.
# You may obtain a copy of the License at
#
# http://www.apache.org/licenses/LICENSE-2.0
#
# Unless required by applicable law or agreed to in writing, software
# distributed under the License is distributed on an "AS IS" BASIS,
# WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
# See the License for the specific language governing permissions and
# limitations under the License.
# ============================================================================

"""Test the exact controlled dX replacement using the real shared, checkpointed head loss on CPU."""

import copy
import hashlib
import json
from pathlib import Path
import unittest
from unittest import mock

import torch  # pylint: disable=forbidden-backend-import
from torch.nn import functional  # pylint: disable=forbidden-backend-import
from torch.utils.checkpoint import DefaultDeviceType  # pylint: disable=forbidden-backend-import

from head_pad_dx_experiment import HeadPadDXExperiment, padded_input_vjp
from hyper_parallel.components.losses.chunked_cross_entropy import projected_cross_entropy
from hyper_parallel.trainer.config.parser import parse_training_args


class HeadPadDXTests(unittest.TestCase):
    """Verify native dW, intentional dX-only scope, replay coverage, placement and ownership cleanup."""

    def setUp(self) -> None:
        """Select CPU explicitly and restore the previous checkpoint default after each check."""
        self.addCleanup(DefaultDeviceType.set_device_type, DefaultDeviceType.get_device_type())
        DefaultDeviceType.set_device_type('cpu')
        torch.manual_seed(79)

    @staticmethod
    def score(logits: torch.Tensor, labels: None, vocab_size: int, shift_labels: torch.Tensor,
              num_items_in_batch: torch.Tensor, **_kwargs: object) -> torch.Tensor:
        """Honor the actual projected CE contract, including ignored tokens and summed numerator."""
        if labels is not None or logits.shape[-1] != vocab_size:
            raise ValueError('The real helper supplied an unexpected score contract')
        return functional.cross_entropy(logits.reshape(-1, vocab_size).float(), shift_labels.reshape(-1),
                                         ignore_index=-100, reduction='sum') / num_items_in_batch

    def shared_loss(self, head: torch.nn.Linear, inputs: torch.Tensor) -> torch.Tensor:
        """Two calls share the output weight and input graph with genuine nonreentrant checkpoint replay."""
        labels = torch.arange(8, dtype=torch.int64).reshape(1, -1)
        labels[0, :2] = -100
        main_loss = projected_cross_entropy(inputs, labels, head=head, loss_fn=self.score,
                                        vocab_size=17, chunk_size=8)
        auxiliary = projected_cross_entropy(inputs * 0.5, labels, head=head, loss_fn=self.score,
                                             vocab_size=17, chunk_size=8)
        return main_loss + 0.3 * auxiliary

    def test_native_forward_and_weight_gradient_shared_checkpoint(self) -> None:
        """Each CP row placement preserves forward and dW, and counts two backwards despite recomputation."""
        for rank in (0, 1):
            with self.subTest(cp_rank=rank):
                plain = torch.nn.Linear(8, 17, bias=False, dtype=torch.bfloat16)
                watched = copy.deepcopy(plain)
                values = torch.randn(1, 8, 8, dtype=torch.bfloat16, requires_grad=True)
                candidate = values.detach().clone().requires_grad_(True)
                records = []
                experiment = HeadPadDXExperiment(watched, rank, 2, 8, records.append, lambda: {'step': 1})
                try:
                    expected, actual = self.shared_loss(plain, values), self.shared_loss(watched, candidate)
                    expected.backward()
                    actual.backward()
                    torch.testing.assert_close(actual, expected, rtol=0, atol=0)
                    torch.testing.assert_close(watched.weight.grad, plain.weight.grad, rtol=0, atol=0)
                    torch.testing.assert_close(candidate.grad, values.grad, rtol=0, atol=0)
                    self.assertEqual(len(records), 2)
                    self.assertEqual({record['cp_rank'] for record in records}, {rank})
                    self.assertTrue(all(record['difference_from_native_dx']['count'] == 64 for record in records))
                finally:
                    experiment.close()
                self.assertNotIn('forward', watched.__dict__)

    def test_only_input_gradient_is_replaced(self) -> None:
        """An explicit doubled dX control changes hidden gradients while preserving native shared dW exactly."""
        plain = torch.nn.Linear(8, 17, bias=False, dtype=torch.bfloat16)
        watched = copy.deepcopy(plain)
        values = torch.randn(1, 8, 8, dtype=torch.bfloat16, requires_grad=True)
        candidate = values.detach().clone().requires_grad_(True)
        records = []
        experiment = HeadPadDXExperiment(watched, 1, 2, 8, records.append, lambda: {'step': 1})
        self.addCleanup(experiment.close)

        def doubled(*args: object) -> torch.Tensor:
            """Inject an unmistakable local derivative change solely to check the intervention boundary."""
            return 2 * padded_input_vjp(*args)

        expected, actual = self.shared_loss(plain, values), self.shared_loss(watched, candidate)
        expected.backward()
        with mock.patch('head_pad_dx_experiment.padded_input_vjp', side_effect=doubled):
            actual.backward()
        torch.testing.assert_close(actual, expected, rtol=0, atol=0)
        torch.testing.assert_close(watched.weight.grad, plain.weight.grad, rtol=0, atol=0)
        torch.testing.assert_close(candidate.grad, 2 * values.grad, rtol=0, atol=0)
        self.assertEqual(len(records), 2)
        self.assertTrue(any(row['difference_from_native_dx']['nonzero_count'] > 0 for row in records))

    def test_global_row_placement_and_local_return_storage(self) -> None:
        """Check exact global row offsets using an independent artificial VJP and retain no padded storage."""
        values = torch.arange(24, dtype=torch.float32).reshape(1, 3, 8).to(torch.bfloat16)
        weight = torch.eye(8, dtype=torch.bfloat16)
        gradient = values + 32
        for rank in (0, 1):
            calls = []

            def oracle(inputs: torch.Tensor, _weight: torch.Tensor, derivative: torch.Tensor) -> torch.Tensor:
                """Return a row-indexed result so a wrong shard selection cannot accidentally pass."""
                calls.append((inputs.clone(), derivative.clone()))
                return torch.arange(48, dtype=torch.float32).reshape(1, 6, 8).to(torch.bfloat16)

            with mock.patch('head_pad_dx_experiment.native_vjp', side_effect=oracle):
                actual = padded_input_vjp(values, weight, gradient, rank, 2)
            expected = torch.arange(48, dtype=torch.float32).reshape(1, 6, 8).to(torch.bfloat16)
            torch.testing.assert_close(actual, expected[:, rank * 3:(rank + 1) * 3], rtol=0, atol=0)
            torch.testing.assert_close(calls[0][0][:, rank * 3:(rank + 1) * 3], values, rtol=0, atol=0)
            torch.testing.assert_close(calls[0][1][:, rank * 3:(rank + 1) * 3], gradient, rtol=0, atol=0)
            other = 1 - rank
            self.assertEqual(torch.count_nonzero(calls[0][0][:, other * 3:(other + 1) * 3]).item(), 0)
            self.assertEqual(torch.count_nonzero(calls[0][1][:, other * 3:(other + 1) * 3]).item(), 0)
            self.assertEqual(actual.untyped_storage().nbytes(), actual.numel() * actual.element_size())

    def test_existing_reshard_hook_and_gradient_ownership(self) -> None:
        """Keep the original autograd parameter edge even if an existing FSDP-like post-hook exposes a shard."""
        head = torch.nn.Linear(8, 17, bias=False, dtype=torch.bfloat16)
        weight = head.weight
        values = torch.randn(1, 8, 8, dtype=torch.bfloat16, requires_grad=True)
        records = []
        experiment = HeadPadDXExperiment(head, 0, 2, 8, records.append, lambda: {'step': 1})
        self.addCleanup(experiment.close)

        def reshard(module: torch.nn.Linear, _args: tuple, _output: torch.Tensor) -> None:
            """Represent owner-controlled parameter replacement after the ordinary module forward."""
            module.weight = torch.nn.Parameter(weight[:2].detach())

        hook = head.register_forward_hook(reshard)
        self.addCleanup(hook.remove)
        output = head(values)
        upstream = torch.randn_like(output)
        with torch.enable_grad():
            reference_input = values.detach().requires_grad_(True)
            reference_weight = weight.detach().requires_grad_(True)
            reference = functional.linear(reference_input, reference_weight)
            expected_dx, expected_dw = torch.autograd.grad(reference, (reference_input, reference_weight), upstream)
        output.backward(upstream)
        torch.testing.assert_close(values.grad, expected_dx, rtol=0, atol=0)
        torch.testing.assert_close(weight.grad, expected_dw, rtol=0, atol=0)
        self.assertIsNone(head.weight.grad)
        self.assertEqual(len(records), 1)

    def test_validation_and_cleanup_do_not_override_another_owner(self) -> None:
        """Reject unsupported shapes and avoid restoring over an unrelated module-forward change."""
        head = torch.nn.Linear(8, 17, bias=False, dtype=torch.bfloat16)
        with self.assertRaises(ValueError):
            HeadPadDXExperiment(head, 2, 2, 8, lambda _row: None, lambda: {'step': 1})
        experiment = HeadPadDXExperiment(head, 0, 2, 8, lambda _row: None, lambda: {'step': 1})
        try:
            with self.assertRaisesRegex(ValueError, 'complete contiguous'):
                head(torch.zeros(1, 4, 8, dtype=torch.bfloat16, requires_grad=True))
            other_forward = head.forward
            head.forward = lambda inputs: inputs
            with self.assertRaisesRegex(RuntimeError, 'ownership'):
                experiment.close()
            head.forward = other_forward
        finally:
            experiment.close()
        experiment.close()
        self.assertNotIn('forward', head.__dict__)


def main() -> None:
    """Run actual CPU graph checks and independently validate the frozen training config."""
    result = unittest.TextTestRunner(verbosity=2).run(unittest.defaultTestLoader.loadTestsFromTestCase(HeadPadDXTests))
    if not result.wasSuccessful():
        raise SystemExit(1)
    root = Path('/work')
    case = 'r129-e213-head-pad-dx-cp2-3-v1'
    config_path = root / 'configs' / (case + '.yaml')
    expected = json.loads((root / 'evidence/f637-native-cp2-reference-config.json').read_bytes())
    expected['training']['train_iters'] = 3
    expected['checkpoint'].update(save_ckpt=False, checkpoint_dir='/work/checkpoints/' + case)
    if parse_training_args([str(config_path)]).to_dict() != expected:
        raise ValueError('The diagnostic changed a numerical configuration field')
    if torch.cuda.is_initialized() or (hasattr(torch, 'npu') and torch.npu.is_initialized()):
        raise RuntimeError('CPU-only tests initialized an accelerator')
    names = ('head_pad_dx_experiment.py', 'capture_head_pad_dx_training.py', 'check_head_pad_dx_cpu.py',
             'head_row_vjp_probe.py', 'fixed_pta_probe_common.py')
    with (root / 'evidence/e213-head-pad-dx-cpu-v1.json').open('x', encoding='utf-8') as output:
        json.dump({'status': 'PASS', 'tests': result.testsRun, 'npu_used': False,
                   'config_sha256': hashlib.sha256(config_path.read_bytes()).hexdigest(),
                   'files': {name: hashlib.sha256((root / 'tools' / name).read_bytes()).hexdigest() for name in names},
                   'scope': 'CPU intervention boundaries and actual checkpoint path; no NPU precision claim'}, output,
                  indent=2)


if __name__ == '__main__':
    main()
