#!/usr/bin/env bash
set -eo pipefail
source /workspace/env.sh
export PATH="/work/venvs/latest-f637-tests/bin:$PATH"
export OMP_NUM_THREADS=1 PYTHONDONTWRITEBYTECODE=1
cd /workspace/hyper-parallel
python /work/tools/check_head_pad_dx_cpu.py
