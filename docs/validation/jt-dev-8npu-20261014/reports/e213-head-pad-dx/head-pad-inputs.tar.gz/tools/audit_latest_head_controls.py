# Copyright 2026 Huawei Technologies Co., Ltd
#
# Licensed under the Apache License, Version 2.0 (the "License");
# you may not use this file except in compliance with the License.
# You may obtain a copy of the License at
#
# http://www.apache.org/licenses/LICENSE-2.0
#
# Unless required by applicable law or agreed to in writing, software
# distributed under the License is distributed on an "AS IS" BASIS,
# WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
# See the License for the specific language governing permissions and
# limitations under the License.
# ============================================================================

"""Audit the latest-source short native control and the optional head-only causal intervention."""

import argparse
from collections import Counter
import hashlib
import json
from pathlib import Path

from audit_head_row_vjp_run import verify_statistics
from strict_compare_runs import audit


ROOT = Path(__file__).resolve().parents[1]
CONTROL = 'r129-e213-native-cp2-3-v1'
CANDIDATE = 'r129-e213-head-pad-dx-cp2-3-v1'
SOURCE = '558eff53571498538048015ae3a7e3e57ba74fb9'
METRICS = ('training/foundation_loss/lm', 'training/foundation_loss/mtp', 'training/foundation_loss/aux',
           'training/total_loss', 'training/grad_norm')


def read_json(path: Path) -> dict:
    """Read the original JSON representation without rewriting collected evidence."""
    return json.loads(path.read_bytes())


def verify_run(case: str, tag: str) -> tuple[dict, Path]:
    """Verify file hashes, all ranks, source identity and actual release, independent of final precision gates."""
    directory = ROOT / 'runs' / case
    manifest_path = ROOT / 'evidence' / (tag + '-evidence-manifest.json')
    manifest = read_json(manifest_path)
    for entry in manifest['files']:
        path = ROOT / entry['path']
        if ROOT not in path.resolve().parents or path.is_symlink():
            raise ValueError('Collected evidence is outside the task directory')
        data = path.read_bytes()
        if len(data) != entry['bytes'] or hashlib.sha256(data).hexdigest() != entry['sha256']:
            raise ValueError('Collected evidence no longer matches its manifest')
    receipt = read_json(ROOT / 'scheduling' / (case + '.receipt.json'))
    request = read_json(ROOT / 'scheduling' / (case + '.request.json'))
    if (receipt['source'] != SOURCE or request['source'] != SOURCE or receipt['exit_code'] != 0
            or not receipt['released'] or receipt['remaining_owned_pids'] or receipt['duration_seconds'] > 600
            or receipt['devices'] != list(range(8)) or receipt['workspace'] != request['workspace']):
        raise ValueError('The actual reserved source, eight-card execution or release was not verified')
    if (directory / 'source-commit.txt').read_text().strip() != SOURCE:
        raise ValueError('The executed source differs from the requested source')
    if (directory / 'source-status.txt').read_bytes() or (directory / 'source.patch').read_bytes():
        raise ValueError('The training source was modified outside its fixed commit')
    for helper in directory.glob('*.py'):
        if hashlib.sha256(helper.read_bytes()).hexdigest() != request['files']['tools/' + helper.name]:
            raise ValueError('An actual helper differs from its requested contents')
    expected = read_json(ROOT / 'evidence/f637-native-cp2-reference-config.json')
    expected['training']['train_iters'] = 3
    expected['checkpoint'].update(save_ckpt=False, checkpoint_dir='/work/checkpoints/' + case)
    if read_json(directory / 'config.resolved.json') != expected:
        raise ValueError('The actual resolved CP recipe changed unexpectedly')
    for rank in range(8):
        start = read_json(directory / f'start-rank{rank}.json')
        finish = read_json(directory / f'complete-rank{rank}.json')
        rows = [json.loads(line) for line in (directory / f'metrics-rank{rank}.jsonl').read_bytes().splitlines()]
        if (start['global_step'] != 0 or start['train_iters'] != 3 or start['micro_batches'] != 2
                or finish['global_step'] != 3 or [row['step'] for row in rows] != [1, 2, 3]):
            raise ValueError('The run did not cover exactly three complete optimizer steps on each rank')
    return {'case': case, 'files_verified': len(manifest['files']), 'container_id': receipt['container_id'],
            'duration_seconds': receipt['duration_seconds'], 'released': True}, manifest_path


def verify_intervention() -> dict:
    """Count actual backwards and validate every full-coordinate local derivative statistic."""
    directory = ROOT / 'runs' / CANDIDATE
    records, cp_ranks = [], Counter()
    for rank in range(8):
        mode = read_json(directory / f'head-pad-dx-mode-rank{rank}.json')
        coverage = read_json(directory / f'head-pad-dx-coverage-rank{rank}.json')
        if (mode['training_steps'] != 3 or mode['numeric_recipe_changed'] is not True
                or mode['selected_module'] != 'lm_head' or not mode['native_forward']
                or not mode['native_weight_gradient'] or coverage != {'1': 4, '2': 4, '3': 4}):
            raise ValueError('The recorded intervention scope or actual backward coverage is wrong')
        cp_ranks[mode['cp_rank']] += 1
        rows = [json.loads(line) for line in (directory / f'head-pad-dx-calls-rank{rank}.jsonl')
                .read_bytes().splitlines()]
        expected_calls = {(step, ordinal) for step in range(1, 4) for ordinal in range(1, 5)}
        actual_calls = {(row['identity']['step'], row['backward_ordinal_in_step']) for row in rows}
        if len(rows) != 12 or actual_calls != expected_calls:
            raise ValueError('A backward was duplicated, omitted or assigned to another step')
        for row in rows:
            if (row['identity']['rank'] != rank or row['identity']['module'] != 'lm_head'
                    or row['cp_rank'] != mode['cp_rank'] or row['cp_degree'] != 2
                    or row['input_shape'] != [1, 2048, 5120] or row['weight_shape'] != [152064, 5120]
                    or row['gradient_shape'] != [1, 2048, 152064] or row['dtype'] != 'torch.bfloat16'
                    or row['padded_rows'] != 4096 or row['production_performance_claim']):
                raise ValueError('An actual backward used an unexpected operand shape or intervention')
            verify_statistics(row['difference_from_native_dx'], 10485760)
        records.extend(rows)
    if cp_ranks != Counter({0: 4, 1: 4}):
        raise ValueError('The actual CP groups do not cover both local row positions')
    statistics = [row['difference_from_native_dx'] for row in records]
    return {'actual_backward_calls': len(records),
            'full_derivative_coordinates': sum(row['count'] for row in statistics),
            'nonzero_coordinates': sum(row['nonzero_count'] for row in statistics),
            'maximum_local_change': max(row['max_abs'] for row in statistics),
            'sum_absolute_local_change': sum(row['absolute_sum'] for row in statistics)}


def main() -> None:
    """Keep short/source-migration rejection findings visible and separate them from diagnostic observations."""
    parser = argparse.ArgumentParser()
    parser.add_argument('--with-intervention', action='store_true')
    parser.add_argument('--output', type=Path, help='Optional new result file; existing files are never overwritten')
    args = parser.parse_args()
    control, control_manifest = verify_run(CONTROL, 'e213-native-cp2-3-v1')
    migration = audit(ROOT / 'runs/r129-f637-fp32-cp2-200', ROOT / 'runs' / CONTROL, 1, 3,
                      reference_manifest=ROOT / 'evidence/f637-cp2-200-complete-evidence-manifest.json',
                      candidate_manifest=control_manifest)
    expected = ['Final acceptance requires exactly 200 consecutive steps',
                'Final acceptance requires matching source commit and patch']
    if migration['findings'] != expected or any(row['max_abs'] != 0 for row in migration['errors'].values()):
        raise ValueError('The latest-source native CP bridge is not exactly transparent in its observed window')
    result = {'control': control, 'source_migration_observed': 'EXACT_THREE_STEP_PREFIX',
              'migration_strict_gate': migration, 'final_training_acceptance': 'NOT_EVALUATED_THREE_STEPS'}
    if args.with_intervention:
        candidate, candidate_manifest = verify_run(CANDIDATE, 'e213-head-pad-dx-cp2-3-v1')
        comparison = audit(ROOT / 'runs' / CONTROL, ROOT / 'runs' / CANDIDATE, 1, 3,
                           reference_manifest=control_manifest, candidate_manifest=candidate_manifest)
        coverage = verify_intervention()
        for rank in range(8):
            native = json.loads((ROOT / 'runs' / CONTROL / f'metrics-rank{rank}.jsonl').read_bytes().splitlines()[0])
            changed = json.loads((ROOT / 'runs' / CANDIDATE / f'metrics-rank{rank}.jsonl').read_bytes().splitlines()[0])
            if any(native[key] != changed[key] for key in METRICS[:-1]):
                raise ValueError('The first forward loss changed before the intended derivative intervention')
        result.update(candidate=candidate, local_intervention=coverage, candidate_vs_native=comparison)
    name = 'e213-head-pad-dx-causal-audit.json' if args.with_intervention else 'e213-native-cp2-control-audit.json'
    output_path = args.output if args.output is not None else ROOT / 'evidence' / name
    with output_path.open('x', encoding='utf-8') as output:
        json.dump(result, output, ensure_ascii=False, indent=2)
    print(json.dumps({key: value for key, value in result.items()
                      if key not in ('migration_strict_gate', 'candidate_vs_native')}))


if __name__ == '__main__':
    main()
