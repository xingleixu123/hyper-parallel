# Copyright 2026 Huawei Technologies Co., Ltd
#
# Licensed under the Apache License, Version 2.0 (the "License");
# you may not use this file except in compliance with the License.
# You may obtain a copy of the License at
#
# http://www.apache.org/licenses/LICENSE-2.0
#
# Unless required by applicable law or agreed to in writing, software
# distributed under the License is distributed on an "AS IS" BASIS,
# WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
# See the License for the specific language governing permissions and
# limitations under the License.
# ============================================================================

"""Check the latest report-only merge and exact CP controls without accelerator initialization."""

import copy
import hashlib
import json
from pathlib import Path
import subprocess

import pytest
import torch  # pylint: disable=forbidden-backend-import
from torch.utils.checkpoint import DefaultDeviceType  # pylint: disable=forbidden-backend-import

import hyper_parallel
from hyper_parallel.trainer.config.parser import parse_training_args


def main() -> None:
    """Validate both frozen configs and the actual merged integration regression module."""
    root = Path('/work')
    expected = json.loads((root / 'evidence/f637-native-cp2-reference-config.json').read_bytes())
    hashes = {}
    for case in ('r129-e213-native-cp2-3-v1', 'r129-e213-head-pad-dx-cp2-3-v1'):
        path = root / 'configs' / (case + '.yaml')
        target = copy.deepcopy(expected)
        target['training']['train_iters'] = 3
        target['checkpoint'].update(save_ckpt=False, checkpoint_dir='/work/checkpoints/' + case)
        actual = parse_training_args([str(path)]).to_dict()
        if actual != target:
            (root / 'evidence/e213-config-mismatch.json').write_text(
                json.dumps({'case': case, 'actual': actual, 'expected': target}, indent=2), encoding='utf-8')
            raise ValueError('The short control modified another numerical or runtime setting')
        hashes[case] = hashlib.sha256(path.read_bytes()).hexdigest()
    if not hyper_parallel.__file__.startswith('/workspace/hyper-parallel/'):
        raise ValueError('The editable install does not point to the bound checkout')
    old_default = DefaultDeviceType.get_device_type()
    try:
        DefaultDeviceType.set_device_type('cpu')
        result = pytest.main(['-q', 'tests/ut/model_integration/test_model_integration.py'])
    finally:
        DefaultDeviceType.set_device_type(old_default)
    if result:
        raise SystemExit(result)
    if torch.cuda.is_initialized() or (hasattr(torch, 'npu') and torch.npu.is_initialized()):
        raise RuntimeError('The device-free checks initialized an accelerator')
    commit = subprocess.check_output(['git', 'rev-parse', 'HEAD'], text=True).strip()
    if commit != '558eff53571498538048015ae3a7e3e57ba74fb9':
        raise ValueError('The actual source is not the reviewed latest integration')
    with (root / 'evidence/e213-native-cp2-cpu-v1.json').open('x', encoding='utf-8') as handle:
        json.dump({'status': 'PASS', 'source': commit, 'configs': hashes, 'npu_used': False,
                   'scope': 'Exact parser comparison and actual integration regression module; no NPU claim'},
                  handle, indent=2)


if __name__ == '__main__':
    main()
