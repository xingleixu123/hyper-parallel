# Copyright 2026 Huawei Technologies Co., Ltd
#
# Licensed under the Apache License, Version 2.0 (the "License");
# you may not use this file except in compliance with the License.
# You may obtain a copy of the License at
#
# http://www.apache.org/licenses/LICENSE-2.0
#
# Unless required by applicable law or agreed to in writing, software
# distributed under the License is distributed on an "AS IS" BASIS,
# WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
# See the License for the specific language governing permissions and
# limitations under the License.
# ============================================================================

"""Replace only a selected shared head's dX with native full-row-shape BF16 VJP replay."""

from collections.abc import Callable
from types import MethodType
from typing import Any

import torch  # pylint: disable=forbidden-backend-import
from torch.autograd.function import once_differentiable  # pylint: disable=forbidden-backend-import
from torch.nn import functional  # pylint: disable=forbidden-backend-import

from fixed_pta_probe_common import difference_stats
from head_row_vjp_probe import NATIVE_LINEAR, native_vjp


def padded_input_vjp(inputs: torch.Tensor, weight: torch.Tensor, gradient: torch.Tensor,
                     cp_rank: int, degree: int) -> torch.Tensor:
    """Place a contiguous CP shard at its original global rows, replay native dX, then select it."""
    rows = inputs.shape[1]
    start = cp_rank * rows
    padded_input = inputs.new_zeros((1, rows * degree, inputs.shape[2]))
    padded_gradient = gradient.new_zeros((1, rows * degree, gradient.shape[2]))
    padded_input[:, start:start + rows].copy_(inputs.detach())
    padded_gradient[:, start:start + rows].copy_(gradient.detach())
    result = native_vjp(padded_input, weight, padded_gradient)
    # Return private local storage rather than retaining the unused padded derivative rows.
    return result[:, start:start + rows].clone()


class PaddedHeadInputGradient(torch.autograd.Function):
    """Diagnostic first-order derivative preserving the native forward and native local weight gradient."""

    @staticmethod
    def forward(ctx: Any, inputs: torch.Tensor, weight: torch.Tensor, cp_rank: int,
                degree: int, sink: Callable[[dict], None], identity: dict) -> torch.Tensor:
        """Save ordinary local operands for the backward selected by actual autograd execution."""
        ctx.save_for_backward(inputs, weight)
        ctx.cp_rank, ctx.degree, ctx.sink, ctx.identity = cp_rank, degree, sink, identity
        return NATIVE_LINEAR(inputs, weight)

    @staticmethod
    @once_differentiable
    def backward(ctx: Any, gradient: torch.Tensor) -> tuple:
        """Keep the normal local dW; change only dX's row shape, precision and scaling unchanged."""
        inputs, weight = ctx.saved_tensors
        if not ctx.needs_input_grad[0] or not ctx.needs_input_grad[1]:
            raise ValueError('This selected training head must require both input and weight gradients')
        with torch.enable_grad():
            values = inputs.detach().requires_grad_(True)
            local_weight = weight.detach().requires_grad_(True)
            output = NATIVE_LINEAR(values, local_weight)
            native_dx, native_dw = torch.autograd.grad(output, (values, local_weight), gradient.detach())
        del output, values, local_weight
        replacement = padded_input_vjp(inputs, weight, gradient, ctx.cp_rank, ctx.degree)
        statistics = difference_stats(replacement.detach().cpu(), native_dx.detach().cpu())
        ctx.sink({'identity': ctx.identity, 'cp_rank': ctx.cp_rank, 'cp_degree': ctx.degree,
                  'input_shape': list(inputs.shape), 'weight_shape': list(weight.shape),
                  'gradient_shape': list(gradient.shape), 'dtype': str(inputs.dtype),
                  'padded_rows': inputs.shape[1] * ctx.degree, 'difference_from_native_dx': statistics,
                  'forward': 'native BF16 Linear', 'weight_gradient': 'native BF16 local autograd replay',
                  'input_gradient': 'native BF16 replay at padded global row shape; select original local rows',
                  'production_performance_claim': False})
        return replacement, native_dw, None, None, None, None


class HeadPadDXExperiment:
    """Own one module-forward binding; retain no input snapshots and count only actual backward calls."""

    def __init__(self, module: torch.nn.Linear, cp_rank: int, degree: int, local_rows: int,
                 sink: Callable[[dict], None], identity: Callable[[], dict]) -> None:
        """Install a shape-guarded diagnostic on a bias-free ordinary local shared head."""
        if not isinstance(module, torch.nn.Linear) or module.bias is not None:
            raise ValueError('The selected shared head must be a bias-free Linear')
        if any(isinstance(value, bool) or not isinstance(value, int) for value in (cp_rank, degree, local_rows)):
            raise ValueError('CP degree, rank and row count must be integers')
        if degree != 2 or cp_rank not in range(degree) or local_rows < 1:
            raise ValueError('The diagnostic requires a valid two-way contiguous CP shard')
        self.module, self.cp_rank, self.degree, self.local_rows = module, cp_rank, degree, local_rows
        self.sink, self.identity = sink, identity
        self.had_instance_forward = 'forward' in module.__dict__
        self.original_forward = module.forward
        self.closed = False
        self.installed = MethodType(self._forward, module)
        module.forward = self.installed

    def _forward(self, module: torch.nn.Linear, inputs: torch.Tensor) -> torch.Tensor:
        weight = module.weight
        if functional.linear is not NATIVE_LINEAR:
            raise RuntimeError('Another functional Linear intervention is active')
        if (type(inputs) not in (torch.Tensor,) or type(weight) not in (torch.Tensor, torch.nn.Parameter)
                or inputs.ndim != 3 or inputs.shape[:2] != (1, self.local_rows) or weight.ndim != 2
                or inputs.shape[2] != weight.shape[1]):
            raise ValueError('The actual head must use one complete contiguous local CP shard')
        if inputs.dtype != torch.bfloat16 or weight.dtype != torch.bfloat16 or inputs.device != weight.device:
            raise ValueError('Head dX diagnosis requires colocated native BF16 operands')
        if inputs.device.type == 'npu' and torch.npu.matmul.allow_hf32:
            raise ValueError('HF32 must remain disabled')
        if not torch.is_grad_enabled():
            return self.original_forward(inputs)
        if not inputs.requires_grad or not weight.requires_grad:
            raise ValueError('The selected head must require both training derivatives')
        identity = dict(self.identity())
        if not identity:
            raise ValueError('The head call lacks a logical training identity')
        return PaddedHeadInputGradient.apply(inputs, weight, self.cp_rank, self.degree, self.sink, identity)

    def close(self) -> None:
        """Restore only this binding; fail rather than overwrite another module modification."""
        if self.closed:
            return
        if self.module.forward is not self.installed:
            raise RuntimeError('The selected module-forward binding changed ownership')
        if self.had_instance_forward:
            self.module.forward = self.original_forward
        else:
            del self.module.forward
        self.closed = True
