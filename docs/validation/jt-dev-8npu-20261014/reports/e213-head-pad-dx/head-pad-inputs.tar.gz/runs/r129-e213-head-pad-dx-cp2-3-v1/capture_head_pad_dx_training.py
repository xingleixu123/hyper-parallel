# Copyright 2026 Huawei Technologies Co., Ltd
#
# Licensed under the Apache License, Version 2.0 (the "License");
# you may not use this file except in compliance with the License.
# You may obtain a copy of the License at
#
# http://www.apache.org/licenses/LICENSE-2.0
#
# Unless required by applicable law or agreed to in writing, software
# distributed under the License is distributed on an "AS IS" BASIS,
# WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
# See the License for the specific language governing permissions and
# limitations under the License.
# ============================================================================

"""Run a bounded three-step CP2 causal control changing only the shared output head input derivative."""

from collections import Counter
import json
from typing import Any

import capture_training
from head_pad_dx_experiment import HeadPadDXExperiment

from hyper_parallel.trainer.callbacks.base import Callback


ORIGINAL_TRAINER = capture_training.TextTrainer
INTERVENTION = None
COUNTS = Counter()


class HeadPadCompletion(Callback):
    """Require all shared-head backwards rather than counting nonreentrant forward replays."""

    def on_train_end(self, state: object, **kwargs: object) -> None:
        """Two microbatches and LM plus MTP require four actual head backwards per optimizer step."""
        if state.global_step != 3 or COUNTS != Counter({1: 4, 2: 4, 3: 4}):
            raise ValueError('The three-step CP2 diagnostic has incomplete actual backward coverage')
        capture_training.write_json(f'head-pad-dx-coverage-rank{capture_training.RANK}.json', dict(COUNTS))


def build_trainer(*args: Any, **kwargs: Any) -> Any:
    """Bind only the final shared head after the ordinary Trainer constructs all parallel wrappers."""
    global INTERVENTION  # pylint: disable=global-statement
    trainer = ORIGINAL_TRAINER(*args, **kwargs)
    base = trainer.base
    if (base.train_iters != 3 or base.state.global_step != 0 or base.mesh.tp_size != 1
            or base.mesh.cp_size != 2 or base.mesh.ep_size != 1 or base.mesh.pp_size != 1
            or base.mesh.dp_size != 4 or base.num_micro_batches != 2):
        raise ValueError('Expected the exact short native CP2 control topology and accumulation count')
    cp_rank = base.mesh.cp_mesh.get_local_rank()

    def identity() -> dict:
        """No branch label is inferred from forward order because checkpoint replay may interleave it."""
        return {'step': base.state.global_step + 1, 'rank': capture_training.RANK, 'module': 'lm_head',
                'scope': 'all shared LM and MTP uses'}

    def record(result: dict) -> None:
        """Keep bounded complete per-backward statistics, never full activations or gradients on disk."""
        if result['input_shape'] != [1, 2048, 5120] or result['weight_shape'] != [152064, 5120]:
            raise ValueError('The selected head differs from the production CP2 shape')
        step = result['identity']['step']
        if step not in (1, 2, 3) or COUNTS[step] >= 4:
            raise ValueError('Unexpected duplicate backward or out-of-window head intervention')
        COUNTS[step] += 1
        result['backward_ordinal_in_step'] = COUNTS[step]
        line = json.dumps(result) + '\n'
        if len(line.encode()) > 128 * 1024:
            raise ValueError('The diagnostic exceeded its per-call metadata bound')
        path = capture_training.OUTPUT / f'head-pad-dx-calls-rank{capture_training.RANK}.jsonl'
        with path.open('a', encoding='utf-8') as handle:
            handle.write(line)

    INTERVENTION = HeadPadDXExperiment(base.model.lm_head, cp_rank, 2, 2048, record, identity)
    base._callbacks.append(HeadPadCompletion(base))  # pylint: disable=protected-access
    capture_training.write_json(f'head-pad-dx-mode-rank{capture_training.RANK}.json', {
        'training_steps': 3, 'numeric_recipe_changed': True, 'cp_rank': cp_rank,
        'selected_module': 'lm_head', 'selected_derivative': 'input only, all shared LM/MTP calls',
        'native_weight_gradient': True, 'native_forward': True,
        'scope': 'Causal localization with extra replay cost; no final acceptance or production resource claim',
    })
    return trainer


def main() -> None:
    """Run the usual evidence path and restore the owned head binding on every exit."""
    capture_training.TextTrainer = build_trainer
    try:
        capture_training.main()
    finally:
        if INTERVENTION is not None:
            INTERVENTION.close()


if __name__ == '__main__':
    main()
