# Copyright 2026 Huawei Technologies Co., Ltd
#
# Licensed under the Apache License, Version 2.0 (the "License");
# you may not use this file except in compliance with the License.
# You may obtain a copy of the License at
#
# http://www.apache.org/licenses/LICENSE-2.0
#
# Unless required by applicable law or agreed to in writing, software
# distributed under the License is distributed on an "AS IS" BASIS,
# WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
# See the License for the specific language governing permissions and
# limitations under the License.
# ============================================================================

"""Parse prepared parallel and resume recipes without constructing models or devices."""

import hashlib
import json
from pathlib import Path
import subprocess

import torch

import hyper_parallel
from hyper_parallel.trainer.config.parser import parse_training_args
from strict_compare_runs import _recipe


ROOT = Path('/work')
SOURCE = '544526f7db8342c607244fd41009b2a74adb84c8'
MANIFEST = ROOT / 'evidence/a1e6-future-matrix-config-manifest-v1.json'


def main() -> None:
    """Require the real parser to preserve every reviewed field in all nineteen recipes."""
    manifest = json.loads(MANIFEST.read_bytes())
    if manifest['source_commit'] != SOURCE or len(manifest['configs']) != 19:
        raise ValueError('Unexpected source or matrix size')
    checkout = Path('/workspace/hyper-parallel')
    source = subprocess.check_output(['git', 'rev-parse', 'HEAD'], cwd=checkout, text=True).strip()
    if source != SOURCE or subprocess.check_output(['git', 'status', '--porcelain'], cwd=checkout):
        raise ValueError('Source is not the clean reviewed checkout')
    if checkout / 'hyper_parallel' not in Path(hyper_parallel.__file__).resolve().parents:
        raise ValueError('Editable import points to another checkout')
    baseline = json.loads((ROOT / 'evidence/201-fsdp8-reference-config.json').read_bytes())
    baseline_recipe = _recipe(baseline)
    results = []
    for entry in manifest['configs']:
        path = ROOT / entry['path']
        contents = path.read_bytes()
        if len(contents) != entry['bytes'] or hashlib.sha256(contents).hexdigest() != entry['sha256']:
            raise ValueError('Prepared configuration changed: ' + entry['case'])
        expected = json.loads(contents)
        actual = parse_training_args([str(path)]).to_dict()
        if json.dumps(actual, sort_keys=True) != json.dumps(expected, sort_keys=True):
            raise ValueError('Actual parser changed a field or scalar type: ' + entry['case'])
        if _recipe(actual) != baseline_recipe:
            raise ValueError('Numerical recipe differs from the new FSDP baseline: ' + entry['case'])
        results.append({'case': entry['case'], 'config_sha256': entry['sha256'], 'resolved': actual})
    if torch.cuda.is_initialized() or (hasattr(torch, 'npu') and torch.npu.is_initialized()):
        raise RuntimeError('A CPU-only parser check initialized an accelerator')
    result = {'status': 'PASS', 'source': source, 'import_path': hyper_parallel.__file__,
              'manifest_sha256': hashlib.sha256(MANIFEST.read_bytes()).hexdigest(),
              'cases': results, 'npu_initialized': False, 'migration_admitted': False,
              'scope': 'CPU production parser only; no training, device capacity or cross-host precision claim'}
    with (ROOT / 'evidence/a1e6-future-matrix-actual-parser-v1.json').open('x', encoding='utf-8') as stream:
        json.dump(result, stream, ensure_ascii=False, indent=2)
        stream.write('\n')
    print(json.dumps({'status': 'PASS', 'cases': len(results), 'source': source,
                      'scope': result['scope']}), flush=True)


if __name__ == '__main__':
    main()
