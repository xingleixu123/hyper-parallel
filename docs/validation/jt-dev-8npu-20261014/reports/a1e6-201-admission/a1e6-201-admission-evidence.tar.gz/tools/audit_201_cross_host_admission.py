# Copyright 2026 Huawei Technologies Co., Ltd
#
# Licensed under the Apache License, Version 2.0 (the "License");
# you may not use this file except in compliance with the License.
# You may obtain a copy of the License at
#
# http://www.apache.org/licenses/LICENSE-2.0
#
# Unless required by applicable law or agreed to in writing, software
# distributed under the License is distributed on an "AS IS" BASIS,
# WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
# See the License for the specific language governing permissions and
# limitations under the License.
# ============================================================================

"""Audit a complete cross-host FSDP reference before admitting experiments on 201."""

import argparse
import copy
import hashlib
import json
import math
from pathlib import Path, PurePosixPath
import re
import statistics

from strict_compare_runs import audit as strict_audit


ROOT = Path(__file__).resolve().parents[1]
SOURCE = '544526f7db8342c607244fd41009b2a74adb84c8'
IMAGE = 'sha256:5f9e677f439d11ab4e7c888f54b142335a27eee7411cbd2ce894a4798a70146d'
OWNER = '01a13aa4-a553-7e22-a1c1-ebd16b083bb9'
TOLERANCE = 0.005
STEPS = 200
RANKS = 8
HELPERS = ('capture_a1e6_training.py', 'capture_training.py', 'module_profile.py',
           'expert_probe.py', 'precision_experiments.py', 'fp32_wgrad_experiment.py')
ENVIRONMENT_KEYS = ('CLOSE_MATMUL_K_SHIFT', 'NCCL_DETERMINISTIC', 'FLASH_ATTENTION_DETERMINISTIC',
                    'CUBLAS_WORKSPACE_CONFIG', 'PYTHONHASHSEED', 'PYTORCH_NPU_ALLOC_CONF')
MATMUL_KEYS = ('allow_tf32', 'allow_hf32', 'allow_bf16_reduced_precision_reduction')
MEMORY_FIELDS = ('allocated_bytes', 'reserved_bytes', 'max_allocated_bytes', 'max_reserved_bytes')
MEMORY_SCOPE = ('Per-process allocator lifetime peaks through completed training/checkpoint callbacks; '
                'not physical device HBM peaks')
RUNNERS = {'201': '/work/tools/run_fair_201_training.sh',
           '125': '/work/tools/run_fair_a1e6_reference.sh', '129': '/work/tools/run_fair_a1e6_reference.sh'}
WORKSPACES = {'125': '/home/xxl/jt-dev-8npu-20261014',
              '129': '/var/tmp/xxl-jt-dev-8npu-20261014', '201': '/opt/xxl-jt-dev-8npu-20261014'}


def _invalid_constant(value: str) -> None:
    raise ValueError('Non-finite JSON constant: ' + value)


def _finite_float(value: str) -> float:
    number = float(value)
    if not math.isfinite(number):
        raise ValueError('Non-finite JSON number: ' + value)
    return number


def _unique_object(pairs: list) -> dict:
    result = {}
    for key, value in pairs:
        if key in result:
            raise ValueError('Duplicate JSON key: ' + key)
        result[key] = value
    return result


def _json(value: bytes) -> dict:
    result = json.loads(value, parse_constant=_invalid_constant, parse_float=_finite_float,
                        object_pairs_hook=_unique_object)
    if not isinstance(result, dict):
        raise ValueError('Expected a JSON object')
    return result


def _sha(path: Path) -> str:
    digest = hashlib.sha256()
    with path.open('rb') as handle:
        for block in iter(lambda: handle.read(1024 * 1024), b''):
            digest.update(block)
    return digest.hexdigest()


def _require(condition: bool, message: str) -> None:
    if not condition:
        raise ValueError(message)


def _finite(value: object) -> bool:
    if not isinstance(value, (float, int)) or isinstance(value, bool):
        return False
    try:
        return math.isfinite(value)
    except OverflowError:
        return False


def _manifest(directory: Path, manifest_path: Path) -> dict:
    root = directory.parent.parent.resolve()
    _require(directory.parent.name == 'runs' and directory.resolve() == root / 'runs' / directory.name
             and not directory.is_symlink(), 'Run directory must be the canonical task runs/case path')
    entries = {}
    for entry in _json(manifest_path.read_bytes())['files']:
        relative = PurePosixPath(entry['path'])
        _require(not relative.is_absolute() and '..' not in relative.parts and '\\' not in str(relative),
                 'Unsafe collection manifest path')
        name = relative.as_posix()
        _require(name not in entries, 'Duplicate collection manifest path: ' + name)
        path = root / name
        _require(root in path.resolve().parents and not path.is_symlink(), 'Collected path leaves task root')
        _require(path.is_file(), 'Missing collected file: ' + name)
        _require(type(entry['bytes']) is int and entry['bytes'] == path.stat().st_size
                 and _sha(path) == entry['sha256'], 'Collected SHA or size differs: ' + name)
        entries[name] = entry
    names = ['config.resolved.json', 'config.yaml', 'source-commit.txt', 'source-status.txt',
             'source.patch', 'EXIT_CODE', *HELPERS]
    for rank in range(RANKS):
        names += [f'{prefix}-rank{rank}.{suffix}' for prefix, suffix in (
            ('initial-state', 'json'), ('start', 'json'), ('complete', 'json'), ('metrics', 'jsonl'),
            ('runtime-flags', 'json'), ('final-memory', 'json'))]
    required = {f'runs/{directory.name}/{name}' for name in names}
    required.update(f'scheduling/{directory.name}.{kind}.json' for kind in ('request', 'receipt'))
    _require(required.issubset(entries), 'Collection manifest omits required audit inputs')
    for prefix, suffix in (('initial-state', 'json'), ('start', 'json'), ('complete', 'json'),
                           ('metrics', 'jsonl'), ('runtime-flags', 'json'), ('final-memory', 'json')):
        expected = {f'{prefix}-rank{rank}.{suffix}' for rank in range(RANKS)}
        _require({path.name for path in directory.glob(f'{prefix}-rank*.{suffix}')} == expected,
                 'Unexpected or missing rank evidence: ' + prefix)
    return {'sha256': _sha(manifest_path), 'verified_files': len(entries)}


def _flags(directory: Path, rank: int) -> dict:
    flags = _json((directory / f'runtime-flags-rank{rank}.json').read_bytes())
    before, training = flags['before_trainer'], flags['training']
    for value in (before['environment'], training['environment']):
        _require(set(value) == set(ENVIRONMENT_KEYS)
                 and all(item is None or isinstance(item, str) for item in value.values()),
                 'Runtime environment flags are incomplete or invalid')
    _require(before['scope'] == 'Environment only; no backend queries', 'Unexpected early observer scope')
    # The JT builder calls use_deterministic_algorithms(True) after the runtime seed helper.
    _require(training['deterministic_algorithms'] is True and training['deterministic_warn_only'] is False,
             'Full determinism flags do not match the reviewed JT model builder')
    matmul = training['npu_matmul']
    _require(set(matmul) == set(MATMUL_KEYS) and all(value is None or type(value) is bool for value in matmul.values()),
             'Matmul flags are incomplete or invalid')
    environment = training['environment']
    expected = {'NCCL_DETERMINISTIC': 'true', 'FLASH_ATTENTION_DETERMINISTIC': '1',
                'CUBLAS_WORKSPACE_CONFIG': ':16:8', 'PYTHONHASHSEED': '42',
                'PYTORCH_NPU_ALLOC_CONF': 'expandable_segments:True'}
    _require(all(environment[key] == value for key, value in expected.items()),
             'Training environment differs from the reviewed deterministic recipe')
    _require(before['environment']['CLOSE_MATMUL_K_SHIFT'] == environment['CLOSE_MATMUL_K_SHIFT'],
             'K-shift environment changed inside the trainer')
    return flags


def _memory(directory: Path, rank: int) -> dict:
    memory = _json((directory / f'final-memory-rank{rank}.json').read_bytes())
    _require(type(memory['global_step']) is int and type(memory['device']) is int
             and memory['global_step'] == STEPS and memory['device'] == rank and memory['scope'] == MEMORY_SCOPE,
             'Final allocator observation has the wrong step, rank device or scope')
    _require(all(type(memory[key]) is int and memory[key] >= 0 for key in MEMORY_FIELDS),
             'Final allocator counters must be nonnegative integer bytes')
    _require(memory['allocated_bytes'] <= memory['reserved_bytes'] <= memory['max_reserved_bytes']
             and memory['allocated_bytes'] <= memory['max_allocated_bytes'] <= memory['max_reserved_bytes'],
             'Final allocator counters are inconsistent')
    return memory


def _rank_trace(directory: Path, rank: int) -> list:
    start = _json((directory / f'start-rank{rank}.json').read_bytes())
    complete = _json((directory / f'complete-rank{rank}.json').read_bytes())
    _require(start['global_step'] == 0 and start['train_iters'] == STEPS and start['micro_batches'] == 1
             and complete['global_step'] == STEPS, 'Exactly 0-200 FSDP steps are required on every rank')
    initial = _json((directory / f'initial-state-rank{rank}.json').read_bytes())
    _require(bool(initial), 'Initial parameter evidence is empty')
    for value in initial.values():
        _require(isinstance(value, dict) and isinstance(value.get('dtype'), str)
                 and isinstance(value.get('shape'), list)
                 and all(type(size) is int and size >= 0 for size in value['shape'])
                 and isinstance(value.get('sha256'), str)
                 and re.fullmatch(r'[0-9a-f]{64}', value['sha256']) is not None,
                 'Initial parameter evidence is malformed')
    rows = [_json(line) for line in (directory / f'metrics-rank{rank}.jsonl').read_bytes().splitlines()]
    _require([row['step'] for row in rows] == list(range(1, STEPS + 1)),
             'Missing, duplicated, reordered or extra optimizer steps')
    consumed_tokens = 0
    consumed_samples = 0
    for row in rows:
        _require(type(row['step']) is int and type(row['rank']) is int
                 and row['rank'] == rank and row['input_identity']['micro_steps'] == 1,
                 'Rank labels or FSDP micro-step counts differ')
        for key, value in row.items():
            if key not in ('input_identity', 'rank', 'step'):
                _require(_finite(value), 'Non-finite or nonnumeric metric: ' + key)
        step_tokens, step_samples = row['data/step_tokens'], row['data/step_samples']
        _require(step_samples == 8 and step_tokens >= 0 and step_tokens == int(step_tokens),
                 'Invalid global batch or token counters')
        consumed_tokens += step_tokens
        consumed_samples += step_samples
        _require(row['data/consumed_tokens'] == consumed_tokens
                 and row['data/consumed_samples'] == consumed_samples, 'Consumed counters do not accumulate from zero')
        _require(row['performance/step_time'] > 0, 'Nonpositive step time')
    return rows


def _run(directory: Path, manifest_path: Path, host: str, recipe: dict, data: dict) -> dict:
    manifest = _manifest(directory, manifest_path)
    root = directory.parent.parent
    receipt = _json((root / 'scheduling' / f'{directory.name}.receipt.json').read_bytes())
    request = _json((root / 'scheduling' / f'{directory.name}.request.json').read_bytes())
    _require(re.fullmatch(r'r' + host + r'-a1e6-fsdp8-0-200-v[1-9][0-9]*', directory.name) is not None,
             'This audit admits only a complete a1e6 FSDP baseline, never a three-step smoke run')
    _require((directory / 'source-commit.txt').read_text().strip() == SOURCE
             and not (directory / 'source-status.txt').read_bytes() and not (directory / 'source.patch').read_bytes(),
             'Admission requires the clean reviewed source commit')
    empty_patch = hashlib.sha256(b'').hexdigest()
    for identity in (request, receipt):
        _require(identity['case'] == directory.name and identity['host'] == host and identity['source'] == SOURCE
                 and identity['image'] == IMAGE and identity['patch_sha256'] == empty_patch,
                 'Request, receipt, host or source identity differs')
    _require(receipt['owner'] == OWNER and receipt.get('remaining_owned_pids') == [],
             'Execution ownership or device release is not proven')
    _require(request['workspace'] == receipt['workspace'] == WORKSPACES[host] and request['cards'] == RANKS
             and request['runner'] == RUNNERS[host] and request['timeout_seconds'] == 900,
             'Requested workspace, runner or eight-card execution differs')
    if host == '201':
        _require(receipt.get('precision_admission_only') is True, '201 execution lacks admission-only scope')
    expected = copy.deepcopy(recipe)
    expected['checkpoint']['checkpoint_dir'] = '/work/checkpoints/' + directory.name
    _require(_json((directory / 'config.resolved.json').read_bytes()) == expected,
             'Resolved FSDP recipe differs beyond its checkpoint directory')
    pins = request['files']
    _require(_sha(directory / 'config.yaml') == pins['configs/' + directory.name + '.yaml'],
             'Executed YAML differs from its request pin')
    helper_hashes = {name: _sha(directory / name) for name in HELPERS}
    _require(all(pins['tools/' + name] == digest for name, digest in helper_hashes.items()),
             'Executed helper differs from its request pin')
    data_pins = {'data/sft_data_4k/' + name: value['sha256'] for name, value in data['files'].items()}
    _require(all(pins.get(name) == digest for name, digest in data_pins.items()),
             'Pinned dataset differs from the verified four-file dataset')
    flags, memories, timings = [], [], []
    for rank in range(RANKS):
        rows = _rank_trace(directory, rank)
        flags.append(_flags(directory, rank))
        memories.append(_memory(directory, rank))
        if rank == 0:
            timings = [row['performance/step_time'] for row in rows[20:]]
    _require(all(value == flags[0] for value in flags), 'Runtime flags differ across ranks')
    return {'case': directory.name, 'host': host, 'collection': manifest, 'runtime_flags': flags[0],
            'helper_sha256': helper_hashes, 'data_sha256': data_pins, 'receipt': receipt,
            'allocator_end_by_rank': memories, 'observed_median_step_seconds_after_20': statistics.median(timings),
            'guard_sampled_hbm_max_mb_by_device': receipt.get('sampled_hbm_max_mb_by_device'),
            'guard_sampled_container_cgroup_peak_bytes': receipt.get('sampled_container_cgroup_peak_bytes')}


def audit(reference: Path, candidate: Path, reference_manifest: Path, candidate_manifest: Path) -> dict:
    """Return separate evidence, main-LM admission and strict all-loss verdicts.

    Args:
        reference: Collected complete FSDP run from host 125 or 129.
        candidate: Collected complete FSDP run from host 201.
        reference_manifest: Collector manifest binding reference files and scheduling evidence.
        candidate_manifest: Collector manifest binding candidate files and scheduling evidence.

    Returns:
        A serializable report. Invalid evidence is rejected before a loss threshold can admit migration.
    """
    result = {'status': 'FAIL', 'evidence_status': 'FAIL', 'main_lm_status': 'UNVERIFIED',
              'migration_admitted': False, 'full_loss_strict_status': 'NOT_EVALUATED_INVALID_EVIDENCE',
              'scope': '201 cross-host admission only; does not accept parallel or resumed-training accuracy',
              'gate_policy': 'Main LM <= 0.005 after all evidence gates; auxiliary losses retain the strict verdict',
              'source': SOURCE, 'steps': [1, STEPS], 'ranks': RANKS, 'absolute_tolerance': TOLERANCE,
              'findings': [], 'cross_hardware_parallel_performance_claim': False,
              'memory_scope': 'Allocator lifetime peaks and guard sampled HBM are separate; neither is instantaneous '
                              'physical HBM or a cross-hardware parallel-strategy benefit.'}
    try:
        _require(reference.resolve() != candidate.resolve(), 'Independent executions are required')
        host = _json((reference.parent.parent / 'scheduling' / f'{reference.name}.receipt.json').read_bytes())['host']
        _require(host in ('125', '129'), 'Reference must run on shared host 125 or 129')
        recipe = _json((ROOT / 'evidence/201-fsdp8-reference-config.json').read_bytes())
        data = _json((ROOT / 'evidence/201-data-source-manifest.json').read_bytes())
        result['policy_input_sha256'] = {name: _sha(ROOT / name) for name in (
            'evidence/201-fsdp8-reference-config.json', 'evidence/201-data-source-manifest.json',
            'tools/audit_201_cross_host_admission.py', 'tools/strict_compare_runs.py', 'tools/compare_runs.py')}
        runs = [_run(reference, reference_manifest, host, recipe, data),
                _run(candidate, candidate_manifest, '201', recipe, data)]
        _require(runs[0]['runtime_flags'] == runs[1]['runtime_flags'], 'Runtime flags differ between hosts')
        _require(runs[0]['helper_sha256'] == runs[1]['helper_sha256'],
                 'Training observation helpers differ between hosts')
        strict = strict_audit(reference, candidate, 1, STEPS, TOLERANCE,
                              reference_manifest=reference_manifest, candidate_manifest=candidate_manifest)
        result['full_loss_strict_status'] = strict['status']
        _require(all(_finite(value) for value in strict['unweighted_error_diagnostics'].values()),
                 'A derived unweighted loss error is not finite')
        _require(all(value is None or _finite(value) for value in strict['performance'].values()),
                 'A derived performance observation is not finite')
        context = strict['measurement_context']
        context['eligible_for_matching_build_mode_performance_comparison'] = False
        context['excluded_reasons'].append('Different hosts/chips/drivers: no parallel-strategy performance claim')
        result.update(runs=runs, strict_comparison=strict, full_loss_strict_status=strict['status'])
        findings = list(strict['findings'])
        if strict['input_mismatch_count']:
            findings.append('Input identities differ between hosts')
        if strict['initial_mismatches']:
            findings.append('Initial parameters differ across ranks or hosts')
        _require(not findings, '; '.join(findings))
        lm = strict['errors']['training/foundation_loss/lm']['max_abs']
        _require(_finite(lm), 'Main LM error is not finite')
        passed = lm <= TOLERANCE
        result.update(evidence_status='PASS', main_lm_status='PASS' if passed else 'FAIL',
                      status='PASS' if passed else 'FAIL', migration_admitted=passed, main_lm_max_abs=lm)
        if not passed:
            result['findings'].append('Main LM absolute error exceeds 0.005 on at least one rank/step')
    except (OSError, ValueError, KeyError, TypeError, IndexError) as exc:
        result['findings'].append(str(exc))
    return result


def write_report(output: Path, result: dict, protected: tuple) -> None:
    """Create a new report outside all immutable input files and run directories."""
    target = output.resolve()
    for path in protected:
        resolved = path.resolve()
        _require(target != resolved and (not path.is_dir() or resolved not in target.parents),
                 'Report must not replace or enter input evidence')
    with output.open('x', encoding='utf-8') as handle:
        json.dump(result, handle, ensure_ascii=False, indent=2, allow_nan=False)
        handle.write('\n')


def main() -> None:
    """Audit fixed complete runs and leave existing evidence untouched."""
    parser = argparse.ArgumentParser()
    parser.add_argument('reference', type=Path)
    parser.add_argument('candidate', type=Path)
    parser.add_argument('--reference-manifest', type=Path, required=True)
    parser.add_argument('--candidate-manifest', type=Path, required=True)
    parser.add_argument('--output', type=Path, required=True)
    args = parser.parse_args()
    result = audit(args.reference, args.candidate, args.reference_manifest, args.candidate_manifest)
    scheduling_inputs = tuple(directory.parent.parent / 'scheduling' / f'{directory.name}.{kind}.json'
                              for directory in (args.reference, args.candidate) for kind in ('request', 'receipt'))
    protected = (args.reference, args.candidate, args.reference_manifest, args.candidate_manifest, *scheduling_inputs)
    write_report(args.output, result, protected)
    print(json.dumps({key: result[key] for key in ('status', 'evidence_status', 'main_lm_status',
                                                 'migration_admitted', 'full_loss_strict_status', 'findings')}))
    raise SystemExit(0 if result['migration_admitted'] else 1)


if __name__ == '__main__':
    main()
