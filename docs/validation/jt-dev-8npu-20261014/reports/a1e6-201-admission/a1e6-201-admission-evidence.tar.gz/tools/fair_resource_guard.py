# Copyright 2026 Huawei Technologies Co., Ltd
#
# Licensed under the Apache License, Version 2.0 (the "License");
# you may not use this file except in compliance with the License.
# You may obtain a copy of the License at
#
# http://www.apache.org/licenses/LICENSE-2.0
#
# Unless required by applicable law or agreed to in writing, software
# distributed under the License is distributed on an "AS IS" BASIS,
# WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
# See the License for the specific language governing permissions and
# limitations under the License.
# ============================================================================

"""Single-job device guard: never preempt other users, never retain devices between jobs."""

import hashlib
import json
import os
from pathlib import Path
import re
import shutil
import subprocess
import sys
import time


ROOT = Path('/home/xxl/jt-dev-8npu-20261014')
ALTERNATE_ROOT = Path('/var/tmp/xxl-jt-dev-8npu-20261014')
DEDICATED_ROOT = Path('/opt/xxl-jt-dev-8npu-20261014')
OWNER = '01a13aa4-a553-7e22-a1c1-ebd16b083bb9'
ALLOWED_IMAGES = {
    'sha256:4d302cd5859ea8cee8af72130937a446e79e709ed93d787b79fedd20f3a1e3a1',
    'sha256:5f9e677f439d11ab4e7c888f54b142335a27eee7411cbd2ce894a4798a70146d',
}
# Shared hosts retain their waiting interval; the dedicated host still requires verified release.
GAP_SECONDS = 1200
SSH_TARGETS = {'125': '125-root', '129': '129-root', '201': '201'}
DEDICATED_IMAGE = 'sha256:5f9e677f439d11ab4e7c888f54b142335a27eee7411cbd2ce894a4798a70146d'
DEDICATED_MEMORY_BYTES = 320 * 1024 ** 3
DEDICATED_MEMORY_RESERVE_BYTES = 64 * 1024 ** 3
DEDICATED_DISK_RESERVE_BYTES = 8 * 1024 ** 3
CHECKPOINT_DISK_RESERVE_BYTES = 64 * 1024 ** 3
A1E6_SOURCE = '544526f7db8342c607244fd41009b2a74adb84c8'
DEDICATED_RUNNER = '/work/tools/run_fair_201_training.sh'
CROSS_HOST_REFERENCE_RUNNER = '/work/tools/run_fair_cross_host_reference.sh'
A1E6_REFERENCE_RUNNER = '/work/tools/run_fair_a1e6_reference.sh'
A1E6_DEDICATED_CASES = {'r201-a1e6-fsdp8-3-v1': (30395, 600),
                        'r201-a1e6-fsdp8-0-200-v1': (30396, 900)}
A1E6_200_CASES = {'r125-a1e6-fsdp8-0-200-v1', 'r129-a1e6-fsdp8-0-200-v1',
                  'r201-a1e6-fsdp8-0-200-v1'}
DEDICATED_CASES = {'r201-e213-fsdp8-3-v1': (30387, 600), **A1E6_DEDICATED_CASES}
IDENTITY_FILE_BYTES = 4096
IDENTITY_PID_LIMIT = 16
OWNERSHIP_EVENT_BYTES = 8 * 1024 * 1024
RUNNER_REPOSITORIES = {
    DEDICATED_RUNNER: 'repo',
    CROSS_HOST_REFERENCE_RUNNER: 'repo',
    A1E6_REFERENCE_RUNNER: 'repo',
    '/work/tools/run_fair_training_case.sh': 'repo',
    '/work/tools/run_fair_dgrad_case.sh': 'repo',
    '/work/tools/run_fair_dgrad_200.sh': 'repo',
    '/work/tools/run_fair_dense_wgrad_200.sh': 'repo',
    '/work/tools/run_fair_head_row_vjp.sh': 'repo',
    '/work/tools/run_fair_latest_cp_control.sh': 'repo',
    '/work/tools/run_fair_head_pad_dx.sh': 'repo',
    '/work/tools/run_fair_f637_module_cost.sh': 'repo',
    '/work/tools/run_fair_fixed_pta_level_probe.sh': 'repo',
    '/work/tools/run_fair_fixed_pta_level2_retry.sh': 'repo',
    '/work/tools/run_fair_pr199_st.sh': 'fixes/pr199-f637-st',
    '/work/tools/run_fair_pr214_st.sh': 'fixes/pr214-npu-st',
}


def cooldown_remaining(state, wall_now, monotonic_now, host='129'):
    """Use the coordinator's clock, conservatively handling clock changes/reboots."""
    if host not in SSH_TARGETS:
        raise ValueError('Unknown resource host')
    if host == '201':
        return 0
    if 'released_wall' not in state:
        return 0
    elapsed_wall = wall_now - state['released_wall']
    elapsed_monotonic = monotonic_now - state['released_monotonic']
    elapsed = max(0, min(elapsed_wall, elapsed_monotonic))
    return max(0, GAP_SECONDS - elapsed)


def parse_cards(output):
    """Require explicit healthy, idle card rows and explicit zero-process evidence."""
    cards = {}
    current = None
    for line in output.splitlines():
        header = re.match(r'^\|\s*(\d+)\s+(910B\w*)\s*\|\s*(\w+)', line)
        if header:
            current = int(header.group(1))
            cards[current] = {'model': header.group(2), 'healthy': header.group(3) == 'OK',
                              'pids': [], 'empty': False}
        usage = re.match(r'^\|\s*0\s*\|\s*\S+\s*\|\s*(\d+)\s+(\d+)\s*/\s*(\d+)\s+(\d+)\s*/\s*(\d+)', line)
        if usage and current is not None:
            cards[current].update(core=int(usage.group(1)), hbm_mb=int(usage.group(4)),
                                  hbm_total_mb=int(usage.group(5)))
        empty = re.search(r'No running processes found in NPU\s+(\d+)', line)
        if empty and int(empty.group(1)) in cards:
            cards[int(empty.group(1))]['empty'] = True
        process = re.match(r'^\|\s*(\d+)\s+0\s*\|\s*(\d+)\s*\|', line)
        if process and int(process.group(1)) in cards:
            cards[int(process.group(1))]['pids'].append(int(process.group(2)))
    return cards


def card_observation():
    """Keep the raw device report alongside its parsed process identities."""
    output = subprocess.check_output(['npu-smi', 'info'], text=True, timeout=20)
    return {'raw': output, 'cards': parse_cards(output)}


def card_snapshot():
    return card_observation()['cards']


def process_identity(pid: int) -> dict:
    """Capture bounded, non-command-line ownership evidence while a process exists."""
    path = Path('/proc') / str(pid)
    result = {'pid': pid, 'observed_wall': time.time()}
    for name in ('status', 'stat', 'cgroup'):
        try:
            with (path / name).open('rb') as stream:
                data = stream.read(IDENTITY_FILE_BYTES + 1)
            result[name] = data[:IDENTITY_FILE_BYTES].decode('utf-8', errors='backslashreplace')
            result[name + '_truncated'] = len(data) > IDENTITY_FILE_BYTES
        except OSError as exc:
            result[name + '_error'] = str(exc)
    try:
        result['pid_namespace'] = os.readlink(path / 'ns/pid')
    except OSError as exc:
        result['pid_namespace_error'] = str(exc)
    return result


def free_cards(cards):
    return [index for index, row in cards.items() if row['healthy'] and row['empty'] and not row['pids']
            and row.get('core', -1) == 0 and row.get('hbm_mb', 999999) < 4096]


def record_probe_memory(receipt: dict, snapshot: dict, devices: list[int]) -> bool:
    """Record sampled card use; sampling cannot establish an instantaneous physical peak."""
    if len(devices) != 1 or devices[0] not in snapshot:
        raise RuntimeError('Single-card probe memory observation is missing')
    used = snapshot[devices[0]].get('hbm_mb')
    if isinstance(used, bool) or not isinstance(used, int) or used < 0:
        raise RuntimeError('Single-card probe memory observation is invalid')
    receipt['sampled_hbm_max_mb'] = max(receipt.get('sampled_hbm_max_mb', 0), used)
    receipt['hbm_sample_count'] = receipt.get('hbm_sample_count', 0) + 1
    receipt['hbm_sample_threshold_mb'] = 16384
    return used >= 16384


def save(path, value):
    temporary = path.with_suffix(path.suffix + '.tmp')
    temporary.write_text(json.dumps(value, indent=2) + '\n')
    temporary.replace(path)


def _save_ownership_event(path: Path, value: dict) -> None:
    """Keep diagnostic evidence below the collector's per-file budget."""
    payload = (json.dumps(value, indent=2) + '\n').encode('utf-8')
    if len(payload) > OWNERSHIP_EVENT_BYTES:
        value = {key: value[key] for key in (
            'observed_wall', 'container_id', 'devices', 'reported_unknown_pids')}
        value.update(evidence_truncated=True, original_serialized_bytes=len(payload))
    save(path, value)


def coordinator_paths(directory: Path, host: str) -> tuple[Path, Path]:
    """Isolate the exclusive machine without shortening shared-machine cooldowns."""
    if host not in SSH_TARGETS:
        raise ValueError('Unknown resource host')
    prefix = '201-resource' if host == '201' else 'global-resource'
    return directory / (prefix + '-state.json'), directory / (prefix + '.lock')


def verify_dedicated_release(receipt: dict) -> None:
    """A zero-gap restart requires positive release evidence for the same owner and host."""
    if (not isinstance(receipt, dict) or receipt.get('host') != '201' or receipt.get('owner') != OWNER
            or receipt.get('released') is not True or not isinstance(receipt.get('attempted'), bool)
            or receipt.get('remaining_owned_pids', []) != []):
        raise RuntimeError('Dedicated host requires a verified device-release receipt')
    if receipt['attempted'] and not re.fullmatch(r'[a-f0-9]{64}', receipt.get('container_id', '')):
        raise RuntimeError('Dedicated release receipt lacks the owned container identity')


def verify_coordinator_state(state: dict, host: str) -> None:
    """Refuse unresolved work even when the host has no scheduling delay."""
    if not isinstance(state, dict):
        raise RuntimeError('Resource state is invalid; inspect it before another launch')
    if state.get('phase') in ('running', 'uncertain'):
        raise RuntimeError('Previous job must be explicitly inspected before another launch')
    if host == '201' and state:
        if state.get('phase') not in ('ready', 'cooldown', 'waiting-for-free-cards'):
            raise RuntimeError('Unknown dedicated-host state; inspect it before another launch')
        verify_dedicated_release(state.get('last_receipt'))


def validate_dedicated_request(request: dict) -> None:
    """Allow only the prepared hardware, image, runner, case, port, deadline and input set."""
    if request['host'] != '201' and request['runner'] != DEDICATED_RUNNER:
        return
    expected = DEDICATED_CASES.get(request['case'])
    if (request['host'] != '201' or request['runner'] != DEDICATED_RUNNER or request['cards'] != 8
            or expected != (request['port'], request['timeout_seconds'])):
        raise ValueError('Dedicated training requires its pinned eight-card case, port and deadline on 201')
    if request['image'] != DEDICATED_IMAGE:
        raise ValueError('Dedicated training requires its verified immutable image')
    required = {'tools/fair_resource_guard.py', 'tools/run_fair_201_training.sh',
                'configs/' + request['case'] + '.yaml', 'tools/capture_training.py', 'tools/module_profile.py',
                'tools/expert_probe.py', 'tools/precision_experiments.py', 'tools/fp32_wgrad_experiment.py'}
    if request['case'] in A1E6_DEDICATED_CASES:
        if request['source'] != A1E6_SOURCE:
            raise ValueError('The new dedicated admission requires the reviewed a1e6 integration source')
        required.add('tools/capture_a1e6_training.py')
    has_data = any(relative.startswith('data/') and relative.endswith('.arrow') for relative in request['files'])
    if not required.issubset(request['files']) or not has_data:
        raise ValueError('Dedicated training is missing required pinned inputs')
    if (not re.fullmatch(r'[a-f0-9]{40}', request['source'])
            or not re.fullmatch(r'[a-f0-9]{64}', request['patch_sha256'])
            or any(not isinstance(value, str) or not re.fullmatch(r'[a-f0-9]{64}', value)
                   for value in request['files'].values())):
        raise ValueError('Dedicated training requires immutable source and input fingerprints')


def host_memory_bytes() -> dict:
    """Read current Linux available memory rather than assuming the inventory remains valid."""
    fields = {}
    for line in Path('/proc/meminfo').read_text().splitlines():
        match = re.fullmatch(r'(MemTotal|MemAvailable):\s+(\d+)\s+kB', line)
        if match:
            fields[match.group(1)] = int(match.group(2)) * 1024
    if set(fields) != {'MemTotal', 'MemAvailable'} or fields['MemAvailable'] > fields['MemTotal']:
        raise RuntimeError('Cannot establish available host memory')
    return fields


def verify_dedicated_history(root: Path) -> list[str]:
    """A previous remote start must have a matching release receipt before another start."""
    checked = []
    for state_path in sorted((root / 'scheduling').glob('r201-*.state.json')):
        state = json.loads(state_path.read_text())
        case = state_path.name.removesuffix('.state.json')
        if (state.get('host') != '201' or state.get('owner') != OWNER or state.get('case') != case
                or not re.fullmatch(r'[a-f0-9]{64}', state.get('container_id', ''))):
            raise RuntimeError('Previous dedicated remote state has an unknown identity')
        receipt_path = state_path.with_name(case + '.receipt.json')
        if not receipt_path.is_file():
            raise RuntimeError('Previous dedicated remote job lacks its release receipt')
        receipt = json.loads(receipt_path.read_text())
        verify_dedicated_release(receipt)
        if receipt.get('case') != case or receipt.get('container_id') != state['container_id']:
            raise RuntimeError('Previous dedicated remote release identity does not match')
        checked.append(case)
    return checked


def verify_disk_capacity(root: Path, reserve_bytes: int) -> dict:
    """Require free space on the actual task filesystem before allocating training devices."""
    disk_free = shutil.disk_usage(root).free
    if disk_free < reserve_bytes:
        raise RuntimeError('Insufficient free space for the planned training output and checkpoint reserve')
    return {'disk_free_bytes': disk_free, 'disk_reserve_bytes': reserve_bytes}


def dedicated_preflight(root: Path, docker: list[str],
                        disk_reserve_bytes: int = DEDICATED_DISK_RESERVE_BYTES) -> dict:
    """Check durable ownership, host capacity, runtime and prior jobs without preempting anything."""
    owner = json.loads((root / 'owner.json').read_text())
    if owner.get('owner') != OWNER:
        raise ValueError('Dedicated workspace ownership does not match')
    history = verify_dedicated_history(root)
    memory = host_memory_bytes()
    minimum_memory = DEDICATED_MEMORY_BYTES + DEDICATED_MEMORY_RESERVE_BYTES
    if memory['MemAvailable'] < minimum_memory:
        raise RuntimeError('Insufficient available host memory for the dedicated container and reserve')
    disk = verify_disk_capacity(root, disk_reserve_bytes)
    runtimes = json.loads(subprocess.check_output(docker + ['info', '--format', '{{json .Runtimes}}'],
                                                text=True, timeout=20))
    if 'runc' not in runtimes:
        raise RuntimeError('The verified explicit runc runtime is unavailable')
    existing = subprocess.check_output(docker + ['ps', '--all', '--quiet', '--no-trunc',
                                                '--filter', 'label=codex.owner=' + OWNER],
                                       text=True, timeout=20).strip()
    if existing:
        raise RuntimeError('An owned container still exists on 201; inspect release before another launch')
    return {'host_memory_bytes': memory, 'container_memory_limit_bytes': DEDICATED_MEMORY_BYTES,
            'host_memory_reserve_bytes': DEDICATED_MEMORY_RESERVE_BYTES, **disk, 'runtime': 'runc',
            'previous_released_cases': history, 'observed_wall': time.time()}


def verify_dedicated_cards(cards: dict) -> None:
    """Retain the actual eight-card 32-GiB hardware contract used for migration validation."""
    if (set(cards) != set(range(8))
            or any(row.get('model') != '910B4' or row.get('hbm_total_mb') != 32768 for row in cards.values())):
        raise RuntimeError('Dedicated hardware differs from the verified eight 910B4 32-GiB cards')


def container_memory_bytes(pid: int) -> dict:
    """Read kernel container accounting; unavailable fields remain explicitly unavailable."""
    if not isinstance(pid, int) or pid < 1:
        return {'unavailable': 'Container has no live init PID'}
    try:
        entries = Path('/proc', str(pid), 'cgroup').read_text().splitlines()
        for entry in entries:
            hierarchy, controllers, relative = entry.split(':', 2)
            if 'memory' in controllers.split(','):
                base = Path('/sys/fs/cgroup/memory')
                names = ('memory.usage_in_bytes', 'memory.max_usage_in_bytes')
            elif hierarchy == '0' and controllers == '':
                base = Path('/sys/fs/cgroup')
                names = ('memory.current', 'memory.peak')
            else:
                continue
            path = (base / relative.lstrip('/')).resolve()
            if path == base or base not in path.parents:
                return {'unavailable': 'Container memory cgroup path is not isolated'}
            result = {'path': path.as_posix()}
            for field, name in zip(('current_bytes', 'peak_bytes'), names):
                try:
                    result[field] = int((path / name).read_text().strip())
                except (OSError, ValueError) as exc:
                    result[field + '_unavailable'] = str(exc)
            return result
    except (OSError, ValueError) as exc:
        return {'unavailable': str(exc)}
    return {'unavailable': 'No memory cgroup entry was reported'}


def record_dedicated_sample(path: Path, receipt: dict, cards: dict, init_pid: int) -> None:
    """Keep small independent per-device samples; sampled maxima are not instantaneous HBM peaks."""
    sample = {'observed_wall': time.time(), 'cards': {}, 'container_memory': container_memory_bytes(init_pid)}
    try:
        sample['host_memory_bytes'] = host_memory_bytes()
    except (OSError, RuntimeError) as exc:
        sample['host_memory_unavailable'] = str(exc)
    maxima = receipt.setdefault('sampled_hbm_max_mb_by_device', {})
    core_maxima = receipt.setdefault('sampled_aicore_max_percent_by_device', {})
    for device in receipt['devices']:
        row = cards.get(device, {})
        sample['cards'][device] = {key: row.get(key) for key in ('hbm_mb', 'hbm_total_mb', 'core', 'healthy')}
        for key, target in (('hbm_mb', maxima), ('core', core_maxima)):
            value = row.get(key)
            if isinstance(value, int) and not isinstance(value, bool) and value >= 0:
                target[str(device)] = max(target.get(str(device), 0), value)
    peak = sample['container_memory'].get('peak_bytes')
    if isinstance(peak, int) and peak >= 0:
        receipt['sampled_container_cgroup_peak_bytes'] = max(
            receipt.get('sampled_container_cgroup_peak_bytes', 0), peak)
    receipt['device_sample_count'] = receipt.get('device_sample_count', 0) + 1
    receipt['device_sample_interval_seconds'] = 5
    receipt['device_memory_peak_scope'] = 'Per-device npu-smi sampled HBM maxima, not instantaneous physical peaks'
    with path.open('a', encoding='utf-8') as stream:
        stream.write(json.dumps(sample, separators=(',', ':')) + '\n')


def remote_workspace(request: dict) -> Path:
    """Select only a recorded task directory; an alternative must use a separate host filesystem."""
    default = DEDICATED_ROOT if request['host'] == '201' else ROOT
    selected = request.get('workspace', default.as_posix())
    allowed = {default.as_posix()}
    if request['host'] == '129':
        allowed.add(ALTERNATE_ROOT.as_posix())
    if request['host'] not in SSH_TARGETS or selected not in allowed:
        raise ValueError('Remote workspace is outside the authorized task directories')
    return Path(selected)


def remote_job(request):
    root = remote_workspace(request)
    if root.resolve() != root:
        raise ValueError('Remote workspace must not redirect through a symbolic link')
    case = request['case']
    if not re.fullmatch(r'[a-zA-Z0-9][a-zA-Z0-9_-]{1,100}', case):
        raise ValueError('Invalid case name')
    if request['host'] not in SSH_TARGETS or request['cards'] not in (1, 2, 4, 8):
        raise ValueError('Invalid host/card request')
    image = request['image']
    if image not in ALLOWED_IMAGES:
        raise ValueError('Image must match a verified immutable image ID')
    if not 1 <= request['timeout_seconds'] <= 900:
        raise ValueError('Every experiment must have a hard limit of at most 900 seconds')
    if request['runner'] not in RUNNER_REPOSITORIES:
        raise ValueError('Runner is outside the authorized one-experiment entry point')
    validate_dedicated_request(request)
    if request['runner'] == CROSS_HOST_REFERENCE_RUNNER:
        references = {'r129-e213-fsdp8-admission-200-v1': ('129', ALTERNATE_ROOT, 30388),
                      'r125-e213-fsdp8-admission-200-v1': ('125', ROOT, 30389)}
        if (references.get(case) != (request['host'], root, request['port']) or request['cards'] != 8
                or request['timeout_seconds'] != 900 or image != DEDICATED_IMAGE):
            raise ValueError('Cross-host reference requires its pinned eight-card 200-step case on a shared host')
    if request['runner'] == A1E6_REFERENCE_RUNNER:
        references = {'r125-a1e6-fsdp8-0-200-v1': ('125', ROOT, 30393),
                      'r129-a1e6-fsdp8-0-200-v1': ('129', ALTERNATE_ROOT, 30394)}
        if (references.get(case) != (request['host'], root, request['port']) or request['cards'] != 8
                or request['timeout_seconds'] != 900 or image != DEDICATED_IMAGE
                or request['source'] != A1E6_SOURCE):
            raise ValueError('The new reference requires its pinned a1e6 source and shared-host eight-card case')
    if request['runner'] == '/work/tools/run_fair_dgrad_case.sh':
        pattern = r'r(125|129)-f637-dgrad-(fsdp8|cp2)-(native|fp32)-3(?:-r[2-9][0-9]*)?'
        if request['cards'] != 8 or not re.fullmatch(pattern, case):
            raise ValueError('Linear dgrad diagnostics require eight devices and an explicit three-step arm')
    if request['runner'] == '/work/tools/run_fair_dgrad_200.sh':
        long_ports = {'r129-f637-dgrad-fsdp8-fp32-200-v1': 30378, 'r129-f637-dgrad-cp2-fp32-200-v1': 30379,
                      'r129-f637-dgrad-fsdp8-fp32-200-v2': 30380, 'r129-f637-dgrad-cp2-fp32-200-v2': 30381}
        if (request['host'] != '129' or request['cards'] != 8 or request['timeout_seconds'] != 900
                or case not in long_ports or request['port'] != long_ports[case]):
            raise ValueError('Long dgrad diagnostics require the pinned eight-card 200-step case on 129')
    if request['runner'] == '/work/tools/run_fair_dense_wgrad_200.sh':
        dense_ports = {'r129-f637-dense-wgrad-fsdp8-200-v1': 30382,
                       'r129-f637-dense-wgrad-cp2-200-v1': 30383}
        if (request['host'] != '129' or request['cards'] != 8 or request['timeout_seconds'] != 900
                or case not in dense_ports or request['port'] != dense_ports[case]):
            raise ValueError('Dense wgrad diagnostics require the pinned eight-card 200-step case on 129')
    if request['runner'] == '/work/tools/run_fair_head_row_vjp.sh':
        if (request['host'] != '129' or request['cards'] != 8 or request['timeout_seconds'] != 600
                or case != 'r129-f637-head-row-vjp-fsdp8-3-v1' or request['port'] != 30384):
            raise ValueError('Head row VJP requires its pinned eight-card three-step 600-second case on 129')
    latest_head_cases = {
        '/work/tools/run_fair_latest_cp_control.sh': ('r129-e213-native-cp2-3-v1', 30385),
        '/work/tools/run_fair_head_pad_dx.sh': ('r129-e213-head-pad-dx-cp2-3-v1', 30386),
    }
    if request['runner'] in latest_head_cases:
        expected_case, expected_port = latest_head_cases[request['runner']]
        if (request['host'] != '129' or request['cards'] != 8 or request['timeout_seconds'] != 600
                or case != expected_case or request['port'] != expected_port):
            raise ValueError('Latest head diagnosis requires its pinned eight-card three-step reservation on 129')
    if request['runner'] == '/work/tools/run_fair_f637_module_cost.sh':
        module_ports = {f'r129-f637-module-{arm}-40-v1': 30371 + index
                        for index, arm in enumerate(('off', 'norm6', 'dense1', 'moe2'))}
        if (request['host'] != '129' or request['cards'] != 8 or case not in module_ports
                or request['port'] != module_ports[case]):
            raise ValueError('Module-cost diagnostics require the pinned eight-card case and port on 129')
    probe_cases = {
        '/work/tools/run_fair_fixed_pta_level_probe.sh': {
            'r129-f637-pta-levels12-1npu-v1': 30375, 'r129-f637-pta-levels12-1npu-v2': 30376},
        '/work/tools/run_fair_fixed_pta_level2_retry.sh': {'r129-f637-pta-level2-1npu-v3': 30377},
    }
    single_probe = request['runner'] in probe_cases
    probe_ports = probe_cases.get(request['runner'], {})
    if single_probe and (request['host'] != '129' or request['cards'] != 1 or request['timeout_seconds'] != 600
                         or case not in probe_ports or request['port'] != probe_ports[case]):
        raise ValueError('PTA probe requires its pinned single-card 600-second case on 129')
    if request['runner'] in ('/work/tools/run_fair_pr199_st.sh', '/work/tools/run_fair_pr214_st.sh'):
        if request['cards'] != 4:
            raise ValueError('PR regression requires exactly four devices')
    if (root / 'runs' / case).exists():
        raise ValueError('Refusing to replace an existing run')
    repo = (root / RUNNER_REPOSITORIES[request['runner']]).resolve()
    if root not in repo.parents:
        raise ValueError('Source checkout resolves outside the task directory')
    source = subprocess.check_output(['git', '-C', str(repo), 'rev-parse', 'HEAD'], text=True).strip()
    patch = subprocess.check_output(['git', '-C', str(repo), 'diff', '--binary', 'HEAD'])
    if source != request['source'] or hashlib.sha256(patch).hexdigest() != request['patch_sha256']:
        raise ValueError('Source or patch fingerprint changed')
    for relative, expected in request['files'].items():
        path = (root / relative).resolve()
        if root not in path.parents or hashlib.sha256(path.read_bytes()).hexdigest() != expected:
            raise ValueError('Pinned input changed: ' + relative)
    directory = root / 'scheduling'
    if request['host'] == '201' and directory.resolve() != directory:
        raise ValueError('Dedicated scheduling directory must not redirect through a symbolic link')
    directory.mkdir(exist_ok=True)
    save(directory / (case + '.request.json'), request)
    dedicated = request['host'] == '201'
    docker = ['docker'] if request['host'] in ('129', '201') else [
        'docker', '-H', 'unix:///run/hp-pr-two-commits-20261008/docker.sock']
    checkpoint_case = case in A1E6_200_CASES
    disk_reserve = CHECKPOINT_DISK_RESERVE_BYTES if checkpoint_case else DEDICATED_DISK_RESERVE_BYTES
    preflight = dedicated_preflight(root, docker, disk_reserve) if dedicated else None
    checkpoint_disk = verify_disk_capacity(root, disk_reserve) if checkpoint_case and not dedicated else None
    before = card_snapshot()
    devices = free_cards(before)[:request['cards']]
    receipt = {'case': case, 'host': request['host'], 'owner': OWNER, 'attempted': False,
               'released': True, 'devices': devices, 'source': source, 'image': image,
               'patch_sha256': request['patch_sha256'], 'before': before, 'workspace': root.as_posix()}
    if checkpoint_disk is not None:
        receipt['checkpoint_disk_preflight'] = checkpoint_disk
    if dedicated and checkpoint_case:
        receipt['precision_admission_only'] = True
    if len(devices) != request['cards']:
        receipt['reason'] = 'insufficient-free-devices'
        return receipt
    if dedicated:
        verify_dedicated_cards(before)
        receipt['dedicated_preflight'] = preflight
    if single_probe:
        record_probe_memory(receipt, before, devices)
    time.sleep(5)
    rechecked = card_snapshot()
    if not set(devices).issubset(free_cards(rechecked)):
        receipt['reason'] = 'device-became-busy-before-launch'
        return receipt
    if dedicated:
        verify_dedicated_cards(rechecked)
    name = 'jt-fair-' + case
    memory_limit = str(DEDICATED_MEMORY_BYTES) if dedicated else ('16g' if single_probe else '320g')
    command = docker + ['create', '--name', name, '--label', 'codex.owner=' + OWNER,
                        '--label', 'codex.case=' + case, '--network', 'host', '--shm-size', '32g',
                        '--memory', memory_limit, '--pids-limit', '4096',
                        '--entrypoint', '/bin/bash',
                        '-w', '/work', '-v', str(root) + ':/work',
                        '-v', str(repo) + ':/workspace/hyper-parallel']
    if dedicated:
        command += ['--runtime', 'runc']
    if single_probe:
        command += ['--cpus', '4']
    for path in ('/usr/local/Ascend/driver', '/usr/local/Ascend/firmware', '/usr/local/dcmi',
                 '/usr/local/bin/npu-smi', '/etc/ascend_install.info', '/etc/hccn.conf', '/etc/vnpu.cfg'):
        if Path(path).exists():
            command += ['-v', path + ':' + path + ':ro']
    for index in devices:
        command += ['--device', '/dev/davinci' + str(index)]
    for path in ('/dev/davinci_manager', '/dev/devmm_svm', '/dev/hisi_hdc'):
        command += ['--device', path]
    visible = ','.join(str(index) for index in devices)
    command += ['-e', 'ASCEND_RT_VISIBLE_DEVICES=' + visible, image,
                request['runner'], case, str(request['port']), str(request['cards'])]
    container = subprocess.check_output(command, text=True).strip()
    receipt['container_id'] = container
    receipt['container_name'] = name
    owned = set()

    def inspect():
        info = json.loads(subprocess.check_output(docker + ['inspect', container], text=True))[0]
        if info['Config']['Labels'].get('codex.owner') != OWNER or info['Id'] != container:
            raise RuntimeError('Container ownership mismatch; no stop action allowed')
        return info

    def stop_owned():
        if inspect()['State']['Running']:
            subprocess.run(docker + ['stop', '--time', '10', container], check=True, capture_output=True)

    started = time.monotonic()
    try:
        receipt.update(attempted=True, released=False, started_wall=time.time())
        save(directory / (case + '.state.json'), receipt)
        with (directory / (case + '.container.log')).open('w') as log:
            process = subprocess.Popen(docker + ['start', '-a', container], stdout=log, stderr=subprocess.STDOUT)
            while process.poll() is None:
                time.sleep(5)
                info = inspect()
                if not info['State']['Running']:
                    continue
                if time.monotonic() - started > request['timeout_seconds']:
                    receipt['reason'] = 'experiment-wall-time-limit'
                    stop_owned()
                    continue
                top = subprocess.run(docker + ['top', container, '-eo', 'pid'], capture_output=True, text=True)
                if top.returncode:
                    continue
                owned.update(int(value) for value in top.stdout.split() if value.isdigit())
                observation = card_observation()
                snapshot = observation['cards']
                if dedicated:
                    sample_path = directory / (case + '.device-samples.jsonl')
                    record_dedicated_sample(sample_path, receipt, snapshot, info['State']['Pid'])
                    receipt['device_samples'] = str(sample_path.relative_to(root))
                if single_probe and record_probe_memory(receipt, snapshot, devices):
                    receipt['reason'] = 'probe-sampled-device-memory-threshold'
                    stop_owned()
                    continue
                foreign = {pid for index in devices for pid in snapshot.get(index, {}).get('pids', [])
                           if pid not in owned and Path('/proc/' + str(pid)).exists()}
                if foreign:
                    identity_candidates_before = len(foreign)
                    identities_before = {pid: process_identity(pid) for pid in sorted(foreign)[:IDENTITY_PID_LIMIT]}
                    # A worker may start between docker top and the NPU snapshot.
                    refreshed = subprocess.run(docker + ['top', container, '-eo', 'pid'],
                                               capture_output=True, text=True)
                    if refreshed.returncode:
                        continue
                    owned.update(int(value) for value in refreshed.stdout.split() if value.isdigit())
                    foreign.difference_update(owned)
                if foreign:
                    event_path = directory / (case + '.ownership-event.json')
                    _save_ownership_event(event_path, {
                        'observed_wall': time.time(), 'container_id': container,
                        'container_init': process_identity(info['State']['Pid']),
                        'devices': devices, 'npu_smi': observation['raw'][:65536],
                        'npu_smi_truncated': len(observation['raw']) > 65536,
                        'top_before': {'stdout': top.stdout[:65536], 'stderr': top.stderr[:65536],
                                       'truncated': len(top.stdout) > 65536 or len(top.stderr) > 65536,
                                       'returncode': top.returncode},
                        'top_after': {'stdout': refreshed.stdout[:65536], 'stderr': refreshed.stderr[:65536],
                                      'truncated': len(refreshed.stdout) > 65536 or len(refreshed.stderr) > 65536,
                                      'returncode': refreshed.returncode},
                        'owned_pids_seen': sorted(owned)[:4096], 'owned_pids_truncated': len(owned) > 4096,
                        'reported_unknown_pids': sorted(foreign)[:128],
                        'unknown_pids_truncated': len(foreign) > 128,
                        'identity_pid_limit': IDENTITY_PID_LIMIT,
                        'identity_candidates_before_refresh': identity_candidates_before,
                        'identities_before_truncated': identity_candidates_before > IDENTITY_PID_LIMIT,
                        'identities_after_truncated': len(foreign) > IDENTITY_PID_LIMIT,
                        'identities_before_refresh': identities_before,
                        'identities_after_refresh': {
                            pid: process_identity(pid) for pid in sorted(foreign)[:IDENTITY_PID_LIMIT]},
                    })
                    receipt.update(reason='foreign-job-appeared-on-selected-devices', foreign_pids=sorted(foreign))
                    receipt['ownership_event'] = str(event_path.relative_to(root))
                    stop_owned()
            process.wait(timeout=30)
            receipt['exit_code'] = inspect()['State']['ExitCode']
    finally:
        stop_owned()
        info = inspect()
        if info['State']['Running']:
            raise RuntimeError('Owned container did not stop; block subsequent experiments')
        remaining = set()
        for _ in range(6):
            after = card_snapshot()
            remaining = {pid for row in after.values() for pid in row['pids']} & owned
            if not remaining:
                break
            time.sleep(5)
        receipt.update(released=not remaining, remaining_owned_pids=sorted(remaining), after=after,
                       finished_wall=time.time(), duration_seconds=time.monotonic() - started)
        save(directory / (case + '.receipt.json'), receipt)
        if not remaining:
            subprocess.run(docker + ['rm', container], check=True, capture_output=True)
    return receipt


def local_job(path):
    import msvcrt

    root = Path(__file__).resolve().parents[1]
    directory = root / 'scheduling'
    directory.mkdir(exist_ok=True)
    request = json.loads(Path(path).read_text())
    remote_root = remote_workspace(request)
    state_path, lock_path = coordinator_paths(directory, request['host'])
    with lock_path.open('a+b') as lock:
        if lock.tell() == 0:
            lock.write(b'0')
            lock.flush()
        lock.seek(0)
        msvcrt.locking(lock.fileno(), msvcrt.LK_NBLCK, 1)
        state = json.loads(state_path.read_text()) if state_path.exists() else {}
        verify_coordinator_state(state, request['host'])
        remaining = cooldown_remaining(state, time.time(), time.monotonic(), request['host'])
        if remaining > 0:
            print(json.dumps({'phase': 'cooldown', 'remaining_seconds': remaining}), flush=True)
            return 75
        state.update(phase='running', request=request, requested_wall=time.time())
        save(state_path, state)
        ssh = ['ssh', '-o', 'BatchMode=yes', '-o', 'ConnectTimeout=10', SSH_TARGETS[request['host']],
               'python3', (remote_root / 'tools/fair_resource_guard.py').as_posix(), '--remote']
        print(json.dumps({'phase': 'checking-and-launching', 'host': request['host'], 'case': request['case']}), flush=True)
        try:
            result = subprocess.run(ssh, input=json.dumps(request), capture_output=True, text=True,
                                    timeout=request['timeout_seconds'] + 180)
            (directory / (request['case'] + '.launcher.log')).write_text(result.stdout + result.stderr)
            receipts = [json.loads(line)['final_receipt'] for line in result.stdout.splitlines()
                        if line.startswith('{"final_receipt":')]
            if len(receipts) != 1 or not receipts[0]['released']:
                raise RuntimeError('Missing verified device-release receipt; do not launch another experiment')
            receipt = receipts[0]
            if request['host'] == '201':
                verify_dedicated_release(receipt)
                if receipt.get('case') != request['case']:
                    raise RuntimeError('Dedicated release receipt belongs to a different case')
            save(directory / (request['case'] + '.receipt.json'), receipt)
            if receipt['attempted']:
                dedicated = request['host'] == '201'
                state.update(phase='ready' if dedicated else 'cooldown', released_wall=time.time(),
                             released_monotonic=time.monotonic(), minimum_gap_seconds=0 if dedicated else GAP_SECONDS,
                             last_receipt=receipt)
            else:
                state.update(phase='waiting-for-free-cards', last_receipt=receipt)
            save(state_path, state)
            print(json.dumps({'phase': state['phase'], 'receipt': receipt}), flush=True)
            return receipt.get('exit_code', 75)
        except BaseException:
            state['phase'] = 'uncertain'
            save(state_path, state)
            raise


if __name__ == '__main__':
    if sys.argv[1] == '--remote':
        outcome = remote_job(json.load(sys.stdin))
        print(json.dumps({'final_receipt': outcome}), flush=True)
    else:
        raise SystemExit(local_job(sys.argv[1]))
