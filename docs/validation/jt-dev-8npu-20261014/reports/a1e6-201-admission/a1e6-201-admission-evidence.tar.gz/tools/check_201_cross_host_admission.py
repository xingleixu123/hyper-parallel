# Copyright 2026 Huawei Technologies Co., Ltd
#
# Licensed under the Apache License, Version 2.0 (the "License");
# you may not use this file except in compliance with the License.
# You may obtain a copy of the License at
#
# http://www.apache.org/licenses/LICENSE-2.0
#
# Unless required by applicable law or agreed to in writing, software
# distributed under the License is distributed on an "AS IS" BASIS,
# WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
# See the License for the specific language governing permissions and
# limitations under the License.
# ============================================================================

"""CPU synthetic counterexamples for 201 admission; these are not training results."""

import copy
import hashlib
import json
import shutil
from pathlib import Path
import tempfile
import unittest

import audit_201_cross_host_admission as admission


def write_json(path: Path, value: object) -> None:
    """Write synthetic input, including deliberate invalid JSON numbers in negative cases."""
    path.write_text(json.dumps(value), encoding='utf-8')


def seal(directory: Path) -> Path:
    """Create a synthetic collector manifest after an intentional fixture change."""
    root = directory.parent.parent
    paths = list(directory.iterdir()) + [root / 'scheduling' / f'{directory.name}.{kind}.json'
                                        for kind in ('request', 'receipt')]
    manifest = root / f'{directory.name}.manifest.json'
    entries = [{'path': path.relative_to(root).as_posix(), 'bytes': path.stat().st_size,
                'sha256': hashlib.sha256(path.read_bytes()).hexdigest()} for path in sorted(paths)]
    write_json(manifest, {'files': entries})
    return manifest


class AdmissionCounterexamples(unittest.TestCase):
    """Reject incomplete or incomparable evidence without making auxiliary losses the main-only gate."""

    def setUp(self) -> None:
        self.temporary = tempfile.TemporaryDirectory(prefix='jt-201-admission-')
        self.addCleanup(self.temporary.cleanup)
        self.root = Path(self.temporary.name)
        self.reference = self.root / 'runs/r129-a1e6-fsdp8-0-200-v1'
        self.candidate = self.root / 'runs/r201-a1e6-fsdp8-0-200-v1'
        self.fixture(self.reference, '129', '1')
        self.fixture(self.candidate, '201', '2')

    def fixture(self, directory: Path, host: str, identity: str) -> None:
        """Materialize complete deterministic synthetic evidence with valid provenance structure."""
        directory.mkdir(parents=True)
        config = json.loads((admission.ROOT / 'evidence/201-fsdp8-reference-config.json').read_bytes())
        config['checkpoint']['checkpoint_dir'] = '/work/checkpoints/' + directory.name
        write_json(directory / 'config.resolved.json', config)
        (directory / 'config.yaml').write_text('synthetic: true\n')
        (directory / 'source-commit.txt').write_text(admission.SOURCE)
        (directory / 'source-status.txt').write_bytes(b'')
        (directory / 'source.patch').write_bytes(b'')
        (directory / 'EXIT_CODE').write_text('0')
        for name in admission.HELPERS:
            (directory / name).write_text('# Synthetic observation helper\n')
        environment = dict.fromkeys(admission.ENVIRONMENT_KEYS)
        environment.update(PYTHONHASHSEED='42', PYTORCH_NPU_ALLOC_CONF='expandable_segments:True')
        training_environment = {**environment, 'NCCL_DETERMINISTIC': 'true',
                                'FLASH_ATTENTION_DETERMINISTIC': '1', 'CUBLAS_WORKSPACE_CONFIG': ':16:8'}
        flags = {'before_trainer': {'environment': environment, 'scope': 'Environment only; no backend queries'},
                 'training': {'environment': training_environment, 'deterministic_algorithms': True,
                              'deterministic_warn_only': False,
                              'npu_matmul': dict.fromkeys(admission.MATMUL_KEYS, False)}}
        for rank in range(8):
            write_json(directory / f'initial-state-rank{rank}.json',
                       {'synthetic.weight': {'shape': [2], 'dtype': 'float32', 'sha256': 'd' * 64}})
            write_json(directory / f'start-rank{rank}.json',
                       {'global_step': 0, 'train_iters': 200, 'micro_batches': 1})
            write_json(directory / f'complete-rank{rank}.json', {'global_step': 200})
            write_json(directory / f'runtime-flags-rank{rank}.json', flags)
            write_json(directory / f'final-memory-rank{rank}.json', {
                'global_step': 200, 'device': rank, 'allocated_bytes': 2, 'reserved_bytes': 3,
                'max_allocated_bytes': 4, 'max_reserved_bytes': 5, 'scope': admission.MEMORY_SCOPE})
            rows = [{'step': step, 'rank': rank, 'training/total_loss': 4.0001,
                     'training/foundation_loss/lm': 3.0, 'training/foundation_loss/mtp': 1.0,
                     'training/foundation_loss/aux': 0.0001, 'training/grad_norm': 1.0, 'training/lr': 0.0001,
                     'memory/device_max_allocated_gb': 2.0, 'memory/device_max_reserved_gb': 3.0,
                     'performance/step_time': 1.0, 'data/step_tokens': 32768, 'data/step_samples': 8,
                     'data/consumed_tokens': 32768 * step, 'data/consumed_samples': 8 * step,
                     'input_identity': {'global_sha256': hashlib.sha256(str(step).encode()).hexdigest(),
                                        'rank_count': 8, 'micro_steps': 1}} for step in range(1, 201)]
            self.write_rows(directory, rank, rows)
        scheduling = self.root / 'scheduling'
        scheduling.mkdir(exist_ok=True)
        data = json.loads((admission.ROOT / 'evidence/201-data-source-manifest.json').read_bytes())
        pins = {'data/sft_data_4k/' + name: value['sha256'] for name, value in data['files'].items()}
        pins.update({'tools/' + name: hashlib.sha256((directory / name).read_bytes()).hexdigest()
                     for name in admission.HELPERS})
        pins['configs/' + directory.name + '.yaml'] = hashlib.sha256(
            (directory / 'config.yaml').read_bytes()).hexdigest()
        common = {'case': directory.name, 'host': host, 'workspace': admission.WORKSPACES[host],
                  'source': admission.SOURCE, 'image': admission.IMAGE, 'patch_sha256': hashlib.sha256(b'').hexdigest()}
        write_json(scheduling / f'{directory.name}.request.json',
                   {**common, 'cards': 8, 'timeout_seconds': 900, 'runner': admission.RUNNERS[host], 'files': pins})
        write_json(scheduling / f'{directory.name}.receipt.json',
                   {**common, 'owner': admission.OWNER, 'container_id': identity * 64, 'attempted': True,
                    'released': True, 'exit_code': 0, 'devices': list(range(8)), 'remaining_owned_pids': [],
                    'precision_admission_only': host == '201'})

    @staticmethod
    def write_rows(directory: Path, rank: int, rows: list) -> None:
        """Write ordered synthetic optimizer steps."""
        (directory / f'metrics-rank{rank}.jsonl').write_text(''.join(json.dumps(row) + '\n' for row in rows))

    @staticmethod
    def rows(directory: Path, rank: int = 7) -> list:
        """Read a synthetic trace for a deliberately invalid mutation."""
        return [json.loads(line) for line in (directory / f'metrics-rank{rank}.jsonl').read_bytes().splitlines()]

    def run_audit(self) -> dict:
        """Seal each synthetic run and apply the real offline audit."""
        return admission.audit(self.reference, self.candidate, seal(self.reference), seal(self.candidate))

    def rejected(self) -> dict:
        """Assert that a counterexample cannot sign a migration acceptance."""
        result = self.run_audit()
        self.assertFalse(result['migration_admitted'], result)
        self.assertEqual(result['status'], 'FAIL')
        self.assertTrue(result['findings'])
        return result

    def mutate_json(self, directory: Path, name: str, mutate: object) -> None:
        """Change one synthetic JSON object and retain all unrelated evidence."""
        path = directory / name
        value = json.loads(path.read_bytes())
        mutate(value)
        write_json(path, value)

    def test_complete_pass_and_no_cross_hardware_performance_claim(self) -> None:
        """A valid run admits main LM, while forbidding a hardware-derived parallel speedup claim."""
        for host in ('129', '125'):
            with self.subTest(reference_host=host):
                if host == '125':
                    self.reference = self.root / 'runs/r125-a1e6-fsdp8-0-200-v1'
                    self.fixture(self.reference, host, '3')
                result = self.run_audit()
                self.assertTrue(result['migration_admitted'], result)
                self.assertEqual(result['full_loss_strict_status'], 'PASS')
                self.assertFalse(result['cross_hardware_parallel_performance_claim'])
                self.assertFalse(result['strict_comparison']['measurement_context']
                                 ['eligible_for_matching_build_mode_performance_comparison'])

    def test_aux_unweighted_failure_retained_without_blocking_main(self) -> None:
        """An auxiliary error visible only after unweighting stays a strict failure."""
        rows = self.rows(self.candidate)
        rows[-1]['training/foundation_loss/aux'] += 0.000001
        self.write_rows(self.candidate, 7, rows)
        result = self.run_audit()
        self.assertTrue(result['migration_admitted'], result)
        self.assertEqual(result['full_loss_strict_status'], 'FAIL')
        self.assertGreater(result['strict_comparison']['unweighted_error_diagnostics']['aux'], 0.005)

    def test_mtp_failure_retained_without_blocking_main(self) -> None:
        """MTP above its raw threshold cannot be silently presented as all-loss PASS."""
        rows = self.rows(self.candidate)
        rows[-1]['training/foundation_loss/mtp'] += 0.002
        self.write_rows(self.candidate, 7, rows)
        result = self.run_audit()
        self.assertTrue(result['migration_admitted'], result)
        self.assertEqual(result['full_loss_strict_status'], 'FAIL')

    def test_main_lm_threshold_on_last_rank_last_step(self) -> None:
        """The main gate covers every rank and every optimizer step."""
        rows = self.rows(self.candidate)
        rows[-1]['training/foundation_loss/lm'] += 0.00501
        self.write_rows(self.candidate, 7, rows)
        result = self.rejected()
        self.assertEqual(result['evidence_status'], 'PASS')
        self.assertEqual(result['main_lm_status'], 'FAIL')

    def test_missing_or_duplicate_step(self) -> None:
        """Missing and duplicated rows both invalidate otherwise identical losses."""
        baseline = self.rows(self.candidate)
        for rows in (baseline[:-1], baseline[:-1] + [baseline[-2]], baseline[1:] + baseline[:1]):
            with self.subTest(ending=[row['step'] for row in rows[-2:]]):
                self.write_rows(self.candidate, 7, rows)
                self.rejected()

    def test_missing_rank(self) -> None:
        """Seven complete ranks cannot represent an eight-card run."""
        (self.candidate / 'metrics-rank7.jsonl').unlink()
        self.rejected()

    def test_extra_rank_evidence(self) -> None:
        """An isolated eight-card run must not contain an unexplained ninth rank trace."""
        (self.candidate / 'metrics-rank8.jsonl').write_bytes((self.candidate / 'metrics-rank7.jsonl').read_bytes())
        self.rejected()

    def test_short_three_step_smoke_is_not_migration_acceptance(self) -> None:
        """A perfect three-step prefix remains ineligible."""
        for rank in range(8):
            self.write_rows(self.candidate, rank, self.rows(self.candidate, rank)[:3])
            self.mutate_json(self.candidate, f'complete-rank{rank}.json', lambda value: value.update(global_step=3))
        self.rejected()

    def test_nonfinite_main_aux_grad_and_time(self) -> None:
        """Even diagnostic loss or timing NaN cannot be hidden by main-only filtering."""
        baseline = self.rows(self.candidate)
        for key in ('training/foundation_loss/lm', 'training/foundation_loss/aux',
                    'training/grad_norm', 'performance/step_time'):
            for invalid in (float('nan'), float('inf')):
                with self.subTest(key=key, value=str(invalid)):
                    rows = copy.deepcopy(baseline)
                    rows[-1][key] = invalid
                    self.write_rows(self.candidate, 7, rows)
                    self.rejected()

    def test_source_and_dirty_source_rejected(self) -> None:
        """Matching numerical outputs do not substitute for the reviewed source."""
        (self.candidate / 'source-commit.txt').write_text('e' * 40)
        self.rejected()
        (self.candidate / 'source-commit.txt').write_text(admission.SOURCE)
        (self.candidate / 'source-status.txt').write_text(' M trainer.py\n')
        self.rejected()

    def test_overflow_in_derived_auxiliary_error_is_unverified(self) -> None:
        """A finite logged value cannot create an infinite diagnostic inside an admitted report."""
        rows = self.rows(self.candidate)
        rows[-1]['training/foundation_loss/aux'] = 1.0e308
        self.write_rows(self.candidate, 7, rows)
        result = self.rejected()
        self.assertEqual(result['main_lm_status'], 'UNVERIFIED')
        json.dumps(result, allow_nan=False)

    def test_input_mismatch_and_shared_cross_rank_error(self) -> None:
        """Cross-host and common cross-rank identity corruption are both rejected."""
        baseline = self.rows(self.candidate)
        changed = copy.deepcopy(baseline)
        changed[-1]['input_identity']['global_sha256'] = 'e' * 64
        self.write_rows(self.candidate, 7, changed)
        self.rejected()
        self.write_rows(self.reference, 7, changed)
        self.rejected()

    def test_initial_state_mismatch(self) -> None:
        """An altered initial tensor prevents an accuracy comparison."""
        self.mutate_json(self.candidate, 'initial-state-rank7.json',
                         lambda value: value['synthetic.weight'].update(sha256='f' * 64))
        self.rejected()

    def test_counter_mismatch_even_if_shared_by_hosts(self) -> None:
        """Identically stale cumulative counters are not accepted as valid data progress."""
        for directory in (self.reference, self.candidate):
            rows = self.rows(directory)
            rows[-1]['data/consumed_samples'] -= 8
            self.write_rows(directory, 7, rows)
        self.rejected()

    def test_flag_mismatch_between_ranks_and_between_hosts(self) -> None:
        """All ranks and both hosts must use one recorded backend environment."""
        def change(value: dict) -> None:
            value['before_trainer']['environment']['CLOSE_MATMUL_K_SHIFT'] = '1'
            value['training']['environment']['CLOSE_MATMUL_K_SHIFT'] = '1'
        self.mutate_json(self.candidate, 'runtime-flags-rank7.json', change)
        self.rejected()
        for rank in range(7):
            self.mutate_json(self.candidate, f'runtime-flags-rank{rank}.json', change)
        self.rejected()

    def test_missing_flag_and_memory_scope(self) -> None:
        """End-of-run allocator evidence cannot be relabeled as physical HBM."""
        flags = (self.candidate / 'runtime-flags-rank7.json').read_bytes()
        (self.candidate / 'runtime-flags-rank7.json').unlink()
        self.rejected()
        (self.candidate / 'runtime-flags-rank7.json').write_bytes(flags)
        self.mutate_json(self.candidate, 'final-memory-rank7.json', lambda value: value.update(scope='physical HBM'))
        self.rejected()

    def test_matching_warn_only_cannot_override_the_jt_builder_policy(self) -> None:
        """Two agreeing hosts cannot substitute warning-only mode for the reviewed builder's strict mode."""
        for directory in (self.reference, self.candidate):
            for rank in range(8):
                self.mutate_json(directory, f'runtime-flags-rank{rank}.json',
                                 lambda value: value['training'].update(deterministic_warn_only=True))
        result = self.rejected()
        self.assertEqual(result['main_lm_status'], 'UNVERIFIED')
        self.assertTrue(any('reviewed JT model builder' in value for value in result['findings']))

    def test_manifest_hash_mismatch(self) -> None:
        """Replacing a collected file after collection invalidates the comparison."""
        reference_manifest, candidate_manifest = seal(self.reference), seal(self.candidate)
        (self.candidate / 'source-status.txt').write_text(' ')
        result = admission.audit(self.reference, self.candidate, reference_manifest, candidate_manifest)
        self.assertFalse(result['migration_admitted'])
        self.assertTrue(any('SHA or size' in value for value in result['findings']))

    def test_alternate_directory_cannot_substitute_unmanifested_flags(self) -> None:
        """Reject an archive copy whose flags were never bound by the collector manifest."""
        alternate = self.root / 'archive' / self.candidate.name
        shutil.copytree(self.candidate, alternate)

        def change(value: dict) -> None:
            value['before_trainer']['environment']['CLOSE_MATMUL_K_SHIFT'] = '1'
            value['training']['environment']['CLOSE_MATMUL_K_SHIFT'] = '1'

        for rank in range(8):
            self.mutate_json(self.candidate, f'runtime-flags-rank{rank}.json', change)
        reference_manifest, candidate_manifest = seal(self.reference), seal(self.candidate)
        manifest = json.loads(candidate_manifest.read_bytes())
        names = ['config.resolved.json', 'source-commit.txt', 'source.patch', 'EXIT_CODE']
        names += [f'{prefix}-rank{rank}.{suffix}' for rank in range(8)
                  for prefix, suffix in (('initial-state', 'json'), ('start', 'json'),
                                         ('complete', 'json'), ('metrics', 'jsonl'))]
        manifest['files'].extend({'path': path.relative_to(self.root).as_posix(), 'bytes': path.stat().st_size,
                                  'sha256': hashlib.sha256(path.read_bytes()).hexdigest()}
                                 for path in (alternate / name for name in names))
        write_json(candidate_manifest, manifest)
        canonical = admission.audit(self.reference, self.candidate, reference_manifest, candidate_manifest)
        self.assertFalse(canonical['migration_admitted'])
        self.assertIn('Runtime flags differ between hosts', canonical['findings'])
        result = admission.audit(self.reference, alternate, reference_manifest, candidate_manifest)
        self.assertFalse(result['migration_admitted'])
        self.assertEqual(result['main_lm_status'], 'UNVERIFIED')
        self.assertTrue(any('canonical task runs/case' in value for value in result['findings']))

    def test_agreeing_request_and_receipt_must_use_the_authorized_host_root(self) -> None:
        """Matching forged or swapped workspaces remain invalid on each admitted host."""
        for directory, host in ((self.reference, '129'), (self.candidate, '201')):
            paths = [self.root / 'scheduling' / f'{directory.name}.{kind}.json'
                     for kind in ('request', 'receipt')]
            originals = [json.loads(path.read_bytes()) for path in paths]
            invalid = ['/wrong-task-root/not-the-authorized-workspace']
            invalid += [root for key, root in admission.WORKSPACES.items() if key != host]
            for workspace in invalid:
                with self.subTest(host=host, workspace=workspace):
                    for path, value in zip(paths, originals):
                        write_json(path, {**value, 'workspace': workspace})
                    result = self.rejected()
                    self.assertEqual(result['main_lm_status'], 'UNVERIFIED')
                    self.assertTrue(any('Requested workspace' in value for value in result['findings']))
            for path, value in zip(paths, originals):
                write_json(path, value)

    def test_request_dataset_pin_and_helper_pin(self) -> None:
        """Actual helper and dataset request pins must remain bound to reviewed evidence."""
        request_path = self.root / 'scheduling' / f'{self.candidate.name}.request.json'
        request = json.loads(request_path.read_bytes())
        original = copy.deepcopy(request)
        request['files']['data/sft_data_4k/state.json'] = 'e' * 64
        write_json(request_path, request)
        self.rejected()
        write_json(request_path, original)
        (self.candidate / 'capture_a1e6_training.py').write_text('# Changed observation\n')
        self.rejected()

    def test_parallel_recipe_and_window_changes_rejected(self) -> None:
        """This host admission cannot be reused for a TP/CP/recompute experiment."""
        path = self.candidate / 'config.resolved.json'
        baseline = json.loads(path.read_bytes())
        for section, key, value in (('accelerator', 'cp_size', 2), ('activation_checkpoint', 'mode', 'full'),
                                    ('training', 'train_iters', 3), ('checkpoint', 'save_ckpt', False)):
            with self.subTest(section=section, key=key):
                changed = copy.deepcopy(baseline)
                changed[section][key] = value
                write_json(path, changed)
                self.rejected()

    def test_execution_identity_release_and_host(self) -> None:
        """Copied executions, remaining owned processes and wrong hosts cannot qualify."""
        path = self.root / 'scheduling' / f'{self.candidate.name}.receipt.json'
        baseline = json.loads(path.read_bytes())
        for key, value in (('container_id', '1' * 64), ('remaining_owned_pids', [123]),
                           ('released', False), ('host', '129'), ('exit_code', 137)):
            with self.subTest(key=key):
                write_json(path, {**baseline, key: value})
                self.rejected()

    def test_report_does_not_replace_or_enter_evidence(self) -> None:
        """Reports are created exclusively outside protected inputs."""
        result = {'status': 'FAIL'}
        with self.assertRaises(ValueError):
            admission.write_report(self.candidate / 'new.json', result, (self.candidate,))
        path = self.root / 'report.json'
        admission.write_report(path, result, (self.reference, self.candidate))
        with self.assertRaises(FileExistsError):
            admission.write_report(path, {'status': 'PASS'}, (self.reference, self.candidate))
        self.assertEqual(json.loads(path.read_bytes()), result)


if __name__ == '__main__':
    unittest.main()
