# Copyright 2026 Huawei Technologies Co., Ltd
#
# Licensed under the Apache License, Version 2.0 (the "License");
# you may not use this file except in compliance with the License.
# You may obtain a copy of the License at
#
# http://www.apache.org/licenses/LICENSE-2.0
#
# Unless required by applicable law or agreed to in writing, software
# distributed under the License is distributed on an "AS IS" BASIS,
# WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
# See the License for the specific language governing permissions and
# limitations under the License.
# ============================================================================

"""Run the prepared matrix parser in a bounded CPU-only container on 201."""

import argparse
import hashlib
import json
from pathlib import Path
import subprocess
import time


ROOT = Path(__file__).resolve().parents[1]
OWNER = "01a13aa4-a553-7e22-a1c1-ebd16b083bb9"
IMAGE = "sha256:5f9e677f439d11ab4e7c888f54b142335a27eee7411cbd2ce894a4798a70146d"
SOURCE = "544526f7db8342c607244fd41009b2a74adb84c8"
CASE = "201-a1e6-matrix-config-cpu-v1"
CASES = {CASE: "source /workspace/env.sh && export OMP_NUM_THREADS=1 && "
               "/work/venvs/validation/bin/python /work/tools/check_a1e6_matrix_configs_cpu.py"}


def inspect_container(container_id: str) -> dict:
    """Return the exact container and verify task ownership before any cleanup."""
    result = json.loads(subprocess.check_output(["docker", "inspect", container_id]))[0]
    if result["Id"] != container_id or result["Config"]["Labels"].get("codex.owner") != OWNER:
        raise RuntimeError("Container identity/ownership mismatch")
    return result


def validate_limits(info: dict) -> dict:
    """Reject any unexpected accelerator exposure or relaxed CPU-only limits."""
    host = info["HostConfig"]
    exact = {"Runtime": "runc", "Privileged": False, "NetworkMode": "none", "Memory": 8 * 1024**3,
             "NanoCpus": 4 * 1000**3, "PidsLimit": 256}
    for name, value in exact.items():
        if host.get(name) != value:
            raise RuntimeError(f"Unexpected container setting: {name}")
    for name in ["Devices", "DeviceRequests", "DeviceCgroupRules"]:
        if host.get(name):
            raise RuntimeError(f"Unexpected accelerator/device exposure: {name}")
    if info["Image"] != IMAGE:
        raise RuntimeError("Container image mismatch")
    for mount in info["Mounts"]:
        if mount["Destination"] in ["/dev", "/sys"] or mount["Destination"].startswith("/dev/"):
            raise RuntimeError("A device path was mounted into the CPU-only container")
    return {name: host.get(name) for name in list(exact) +
            ["Devices", "DeviceRequests", "DeviceCgroupRules", "ReadonlyRootfs", "Tmpfs"]}


def preflight(case: str) -> dict:
    """Require the owned root, current source and exact CPU-parser input bytes."""
    if case != CASE or ROOT != Path("/opt/xxl-jt-dev-8npu-20261014") or ROOT.resolve() != ROOT:
        raise RuntimeError("Unexpected parser case or root")
    if json.loads((ROOT / "owner.json").read_text())["owner"] != OWNER:
        raise RuntimeError("Task owner mismatch")
    expected = json.loads((ROOT / "evidence/a1e6-matrix-cpu-inputs-v1.json").read_bytes())
    for relative, digest in expected["files"].items():
        path = ROOT / relative
        if path.resolve() != path or not path.is_file() or hashlib.sha256(path.read_bytes()).hexdigest() != digest:
            raise RuntimeError("Prepared parser input changed: " + relative)
    source = subprocess.check_output(["git", "rev-parse", "HEAD"], cwd=ROOT / "repo", text=True).strip()
    if source != SOURCE or subprocess.check_output(["git", "status", "--porcelain"], cwd=ROOT / "repo"):
        raise RuntimeError("Source is not the clean reviewed checkout")
    if (ROOT / "evidence/a1e6-future-matrix-actual-parser-v1.json").exists():
        raise RuntimeError("Refusing to replace parser evidence")
    return {"source": source, "files": expected["files"], "scope": "CPU parser only; no migration admission"}


def main() -> None:
    """Launch one bounded CPU-only container and remove exactly that container."""
    parser = argparse.ArgumentParser()
    parser.add_argument("case", choices=sorted(CASES))
    case = parser.parse_args().case
    stdout_path = ROOT / "evidence" / (case + ".stdout.log")
    stderr_path = ROOT / "evidence" / (case + ".stderr.log")
    receipt_path = ROOT / "evidence" / (case + ".receipt.json")
    if any(path.exists() for path in [stdout_path, stderr_path, receipt_path]):
        raise RuntimeError("Refusing to overwrite CPU diagnostic evidence")
    receipt = {"case": case, "owner": OWNER, "started_epoch": time.time(), "preflight": preflight(case),
               "timeout_seconds": 240, "status": "STARTING"}
    command = ["docker", "create", "--name", "jt-cpu-" + case,
               "--label", "codex.owner=" + OWNER, "--label", "codex.case=" + case,
               "--runtime", "runc", "--network", "none", "--memory", "8g", "--cpus", "4",
               "--pids-limit", "256", "--env", "PYTHONDONTWRITEBYTECODE=1",
               "--env", "TORCH_DEVICE_BACKEND_AUTOLOAD=0", "--entrypoint", "/bin/bash"]
    if case == "201-image-cpu-static-v1":
        command += ["--read-only", "--tmpfs", "/tmp:rw,nosuid,nodev,size=1g",
                    "--mount", "type=bind,source=" + str(ROOT) + ",target=/work,readonly"]
    else:
        command += ["--workdir", "/workspace/hyper-parallel",
                    "--mount", "type=bind,source=" + str(ROOT) + ",target=/work",
                    "--mount", "type=bind,source=" + str(ROOT / "repo") + ",target=/workspace/hyper-parallel",
                    "--mount", "type=bind,source=/usr/local/Ascend/driver,target=/usr/local/Ascend/driver,readonly"]
    command += [IMAGE, "-lc", CASES[case]]
    container_id = subprocess.check_output(command, text=True).strip()
    receipt.update(container_id=container_id, docker_create_command=command)
    try:
        info = inspect_container(container_id)
        receipt["verified_host_config"] = validate_limits(info)
        receipt["mounts"] = info["Mounts"]
        with stdout_path.open("xb") as output, stderr_path.open("xb") as errors:
            result = subprocess.run(["docker", "start", "--attach", container_id], stdout=output, stderr=errors,
                                    timeout=240, check=False)
        receipt["attach_exit_code"] = result.returncode
        info = inspect_container(container_id)
        receipt["container_state"] = info["State"]
        receipt["status"] = "PASS" if result.returncode == 0 and info["State"]["ExitCode"] == 0 else "FAIL"
    except subprocess.TimeoutExpired:
        receipt.update(status="TIMEOUT", attach_exit_code=124)
    except BaseException as error:
        receipt.update(status="ERROR", error=str(error))
        raise
    finally:
        info = inspect_container(container_id)
        if info["State"]["Running"]:
            subprocess.run(["docker", "kill", "--signal", "KILL", container_id], check=True,
                           stdout=subprocess.DEVNULL, timeout=15)
        receipt["final_container_state"] = inspect_container(container_id)["State"]
        subprocess.run(["docker", "rm", container_id], check=True, stdout=subprocess.DEVNULL, timeout=30)
        remaining = subprocess.check_output(["docker", "ps", "--all", "--quiet", "--no-trunc",
                                             "--filter", "id=" + container_id], text=True).strip()
        receipt["removed_verified"] = not remaining
        receipt["finished_epoch"] = time.time()
        with receipt_path.open("x", encoding="utf-8") as output:
            json.dump(receipt, output, ensure_ascii=False, indent=2)
            output.write("\n")
    print(json.dumps(receipt, ensure_ascii=False), flush=True)
    if receipt["status"] != "PASS" or not receipt["removed_verified"]:
        raise SystemExit(1)


if __name__ == "__main__":
    main()
