# Copyright 2026 Huawei Technologies Co., Ltd
#
# Licensed under the Apache License, Version 2.0 (the "License");
# you may not use this file except in compliance with the License.
# You may obtain a copy of the License at
#
# http://www.apache.org/licenses/LICENSE-2.0
#
# Unless required by applicable law or agreed to in writing, software
# distributed under the License is distributed on an "AS IS" BASIS,
# WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
# See the License for the specific language governing permissions and
# limitations under the License.
# ============================================================================

"""Independently check the collected 201 run without manufacturing a cross-host reference."""

import copy
from datetime import datetime, timezone
import hashlib
import json
import math
from pathlib import Path, PurePosixPath
import re
import statistics


ROOT = Path(__file__).resolve().parents[1]
CASE = 'r201-a1e6-fsdp8-0-200-v1'
RUN = ROOT / 'runs' / CASE
SOURCE = '544526f7db8342c607244fd41009b2a74adb84c8'
IMAGE = 'sha256:5f9e677f439d11ab4e7c888f54b142335a27eee7411cbd2ce894a4798a70146d'
OWNER = '01a13aa4-a553-7e22-a1c1-ebd16b083bb9'
PREFIX = 'evidence/201-a1e6-fsdp8-200-v1-'
ORIGINAL = PREFIX + 'evidence-manifest.json'
JOINT = PREFIX + 'joint-audit-manifest.json'
LOSS_KEYS = ('training/total_loss', 'training/foundation_loss/lm',
             'training/foundation_loss/mtp', 'training/foundation_loss/aux', 'training/grad_norm')
INPUTS = {
    ORIGINAL: '0f5787ac734e47aac93b00166d5b56a06a7926d6bcfe632ff460908dcb32e85c',
    JOINT: 'ea154ebe0511cc2b51b142e6bf75581e50f75e9a8055d7afb281794f9071326f',
    'evidence/201-fsdp8-reference-config.json': 'dfb276d6b985e0d6197888d4480c340611bc2ab42a3d58c89121a1319457f782',
    'evidence/201-data-source-manifest.json': '4438e20fb2e95251a9358eadcc1dc2b435f58a4528d604a5b2a32e9965105e21',
    PREFIX + 'independent-remote-state.json': '5fa15d590904616cb6c6b7f9379e4019ad10973d56730a4dd772ff932f7ca4da',
    PREFIX + 'independent-data-hashes.json': 'ee1fc418a61b2f4caa3d2ff3c36010e2be37066a44410a33a342af51343844d6',
}


def require(condition: bool, message: str) -> None:
    """Stop before creating a PASS report when any independent invariant fails."""
    if not condition:
        raise ValueError(message)


def unique_object(pairs: list) -> dict:
    """Reject duplicate JSON fields rather than interpreting the last value silently."""
    result = {}
    for key, value in pairs:
        require(key not in result, 'Duplicate JSON key: ' + key)
        result[key] = value
    return result


def invalid_number(value: str) -> None:
    """Reject non-finite JSON literals."""
    raise ValueError('Non-finite JSON literal: ' + value)


def read_json(path: Path) -> dict:
    """Read a bounded evidence object with explicit JSON semantics."""
    return json.loads(path.read_bytes(), object_pairs_hook=unique_object, parse_constant=invalid_number)


def sha256(path: Path) -> str:
    """Hash bytes incrementally, preserving bounded host memory."""
    digest = hashlib.sha256()
    with path.open('rb') as handle:
        for chunk in iter(lambda: handle.read(1024 * 1024), b''):
            digest.update(chunk)
    return digest.hexdigest()


def verify_manifest(relative: str, count: int) -> dict:
    """Independently validate every entry, including paths, sizes and hashes."""
    value = read_json(ROOT / relative)
    entries = {}
    for entry in value['files']:
        name = PurePosixPath(entry['path'])
        require(not name.is_absolute() and '..' not in name.parts and '\\' not in str(name), 'Unsafe manifest path')
        require(name.as_posix() not in entries, 'Duplicate manifest entry')
        path = ROOT / name
        require(path.is_file() and path.resolve() == path and ROOT in path.parents, 'Missing or redirected file')
        require(type(entry['bytes']) is int and entry['bytes'] == path.stat().st_size, 'File size differs: ' + str(name))
        require(entry['sha256'] == sha256(path), 'SHA differs: ' + str(name))
        entries[name.as_posix()] = entry
    require(len(entries) == count, 'Unexpected manifest entry count')
    return entries


def traces() -> tuple:
    """Validate all 1600 ordered optimizer rows and across-rank identities."""
    rows, initial, flags, memories = [], [], [], []
    expected_steps = list(range(1, 201))
    for rank in range(8):
        start = read_json(RUN / f'start-rank{rank}.json')
        complete = read_json(RUN / f'complete-rank{rank}.json')
        require(start['global_step'] == 0 and start['train_iters'] == 200 and start['micro_batches'] == 1,
                'Incorrect start boundary')
        require(complete['global_step'] == 200, 'Incorrect complete boundary')
        initial.append(read_json(RUN / f'initial-state-rank{rank}.json'))
        flags.append(read_json(RUN / f'runtime-flags-rank{rank}.json'))
        memories.append(read_json(RUN / f'final-memory-rank{rank}.json'))
        rank_rows = [json.loads(line, object_pairs_hook=unique_object, parse_constant=invalid_number)
                     for line in (RUN / f'metrics-rank{rank}.jsonl').read_bytes().splitlines()]
        require([row['step'] for row in rank_rows] == expected_steps, 'Incomplete, duplicate or reordered steps')
        tokens, samples = 0, 0
        for row in rank_rows:
            require(type(row['rank']) is int and row['rank'] == rank and type(row['step']) is int, 'Wrong rank/step')
            for key, number in row.items():
                if key != 'input_identity':
                    require(type(number) in (float, int) and math.isfinite(number), 'Invalid metric: ' + key)
            identity = row['input_identity']
            require(identity['rank_count'] == 8 and identity['micro_steps'] == 1
                    and re.fullmatch('[0-9a-f]{64}', identity['global_sha256']) is not None, 'Invalid input identity')
            require(row['data/step_samples'] == 8 and row['data/step_tokens'] >= 0
                    and row['data/step_tokens'] == int(row['data/step_tokens']), 'Incorrect logical batch size')
            tokens += row['data/step_tokens']
            samples += row['data/step_samples']
            require(row['data/consumed_tokens'] == tokens and row['data/consumed_samples'] == samples,
                    'Incorrect cumulative counters')
            require(row['performance/step_time'] > 0, 'Nonpositive timing')
        rows.append(rank_rows)
    parameters = {value['name'] for value in read_json(RUN / 'start-rank0.json')['model_parameters']}
    persistent_buffers = {'model.layers.1.mlp.gate.e_score_correction_bias',
                          'mtp.layers.0.transformer_layer.mlp.gate.e_score_correction_bias'}
    require(all(value == initial[0] for value in initial) and set(initial[0]) == parameters | persistent_buffers,
            'Initial tensor identity differs or has unexpected cardinality')
    require(all(value == flags[0] for value in flags), 'Runtime flags differ across ranks')
    require(flags[0]['training']['deterministic_algorithms'] is True
            and flags[0]['training']['deterministic_warn_only'] is False, 'Unexpected deterministic flags')
    for environment in (flags[0]['before_trainer']['environment'], flags[0]['training']['environment']):
        require(environment['CLOSE_MATMUL_K_SHIFT'] is None, 'Unexpected K_SHIFT override')
    counter_keys = ('data/step_tokens', 'data/step_samples', 'data/consumed_tokens', 'data/consumed_samples')
    for step in range(200):
        for rank in range(1, 8):
            require(rows[rank][step]['input_identity'] == rows[0][step]['input_identity'], 'Cross-rank input differs')
            require(all(rows[rank][step][key] == rows[0][step][key] for key in counter_keys),
                    'Cross-rank logical counters differ')
    for rank, memory in enumerate(memories):
        require(memory['global_step'] == 200 and memory['device'] == rank, 'Wrong final memory boundary')
        require(memory['scope'] == 'Per-process allocator lifetime peaks through completed training/checkpoint callbacks; '
                'not physical device HBM peaks', 'Memory scope differs')
        fields = ('allocated_bytes', 'reserved_bytes', 'max_allocated_bytes', 'max_reserved_bytes')
        require(all(type(memory[key]) is int and memory[key] >= 0 for key in fields), 'Invalid memory counter')
        require(memory['allocated_bytes'] <= memory['reserved_bytes'] <= memory['max_reserved_bytes']
                and memory['allocated_bytes'] <= memory['max_allocated_bytes'] <= memory['max_reserved_bytes'],
                'Memory counter ordering differs')
    return rows, initial, flags, memories


def sampled_resources(receipt: dict) -> dict:
    """Recompute sampled HBM and cgroup maxima from the archived raw observations."""
    expected = f'scheduling/{CASE}.device-samples.jsonl'
    require(receipt['device_samples'] == expected, 'Sample path differs')
    samples = [json.loads(line, object_pairs_hook=unique_object, parse_constant=invalid_number)
               for line in (ROOT / expected).read_bytes().splitlines()]
    require(len(samples) == 82 == receipt['device_sample_count'], 'Sample count differs')
    maxima = {str(rank): 0 for rank in range(8)}
    utilization = {str(rank): 0 for rank in range(8)}
    free = 32768
    for sample in samples:
        require(set(sample['cards']) == set(maxima), 'Sample omits a device')
        require(receipt['started_wall'] <= sample['observed_wall'] <= receipt['finished_wall'], 'Sample outside run')
        require(sample['container_memory']['path'].endswith('/' + receipt['container_id']), 'Cgroup identity differs')
        for rank, card in sample['cards'].items():
            require(card['healthy'] and card['hbm_total_mb'] == 32768, 'Device capacity or health differs')
            require(0 <= card['hbm_mb'] <= 32768 and 0 <= card['core'] <= 100, 'Invalid resource observation')
            maxima[rank] = max(maxima[rank], card['hbm_mb'])
            utilization[rank] = max(utilization[rank], card['core'])
            free = min(free, 32768 - card['hbm_mb'])
    intervals = [right['observed_wall'] - left['observed_wall'] for left, right in zip(samples, samples[1:])]
    require(all(interval > 0 for interval in intervals), 'Unordered samples')
    peak = max(sample['container_memory']['peak_bytes'] for sample in samples)
    require(maxima == receipt['sampled_hbm_max_mb_by_device'], 'Receipt HBM aggregate differs')
    require(utilization == receipt['sampled_aicore_max_percent_by_device'], 'Receipt core aggregate differs')
    require(peak == receipt['sampled_container_cgroup_peak_bytes'], 'Receipt cgroup peak differs')
    return {'sample_count': len(samples), 'sampled_hbm_max_mib_by_device': maxima,
            'sampled_hbm_peak_mib': max(maxima.values()), 'sampled_min_free_mib': free,
            'sampled_aicore_max_percent_by_device': utilization, 'sampled_container_cgroup_peak_bytes': peak,
            'host_mem_available_min_bytes': min(sample['host_memory_bytes']['MemAvailable'] for sample in samples),
            'configured_interval_seconds': receipt['device_sample_interval_seconds'],
            'observed_interval_median_seconds': statistics.median(intervals),
            'observed_interval_max_seconds': max(intervals),
            'last_sample_to_receipt_finish_seconds': receipt['finished_wall'] - samples[-1]['observed_wall'],
            'scope': 'Sampled physical HBM only; capture gaps and launch/release edges prevent an instantaneous peak claim.'}


def main() -> None:
    """Save a new provenance-bound single-run report, always keeping migration false."""
    for name, expected in INPUTS.items():
        require(sha256(ROOT / name) == expected, 'Pinned independent input changed: ' + name)
    original, joint = verify_manifest(ORIGINAL, 92), verify_manifest(JOINT, 98)
    require(all(joint.get(name) == entry for name, entry in original.items()), 'Original collection was replaced')
    actual_files = {path.relative_to(ROOT).as_posix() for path in RUN.rglob('*') if path.is_file()}
    require(actual_files == {name for name in original if name.startswith('runs/')}, 'Unlisted or missing run file')
    request = read_json(ROOT / 'scheduling' / (CASE + '.request.json'))
    receipt = read_json(ROOT / 'scheduling' / (CASE + '.receipt.json'))
    joint_metadata = read_json(ROOT / JOINT)['request_provenance']
    remote_request = read_json(ROOT / joint_metadata['remote_supplement']['supplemental_path'])
    guard = read_json(ROOT / joint_metadata['guard_state_snapshot_path'])
    require(request == remote_request == guard['request'], 'Supplemental request provenance differs')
    require(receipt == guard['last_receipt'] and guard['phase'] == 'ready', 'Frozen release state differs')
    for value in (request, receipt):
        require(value['host'] == '201' and value['case'] == CASE and value['source'] == SOURCE
                and value['image'] == IMAGE and value['workspace'] == '/opt/xxl-jt-dev-8npu-20261014',
                'Run execution identity differs')
        require(value['patch_sha256'] == hashlib.sha256(b'').hexdigest(), 'Dirty source patch')
    require(receipt['attempted'] is True and receipt['released'] is True and receipt['exit_code'] == 0
            and receipt['remaining_owned_pids'] == [] and receipt['owner'] == OWNER
            and receipt['devices'] == list(range(8)) and receipt['precision_admission_only'] is True,
            'Incomplete execution or release')
    require((RUN / 'EXIT_CODE').read_text().strip() == '0' and (RUN / 'source-commit.txt').read_text().strip() == SOURCE
            and (RUN / 'source.patch').read_bytes() == b'' and (RUN / 'source-status.txt').read_bytes() == b'',
            'Captured source or exit status differs')
    require((RUN / 'import-path.txt').read_text().strip() == '/workspace/hyper-parallel/hyper_parallel/__init__.py',
            'Editable import path differs')
    recipe = copy.deepcopy(read_json(ROOT / 'evidence/201-fsdp8-reference-config.json'))
    recipe['checkpoint']['checkpoint_dir'] = '/work/checkpoints/' + CASE
    require(read_json(RUN / 'config.resolved.json') == recipe, 'Resolved numerical recipe differs')
    require(sha256(RUN / 'config.yaml') == request['files']['configs/' + CASE + '.yaml'], 'Executed config differs')
    helpers = ('capture_a1e6_training.py', 'capture_training.py', 'module_profile.py', 'expert_probe.py',
               'precision_experiments.py', 'fp32_wgrad_experiment.py')
    require(all(sha256(RUN / name) == request['files']['tools/' + name] for name in helpers), 'Helper pin differs')
    data = read_json(ROOT / 'evidence/201-data-source-manifest.json')
    remote_data = read_json(ROOT / (PREFIX + 'independent-data-hashes.json'))
    require(remote_data['files'] == data['files'], 'Remote data files or metadata differ')
    for name, value in data['files'].items():
        relative = 'data/sft_data_4k/' + name
        require(request['files'][relative] == value['sha256'], 'Dataset pin differs')
    rows, initial, flags, memories = traces()
    cross_rank = {key: max(abs(rows[rank][step][key] - rows[0][step][key])
                           for rank in range(8) for step in range(200)) for key in LOSS_KEYS}
    times = [max(rows[rank][step]['performance/step_time'] for rank in range(8)) for step in range(20, 200)]
    measured_tokens = sum(row['data/step_tokens'] for row in rows[0][20:])
    resources = sampled_resources(receipt)
    resources.update(median_callback_step_seconds_after20=statistics.median(times),
                     summed_callback_seconds_after20=sum(times), supervised_tokens_after20=measured_tokens,
                     supervised_tokens_per_callback_second_after20=measured_tokens / sum(times),
                     allocator_lifetime_max_allocated_bytes=max(value['max_allocated_bytes'] for value in memories),
                     allocator_lifetime_max_reserved_bytes=max(value['max_reserved_bytes'] for value in memories))
    previous = read_json(ROOT / (PREFIX + 'summary.json'))
    require(previous['migration_allowed'] is False and previous['verified_files'] == 92, 'Prior summary overclaims')
    require(resources['median_callback_step_seconds_after20'] == previous['resources']['median_step_seconds']
            and resources['supervised_tokens_per_callback_second_after20'] == previous['resources']['supervised_tokens_per_second']
            and resources['sampled_hbm_peak_mib'] == previous['sampled_physical_hbm_peak_mib']
            and resources['sampled_min_free_mib'] == previous['sampled_physical_hbm_min_free_mib'],
            'Independent resource aggregation differs from prior summary')
    remote = read_json(ROOT / (PREFIX + 'independent-remote-state.json'))
    require(remote['receipt_sha256'] == sha256(ROOT / 'scheduling' / (CASE + '.receipt.json')), 'Remote receipt changed')
    require(remote['fixed_container_inspect']['exit_code'] == 1
            and 'No such object: ' + receipt['container_id'] in remote['fixed_container_inspect']['stderr'],
            'Completed container removal is not proven')
    require(remote['owned_containers']['exit_code'] == 0 and not remote['owned_containers']['stdout'].strip(),
            'An owned container remains in the independent terminal snapshot')
    smi = remote['npu_smi_info']
    require(smi['exit_code'] == 0, 'Current device read failed')
    empty = {int(value) for value in re.findall(r'No running processes found in NPU\s+(\d+)', smi['stdout'])}
    healthy = {int(value) for value in re.findall(r'^\|\s*(\d+)\s+910B4\s*\|\s*OK', smi['stdout'], re.MULTILINE)}
    require(empty == healthy == set(range(8)), 'Current 201 cards are not all healthy and empty')
    require(remote['source_head']['stdout'].strip() == SOURCE and remote['source_status']['stdout'] == '',
            'Remote source changed or became dirty')
    inventory = read_json(ROOT / 'evidence/201-a1e6-step200-checkpoint-inventory.json')
    require(inventory['files'] == remote['checkpoint']['files']
            and inventory['total_bytes'] == remote['checkpoint']['total_bytes'], 'Checkpoint inventory changed')
    references = []
    for host in ('125', '129'):
        case = f'r{host}-a1e6-fsdp8-0-200-v1'
        path = ROOT / 'runs' / case
        references.append({'host': host, 'case': case, 'complete_rank_count': len(list(path.glob('complete-rank*.json'))),
                           'metric_rank_count': len(list(path.glob('metrics-rank*.jsonl'))),
                           'receipt_exit_code': read_json(ROOT / 'scheduling' / (case + '.receipt.json'))['exit_code']})
    require(all(value['complete_rank_count'] == 0 for value in references), 'Shared reference availability changed')
    report = {'time_utc': datetime.now(timezone.utc).isoformat(), 'case': CASE,
              'status': 'PASS_SINGLE_RUN_AND_RESOURCE_INTEGRITY_ONLY', 'migration_admitted': False,
              'cross_host_precision_status': 'UNVERIFIED_NO_COMPLETE_MATCHING_SOURCE_SHARED_HOST_REFERENCE',
              'cross_hardware_parallel_performance_claim': False, 'pinned_inputs_sha256': INPUTS,
              'original_files_verified': len(original), 'joint_files_verified': len(joint),
              'original_total_bytes': sum(value['bytes'] for value in original.values()),
              'original_collection_unchanged': True, 'request_json_provenance_equal': True,
              'source': SOURCE, 'source_clean': True, 'ranks': 8, 'ordered_optimizer_steps_each_rank': [1, 200],
              'metric_rows': 1600, 'initial_tensor_count_each_rank': len(initial[0]),
              'cross_rank_initial_and_input_identity_equal': True, 'cross_rank_logged_scalar_max_abs': cross_rank,
              'runtime_flags': flags[0], 'end_counters': {'samples': rows[0][-1]['data/consumed_samples'],
                                                        'tokens': rows[0][-1]['data/consumed_tokens']},
              'first_step_logged_losses': {key: rows[0][0][key] for key in LOSS_KEYS},
              'last_step_logged_losses': {key: rows[0][-1][key] for key in LOSS_KEYS},
              'resources': resources, 'execution_exit_code': 0, 'released': True,
              'live_terminal_check': {'fixed_container_absent': True, 'owned_containers': 0,
                                      'healthy_empty_devices': sorted(empty), 'remote_source_clean': True},
              'checkpoint': {'file_count': len(inventory['files']), 'total_bytes': inventory['total_bytes'],
                             'small_sha256_files_rechecked': sum('sha256' in value for value in inventory['files']),
                             'large_tensor_files_size_only': sum('sha256' not in value for value in inventory['files']),
                             'restore_or_resume_tested': False, 'all_inventory_entries_unchanged': True},
              'shared_references': references,
              'boundaries': ['No independent shared-host reference exists; rank agreement does not prove accuracy.',
                             'Physical HBM maxima are sampled; 5s configuration is not a guaranteed sampling interval.',
                             'Callback timing excludes first20 steps and does not include end-to-end setup/checkpoint/release.',
                             'Checkpoint 17 small-file hashes verified; 8 large tensor payloads were not read/hashed/restored.',
                             'No NPU experiment, container launch, source edit or evidence replacement was performed.']}
    extra_inputs = (PREFIX + 'summary.json', 'evidence/201-a1e6-step200-checkpoint-inventory.json',
                    'evidence/201-cross-host-admission-auditor-independent-review-v2.json')
    report['additional_inputs_sha256'] = {name: sha256(ROOT / name) for name in extra_inputs}
    report['analysis_script_sha256'] = sha256(Path(__file__))
    output = ROOT / (PREFIX + 'independent-run-review.json')
    with output.open('x', encoding='utf-8') as handle:
        json.dump(report, handle, ensure_ascii=False, indent=2, allow_nan=False)
        handle.write('\n')
    print(json.dumps({'path': str(output), 'sha256': sha256(output), 'status': report['status'],
                      'migration_admitted': False, 'resources': resources}, ensure_ascii=False))


if __name__ == '__main__':
    main()
