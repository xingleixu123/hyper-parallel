# Copyright 2026 Huawei Technologies Co., Ltd
#
# Licensed under the Apache License, Version 2.0 (the "License");
# you may not use this file except in compliance with the License.
# You may obtain a copy of the License at
#
# http://www.apache.org/licenses/LICENSE-2.0
#
# Unless required by applicable law or agreed to in writing, software
# distributed under the License is distributed on an "AS IS" BASIS,
# WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
# See the License for the specific language governing permissions and
# limitations under the License.
# ============================================================================

"""Read fixed 201 completion evidence without starting containers or loading tensor payloads."""

import hashlib
import json
from pathlib import Path
import shutil
import subprocess
import time


ROOT = Path('/opt/xxl-jt-dev-8npu-20261014')
CASE = 'r201-a1e6-fsdp8-0-200-v1'
CONTAINER = '7ccb81afdb9b6bffd5de62ff4d671a90b8afd7b326c3ce0097577f8c0bc181fa'
OWNER = '01a13aa4-a553-7e22-a1c1-ebd16b083bb9'


def command(arguments: list) -> dict:
    """Capture only a bounded read command's output and status."""
    result = subprocess.run(arguments, capture_output=True, text=True, timeout=30, check=False)
    if len(result.stdout) + len(result.stderr) > 131072:
        raise RuntimeError('Unexpectedly large read command output')
    return {'exit_code': result.returncode, 'stdout': result.stdout, 'stderr': result.stderr}


def checked(path: Path) -> None:
    """Require an existing regular task file without symlink redirection."""
    if path.resolve() != path or ROOT not in path.parents or not path.is_file() or path.is_symlink():
        raise RuntimeError('Unsafe or missing task evidence path: ' + str(path))


def main() -> None:
    """Print a read-only live snapshot and hashes of checkpoint files at most one MiB."""
    if ROOT.resolve() != ROOT or not ROOT.is_dir():
        raise RuntimeError('Unexpected fixed task root')
    owner_path = ROOT / 'owner.json'
    checked(owner_path)
    owner = json.loads(owner_path.read_bytes())
    if owner.get('owner') != OWNER:
        raise RuntimeError('Task owner differs')
    receipt_path = ROOT / 'scheduling' / (CASE + '.receipt.json')
    checked(receipt_path)
    receipt_raw = receipt_path.read_bytes()
    receipt = json.loads(receipt_raw)
    if receipt['container_id'] != CONTAINER or receipt['owner'] != OWNER or receipt['case'] != CASE:
        raise RuntimeError('Completed receipt identity differs')
    checkpoint = ROOT / 'checkpoints' / CASE / 'global_step_200'
    if checkpoint.resolve() != checkpoint or not checkpoint.is_dir():
        raise RuntimeError('Unsafe checkpoint directory')
    files = []
    for path in sorted(checkpoint.rglob('*')):
        if path.is_dir():
            if path.is_symlink() or path.resolve() != path:
                raise RuntimeError('Checkpoint directory redirects')
            continue
        checked(path)
        size = path.stat().st_size
        entry = {'path': path.relative_to(checkpoint).as_posix(), 'bytes': size}
        if size <= 1024 * 1024:
            entry['sha256'] = hashlib.sha256(path.read_bytes()).hexdigest()
        files.append(entry)
    docker = ['docker', '--host', 'unix:///var/run/docker.sock']
    inspect = command(docker + ['inspect', '--format', '{{json .State}}', CONTAINER])
    if inspect['exit_code'] == 0:
        inspect['state'] = json.loads(inspect['stdout'])
    memory = {}
    for line in Path('/proc/meminfo').read_text().splitlines():
        name, value = line.split(':', 1)
        if name in ('MemTotal', 'MemAvailable'):
            memory[name] = int(value.strip().split()[0]) * 1024
    report = {
        'remote_observed_wall': time.time(), 'host': '201', 'root': str(ROOT), 'owner': owner,
        'case': CASE, 'receipt_sha256': hashlib.sha256(receipt_raw).hexdigest(),
        'receipt_released': receipt['released'], 'receipt_remaining_owned_pids': receipt['remaining_owned_pids'],
        'fixed_container_inspect': inspect,
        'owned_containers': command(docker + ['ps', '-a', '--no-trunc', '--filter', 'label=codex.owner=' + OWNER,
                                              '--format', '{{json .}}']),
        'npu_smi_info': command(['npu-smi', 'info']),
        'source_head': command(['git', '-C', str(ROOT / 'repo'), 'rev-parse', 'HEAD']),
        'source_status': command(['git', '-C', str(ROOT / 'repo'), 'status', '--porcelain', '--untracked-files=normal']),
        'checkpoint': {'path': str(checkpoint), 'files': files, 'total_bytes': sum(item['bytes'] for item in files),
                       'scope': 'All file names/sizes, SHA256 only for files <=1MiB; no tensor payload read or restore'},
        'disk_free_bytes': shutil.disk_usage(ROOT).free, 'host_memory_bytes': memory,
        'read_only': True, 'containers_started': 0, 'npu_training_or_device_initialization': False,
    }
    print(json.dumps(report, ensure_ascii=False, allow_nan=False))


if __name__ == '__main__':
    main()
