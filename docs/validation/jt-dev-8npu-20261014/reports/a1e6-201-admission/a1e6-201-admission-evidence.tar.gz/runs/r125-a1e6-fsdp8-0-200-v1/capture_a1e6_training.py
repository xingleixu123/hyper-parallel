# Copyright 2026 Huawei Technologies Co., Ltd
#
# Licensed under the Apache License, Version 2.0 (the "License");
# you may not use this file except in compliance with the License.
# You may obtain a copy of the License at
#
# http://www.apache.org/licenses/LICENSE-2.0
#
# Unless required by applicable law or agreed to in writing, software
# distributed under the License is distributed on an "AS IS" BASIS,
# WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
# See the License for the specific language governing permissions and
# limitations under the License.
# ============================================================================

"""Observe determinism controls and completed-run memory without changing their values."""

import os

import torch

import capture_training


def environment_flags() -> dict:
    """Read strings only before the trainer assigns each worker's device."""
    return {name: os.environ.get(name) for name in (
        'CLOSE_MATMUL_K_SHIFT', 'NCCL_DETERMINISTIC', 'FLASH_ATTENTION_DETERMINISTIC',
        'CUBLAS_WORKSPACE_CONFIG', 'PYTHONHASHSEED', 'PYTORCH_NPU_ALLOC_CONF')}


def runtime_flags() -> dict:
    """Record selected controls after initialization without setting any backend option."""
    matmul = getattr(getattr(torch, 'npu', None), 'matmul', None)
    return {'environment': environment_flags(),
            'deterministic_algorithms': torch.are_deterministic_algorithms_enabled(),
            'deterministic_warn_only': torch.is_deterministic_algorithms_warn_only_enabled(),
            'npu_matmul': {name: getattr(matmul, name, None) for name in (
                'allow_tf32', 'allow_hf32', 'allow_bf16_reduced_precision_reduction')}}


BEFORE_TRAINER = {'environment': environment_flags(), 'scope': 'Environment only; no backend queries'}


class RuntimeEvidenceCallback(capture_training.EvidenceCallback):
    """Extend only train-boundary observations; preserve every step's original capture behavior."""

    def on_train_begin(self, state: object, **kwargs: object) -> None:
        """Capture the actual post-initialization flags used by each worker."""
        super().on_train_begin(state, **kwargs)
        capture_training.write_json(f'runtime-flags-rank{capture_training.RANK}.json',
                                    {'before_trainer': BEFORE_TRAINER, 'training': runtime_flags()})

    def on_train_end(self, state: object, **kwargs: object) -> None:
        """Read cumulative allocator peaks after checkpoint callbacks have completed."""
        torch.npu.synchronize()
        capture_training.write_json(f'final-memory-rank{capture_training.RANK}.json', {
            'global_step': state.global_step,
            'device': torch.npu.current_device(),
            'allocated_bytes': torch.npu.memory_allocated(),
            'reserved_bytes': torch.npu.memory_reserved(),
            'max_allocated_bytes': torch.npu.max_memory_allocated(),
            'max_reserved_bytes': torch.npu.max_memory_reserved(),
            'scope': 'Per-process allocator lifetime peaks through completed training/checkpoint callbacks; '
                     'not physical device HBM peaks',
        })
        super().on_train_end(state, **kwargs)


if __name__ == '__main__':
    capture_training.EvidenceCallback = RuntimeEvidenceCallback
    capture_training.main()
